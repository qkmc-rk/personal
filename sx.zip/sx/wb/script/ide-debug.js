/*
Copyright (c) geejing.com, all rights reserved.
Contact: contact@geejing.com
Visit: http://www.geejing.com
*/

/**
 * @class Ide
 *
 * 集成开发环境，为应用系统的开发提供一个整合的环境。实现了集成开发环境前台部分的应用。
 */
var Ide = {
  /** @property {Ext.container.Container} activeCard 当前激活的选项卡 */
  /** @property {Ext.component} activeTarget 最后被点击的组件 */
  /** @property {Ext.tree.Panel} fileTree IDE左侧的文件树 */
  /** @property {Ext.tab.Panel} fileTab IDE工作区文件选项卡 */
  /** @property {Ext.tree.Panel} controlTree IDE右侧控件树 */
  /** @property {Ext.tab.Panel} utilView IDE下方多功能视图 */
  /** @property {Ext.grid.Panel} markerGrid 多功能视图中的标记表格 */
  /** @property {Ext.grid.Panel} searchGrid 多功能视图中的搜索表格 */
  /** @property {Array} backList 导航返回列表 */
  backList: [],
  /** @property {Array} forwardList 导航前进列表 */
  forwardList: [],
  /** @property {Object} controlDefines 数据字典中的控件类型和图标定义 */
  controlDefines: {
    datetimefield: {
      type: 'datetime',
      iconCls: 'datetime_icon'
    },
    datefield: {
      type: 'date',
      iconCls: 'date_icon'
    },
    timefield: {
      type: 'time',
      iconCls: 'time_icon'
    },
    numberfield: {
      type: 'number',
      iconCls: 'ne_icon'
    },
    textfield: {
      type: 'text',
      iconCls: 'te_icon'
    },
    textarea: {
      type: 'textarea',
      iconCls: 'textarea_icon'
    },
    combo: {
      type: 'combo',
      iconCls: 'combobox_icon'
    },
    blob: {
      type: 'file',
      iconCls: 'file_default_icon'
    }
  },
  /**
   * 初始化集成开发环境。
   */
  init: function() {
    Ide.activeCard = null;
    Ide.activeScope = null;
    Ide.defineClasses();
    Ide.objectViewMenu = new Ext.menu.Menu({
      minWidth: 210,
      items: [{
          text: "剪切<span class='wb_right'>Ctrl+X</span>",
          iconCls: "cut_icon",
          handler: app.cut
        }, {
          text: "复制<span class='wb_right'>Ctrl+C</span>",
          iconCls: "copy_icon",
          handler: app.copy
        }, {
          text: "粘贴<span class='wb_right'>Ctrl+V</span>",
          iconCls: "paste_icon",
          handler: app.paste
        }, {
          text: "粘贴为子节点<span class='wb_right'>Ctrl+Shift+V</span>",
          iconCls: "tree_icon",
          handler: function() {
            app.pasteNode(true);
          }
        }, {
          text: "删除<span class='wb_right'>Delete</span>",
          iconCls: "delete_icon",
          handler: app.remove
        },
        "-", {
          text: "布局设计器<span class='wb_right'>Ctrl+B</span>",
          iconCls: "window_icon",
          handler: app.setLayout
        }, {
          text: "自动调整控件顺序<span class='wb_right'>Ctrl+Shift+U</span>",
          iconCls: 'order_icon',
          handler: app.adjustZIndex
        },
        "-", {
          text: "自动生成表格列",
          iconCls: "columns_icon",
          handler: app.createColumns
        }, {
          text: "自动添加编辑控件",
          iconCls: "te_icon",
          handler: app.createEditors
        }
      ]
    });
    Wb.onUnload(function() {
      var title = Wb.getModifiedTitle(Ide.fileTab, true);
      if (title !== null)
        return title + '已经被修改';
    });
    //获取系统数据
    Wb.request({
      url: 'm?xwl=dev/ide/get-sys-data',
      success: function(response) {
        Ext.apply(Ide, Wb.decode(response.responseText));
        Wb.each(Ide.cmPickList, function(k, v) {
          Ide.cmPickList[k] = Wb.sort(v);
        });
        if (Ide.versionType != 'x') {
          Ide.getStdPackBtn.setVisible(false);
          Ide.getEntPackBtn.setVisible(false);
          Ide.getRelPackBtn.setText('发布版本');
        }
      }
    });
  },
  /**
   * 在应用目录、模块目录或当前选择的目录/文件搜索文本。
   */
  search: function() {
    Ide.findReplace();
  },
  /**
   * 根据上次搜索的条件重新搜索结果。如果未执行过搜索则等效搜索操作。
   */
  searchAgain: function() {
    if (Ide.searchGrid.searched)
      Ide.searchGrid.store.reload();
    else Ide.search();
  },
  /**
   * 显示搜索表格。
   */
  showSearch: function() {
    Ide.toggleViewBtn.toggle(true);
    Ide.utilView.setActiveTab(Ide.searchGrid);
  },
  /**
   * 在应用目录内搜索指定类型文件的正则表达式关键字。文件类型包括：*.xwl,*.js,*.css,*.html,*.htm,*.java,*.jsp。
   */
  searchKey: function(searchRegExp) {
    Ide.searchGrid.store.load({
      params: {
        search: searchRegExp,
        pathList: Wb.encode([Ide.webPath]),
        filePatterns: '*.xwl,*.js,*.css,*.html,*.htm,*.java,*.jsp',
        regularExp: true,
        isReplace: false
      },
      callback: function(a, b, success) {
        if (success)
          Ide.showSearch();
        Ide.searchGrid.searched = true;
      }
    });
  },
  /**
   * 在应用目录内搜索TODO:关键字。搜索的文件类型包括：*.xwl,*.js,*.css,*.html,*.htm,*.java,*.jsp。
   */
  searchTodo: function() {
    Ide.searchKey('\\bTODO:');
  },
  /**
   * 在应用目录、模块目录或当前选择的目录/文件替换文本。
   */
  replace: function() {
    Ide.findReplace(true);
  },
  /**
   * 在应用目录、模块目录或当前选择的目录/文件搜索或替换文本。
   * @param {Boolean} isReplace 是否执行替换操作，默认为false。
   */
  findReplace: function(isReplace) {
    var items, files = Ide.fileTree.getSelection(),
      editor = Ide.getEditor(),
      selText;
    if (!files.length)
      files.push(Ide.fileTree.getRootNode().firstChild);
    if (editor)
      selText = editor.getSelection();
    items = [{
      xtype: 'combo',
      fieldLabel: '搜索内容',
      itemId: 'search',
      allowBlank: false,
      saveKeyname: 'sys.ide.find.find',
      pickKeyname: 'sys.ide.find.find',
      store: []
    }, {
      xtype: 'combo',
      fieldLabel: '文件类型',
      itemId: 'filePatterns',
      pickKeyname: 'sys.ide.find.filePatterns',
      value: '*.xwl, *.js, *.css, *.html, *.htm, *.java, *.jsp',
      saveKeyname: 'sys.ide.find.filePatterns',
      store: ['*.xwl, *.js, *.css, *.html, *.htm, *.java, *.jsp', '*.xwl', '*.js', '*.htm, *.html',
        '*.css', '*.java', '*.jsp, *.jspx'
      ]
    }, {
      xtype: 'radiogroup',
      fieldLabel: '检索目录',
      itemId: 'scope',
      saveKeyname: 'sys.ide.find.scope',
      items: [{
        boxLabel: '应用',
        value: true
      }, {
        boxLabel: '模块'
      }, {
        boxLabel: '选择'
      }, {
        boxLabel: '当前文件'
      }],
      listeners: {
        change: function(me, value) {
          var title;
          switch (value) {
            case 0:
              title = '应用';
              break;
            case 1:
              title = '模块';
              break;
            case 2:
              title = Wb.getInfo(files);
              break;
            case 3:
              title = Ide.activeCard && Ide.activeCard.file ?
                Ide.activeCard.file : '(无效)';
          }
          Wb.setTitle(me.up('window'), title);
        }
      }
    }, {
      xtype: 'fieldcontainer',
      hideEmptyLabel: false,
      layout: 'hbox',
      defaults: {
        flex: 1
      },
      items: [{
        itemId: 'whole',
        boxLabel: '完全匹配',
        xtype: 'checkbox',
        saveKeyname: 'sys.ide.find.whole'
      }, {
        itemId: 'caseSensitive',
        boxLabel: '区分大小写',
        xtype: 'checkbox',
        saveKeyname: 'sys.ide.find.caseSensitive'
      }, {
        itemId: 'regularExp',
        boxLabel: '正则表达式',
        xtype: 'checkbox',
        saveKeyname: 'sys.ide.find.regularExp',
        listeners: {
          change: function(me, value) {
            var ref = Wb.getRefer(me.ownerCt);
            ref.whole.setDisabled(value);
            ref.caseSensitive.setDisabled(value);
          }
        }
      }]
    }];
    if (isReplace)
      items.splice(1, 0, {
        xtype: 'combo',
        fieldLabel: '替换为',
        itemId: 'replace',
        pickKeyname: 'sys.ide.find.replace',
        store: []
      });
    var promptWin = Wb.prompt({
      title: (isReplace ? '替换' : '搜索') + ' - 应用',
      iconCls: 'search_icon',
      items: items,
      handler: function(values, win) {
        function doFindReplace() {
          var jsCaseInsensitive, jsRegExp, pathList;
          if (values.regularExp && Ext.String.endsWith(values.search, '/i')) {
            jsCaseInsensitive = true;
            jsRegExp = values.search.slice(0, -2);
            values.search = '(?i)' + jsRegExp;
          } else jsRegExp = values.search;
          switch (values.scope) {
            case 0:
              pathList = [
                Ide.webPath
              ];
              break;
            case 1:
              pathList = [Ide.modulePath];
              break;
            case 2:
              pathList = [];
              Wb.each(files, function(file) {
                pathList.push(Ide.getPath(file));
              });
              break;
            case 3:
              pathList = [];
              if (Ide.activeCard && Ide.activeCard.file)
                pathList.push(Ide.activeCard.path);
              break;
          }
          Ide.doCommit();
          Ide.searchGrid.store.load({
            params: Ext.apply({
              isReplace: isReplace,
              pathList: Wb.encode(pathList)
            }, values),
            callback: function(a, b, success) {
              if (success) {
                if (success)
                  Ide.showSearch();
                Ide.searchGrid.searched = !isReplace;
                win.close();
                if (isReplace) {
                  var card, regExp;
                  if (values.regularExp) {
                    if (jsCaseInsensitive)
                      regExp = new RegExp(jsRegExp, 'i');
                    else
                      regExp = new RegExp(jsRegExp);
                  } else {
                    regExp = (values.whole ? '\\b' : '') + Wb.quoteRegexp(values.search) + (values.whole ? '\\b' : '');
                    if (values.caseSensitive)
                      regExp = new RegExp(regExp);
                    else
                      regExp = new RegExp(regExp, 'i');
                  }
                  Ide.stopRecNav = true;
                  Ide.searchGrid.store.each(function(rec) {
                    card = Ide.fileTab.child('[path=' + rec.data.path + ']');
                    if (card) {
                      card.lastModified = rec.get('lastModified');
                      Ide.replaceText(card, regExp, values.replace);
                    }
                  });
                  Ide.stopRecNav = false;
                }
              }
            }
          });
        }
        if (isReplace)
          Wb.confirm('确定要替换已经保存的文本吗？<br>警告：替换后将不可撤消。', doFindReplace);
        else
          doFindReplace();
      }
    });
    if (selText)
      promptWin.getComponent('search').setValue(selText.split('\n')[0].substring(0, 500));
  },
  /**
   * 在选项卡中替换所有CodeMirror的文本。
   * @param {Panel} card 选项卡。
   * @param {RegExp} regExp 被替换字符串的正则表达式。
   * @return {String} newText 替换的字符串。
   */
  replaceText: function(card, regExp, newText) {
    function replace(cm) {
      var cursor = cm.getSearchCursor(regExp);
      while (cursor.findNext()) {
        cursor.replace(newText);
      }
      cm.needRefresh = true;
    }

    function replaceObject(obj) {
      if (!obj) return;
      Wb.each(obj, function(key, value) {
        obj[key] = value.replace(regExp, newText);
      });
    }
    if (card.cardType == 'module') {
      card.tree.getRootNode().cascadeBy(function(n) {
        if (!n.isRoot()) {
          replaceObject(n.data.configs);
          replaceObject(n.data.events);
          if (n.data.text !== n.data.configs.itemId) {
            n.set('text', n.data.configs.itemId);
            n.commit();
            Ide.syncNodes(n);
          }
        }
      });
      Ide.refreshGrid(card.property);
      var subCard = card.getActiveTab();
      if (subCard.layoutCard)
        Ide.updateLayout(subCard);
    }
    if (card.editor) replace(card.editor);
    if (card instanceof Ext.tab.Panel) {
      card.items.each(function(t) {
        if (t.editor) replace(t.editor);
      });
    }
  },
  /**
   * 根据节点数据刷新属性表格中的数据。
   * @param {PropertyGrid} [grid] 属性表格。如果缺省该值，将使用当前模块的属性表格。
   */
  refreshGrid: function(grid) {
    if (!grid) grid = Ide.activeCard.property;
    var data, value, typeData, metaData, propType,
      textTypes = ['text', 'html', 'js', 'ss', 'sql'],
      node = grid.node,
      meta = Ide.getMetaControl(node).data;
    grid.store.stopUpdate = true;
    Ext.suspendLayouts();
    grid.store.each(function(rec) {
      data = rec.data;
      propType = data.type.toLowerCase();
      typeData = node.data[propType];
      if (typeData) {
        value = typeData[data.name];
        metaData = meta[propType];
        if (metaData)
          metaData = metaData[data.name];
        if (metaData && Wb.indexOf(textTypes, metaData.type) != -1)
          value = Wb.toLine(value, 200);
        rec.set('value', value || '');
      }
    });
    grid.store.commitChanges();
    Ext.resumeLayouts(true);
    grid.store.stopUpdate = false;
  },
  /**
   * 提交所有编辑器中未决的数据。
   */
  doCommit: function() {
    Ide.fileTab.items.each(function(card) {
      if (card.commitChange)
        card.commitChange();
    });
  },
  /**
   * 属性设计器中itemId值验证器。
   * @param {String} value itemId值。
   */
  nodeItemIdValidator: function(value) {
    var found = false,
      node = Ide.activeCard.property.node;

    node.parentNode.eachChild(function(child) {
      if (child != node && child.data.text === value) {
        found = true;
        return false;
      }
    });
    if (found)
      return '名称 "' + value + '" 重复';
    else
      return true;
  },
  /**
   * 属性设计器中itemId值验证器。
   * @param {String} value itemId值。
   */
  compItemIdValidator: function(value) {
    var found = false,
      comp = this.ownerCt.curPropComp,
      designer = comp.ownerCt;

    designer.items.each(function(child) {
      if (child != comp && child._itemId === value) {
        found = true;
        return false;
      }
    });
    if (found)
      return '名称 "' + value + '" 重复';
    else
      return true;
  },
  /**
   * 使用SQL生成器生成SQL，并设置到当前编辑器。
   */
  setSQL: function() {
    Wb.run({
      url: 'm?xwl=sys/tool/dev/sql-builder',
      single: true,
      success: function(app) {
        app.getSQL(function(sql) {
          Ide.insertText(sql);
        });
      }
    });
  },
  /**
   * 显示添加框架模块的对话框。
   * @param {String} title 对话框标题。
   * @param {String} frameType 框架类型。
   * @param {Array} [extraItems] 对话框中的附加控件列表。
   * @param {Boolean} [createFolder] 是否创建子目录，默认为false。
   */
  promptFrameDialog: function(title, frameType, extraItems, createFolder) {
    var items = [{
      fieldLabel: '名称',
      allowBlank: false,
      itemId: 'name',
      validator: Ide.verifyName
    }, {
      fieldLabel: '标题',
      itemId: 'title'
    }, app.getIconEditor()];
    if (extraItems)
      items = items.concat(extraItems);
    Wb.prompt({
      title: title,
      iconCls: 'file_add_icon',
      defaults: {
        labelWidth: 80
      },
      items: items,
      handler: function(values, win) {
        var folder = app.getCurrentFolder(true);
        values.path = app.getPath(folder);
        values.frameType = frameType;
        Wb.request({
          url: 'm?xwl=dev/ide/add-frame',
          params: values,
          success: function(resp) {
            var moduleNode, folderNode, loaded = folder.data.loaded;
            folder.expand(false, function() {
              if (loaded) {
                moduleNode = folder.appendChild({
                  id: Wb.getId(),
                  text: values.name + ".xwl",
                  title: values.title,
                  iconCls: values.iconCls,
                  leaf: true
                });
                moduleNode.commit();
                if (createFolder) {
                  folderNode = folder.appendChild({
                    id: Wb.getId(),
                    text: values.name,
                    title: values.title,
                    hidden: true,
                    cls: 'x-highlight'
                  });
                  folderNode.commit();
                }
              } else {
                moduleNode = folder.findChild('text', values.name + '.xwl');
                if (createFolder)
                  folderNode = folder.findChild('text', values.name);
              }
              app.fileTree.setSelection(createFolder ? [moduleNode, folderNode] : moduleNode);
              win.close();
            });
          }
        });
      }
    });
  },
  /**
   * 创建增删改查框架模块。
   */
  createCRUDFrame: function() {
    app.promptFrameDialog('添加增删改查框架模块', 'crud', [{
      fieldLabel: '表名',
      itemId: 'tableName',
      allowBlank: false
    }, {
      fieldLabel: '主键字段',
      itemId: 'keyField',
      allowBlank: false
    }, {
      fieldLabel: '名称字段',
      itemId: 'nameField'
    }, {
      fieldLabel: '编号字段',
      itemId: 'codeField'
    }, {
      title: '数据的编辑方式',
      xtype: 'fieldset',
      defaultType: 'radio',
      items: [{
        boxLabel: '对话框',
        name: 'editMode',
        checked: true,
        itemId: 'dialog'
      }, {
        boxLabel: '可编辑表格',
        name: 'editMode',
        itemId: 'editGrid',
        listeners: {
          change: function(cb, val) {
            cb.up('window').getComponent('hasUpload').setDisabled(val);
          }
        }
      }]
    }, {
      boxLabel: '包含文件上传控件',
      xtype: 'checkbox',
      itemId: 'hasUpload'
    }], true);
  },
  /**
   * 创建公共对话框框架模块。
   */
  createDialogFrame: function() {
    app.promptFrameDialog('添加公共对话框框架模块', 'xcommonDialog');
  },
  /**
   * 创建主页面框架模块。
   */
  createMainFrame: function() {
    app.promptFrameDialog('添加主页面框架模块', 'xmainPage');
  },
  /**
   * 获取当前首个选择节点的目录所在路径。如果未选择任何节点将返回模块根节点路径。
   * @param {Boolean} returnNode 是否返回目录节点对象，默认返回路径。
   * @return {NodeInterface/String} 目录路径或目录节点对象。
   */
  getCurrentFolder: function(returnNode) {
    var folder = app.fileTree.getSelection()[0];
    if (!folder)
      folder = app.fileTree.getRootNode().firstChild;
    if (folder.isLeaf())
      folder = folder.parentNode;
    return returnNode ? folder : app.getPath(folder);
  },
  /**
   * 设置以毫米为单位的纸张大小，该宽度使用模拟宽度，在最终输出到打印时报像素转换为毫米。模拟比例4像素为1mm。
   */
  setPaper: function() {
    var designer = Ide.getDesigner();
    if (!designer) {
      Wb.warn('请打开布局设计器使用该功能。');
      return;
    }
    Wb.prompt({
      title: '设置纸张大小',
      iconCls: 'report_icon',
      focusControl: 'width',
      items: [{
        fieldLabel: '纸张类型',
        xtype: 'combo',
        allowBlank: false,
        editable: false,
        value: 0,
        store: [
          [
            [210, 297], 'A4纵向'
          ],
          [
            [297, 210], 'A4横向'
          ],
          [
            [297, 420], 'A3纵向'
          ],
          [
            [420, 297], 'A3横向'
          ],
          [0, '自定义大小']
        ],
        listeners: {
          change: function(cb, newValue) {
            var wEdit = cb.ownerCt.down('#width'),
              hEdit = cb.ownerCt.down('#height');
            if (newValue) {
              wEdit.setValue(newValue[0]);
              hEdit.setValue(newValue[1]);
            } else {
              Wb.reset([hEdit, wEdit]);
            }
          }
        }
      }, {
        fieldLabel: '宽度(mm)',
        xtype: 'numberfield',
        allowBlank: false,
        decimalPrecision: 0,
        itemId: 'width',
        value: 210,
        minValue: 0
      }, {
        fieldLabel: '长度(mm)',
        xtype: 'numberfield',
        allowBlank: false,
        decimalPrecision: 0,
        itemId: 'height',
        value: 297,
        minValue: 0
      }],
      handler: function(values, win) {
        designer.setWidth(4 * values.width);
        designer.setHeight(4 * values.height);
        Ide.setModified();
        win.close();
      }
    });
  },
  /**
   * 根据控件的位置自动调整控件先后顺序。
   */
  adjustZIndex: function() {
    Wb.confirm('确定要自动调整当前控件所属所有子控件的先后顺序吗？', function() {
      Ide.doAdjustZIndex();
    });
  },
  /**
   * 执行根据控件的位置自动调整控件先后顺序。
   * @param {NodeInterface} [containerNode] 要调整的容器节点。默认使用当前编辑的容器关联的节点或选择节点。
   */
  doAdjustZIndex: function(containerNode) {
    var nodes, sortNodes = [],
      designer = Ide.getDesigner();
    if (containerNode)
      nodes = [containerNode];
    else if (designer) {
      Ide.doApplyLayout(designer.ownerCt, true);
      nodes = [designer.node];
    } else
      nodes = Ide.getNode(true);
    if (Wb.isEmpty(nodes)) {
      Wb.warn('请在对象视图中选择至少1个容器节点。');
      return;
    }
    Ext.suspendLayouts();
    Wb.each(nodes, function(setNode) {
      setNode.eachChild(function(item) {
        sortNodes.push({
          node: item,
          w: (parseInt(item.data.configs.y, 10) || 0) * 1000000 + (parseInt(item.data.configs.x, 10) || 0)
        });
        Ide.doAdjustZIndex(item);
      });
      if (setNode.data.configs.layout == 'absolute') {
        Ext.Array.sort(sortNodes, function(v1, v2) {
          return v1.w - v2.w;
        });
        Wb.each(sortNodes, function(item) {
          setNode.appendChild(item.node);
        });
        //在对应的设计器中设置控件的ZIndex
        Ide.activeCard.items.each(function(card) {
          var designer = card.designer;
          if (designer && designer.node == setNode) {
            Wb.each(sortNodes, function(node) {
              designer.items.each(function(item) {
                if (item.isMask && item.bindComp.node == node.node) {
                  designer.add(item.bindComp);
                  designer.add(item);
                }
              });
            });
          }
        });
      }
    });
    Ext.resumeLayouts(true);
    Ide.setModified();
  },
  /**
   * 设置当前容器对象的布局。
   */
  setLayout: function() {
    var card = Ide.activeCard,
      node, layout, setCard;
    node = Ide.getNode();
    if (!node) {
      Wb.warn('请在模块对象视图中选择1个容器节点。');
      return;
    }
    if (!Ide.getMetaControl(node).data.configs.layout) {
      Wb.warn('所选择的节点无任何可用布局。');
      return;
    }
    layout = node.data.configs.layout;

    function doSetLayout() {
      if (!layout) {
        node.data.configs.layout = 'absolute';
        Ide.setModified();
      }
      card.items.each(function(subCard) {
        if (subCard.layoutCard && subCard.node == node) {
          setCard = subCard;
          return false;
        }
      });
      if (!setCard) {
        setCard = card.add({
          title: node.data.text,
          iconCls: node.data.iconCls,
          node: node,
          layoutCard: true,
          closable: true,
          autoScroll: true,
          border: false,
          commitChange: Ide.applyLayout,
          bodyStyle: 'background-color:#787878',
          bbar: [{
            xtype: 'tbtext',
            text: '名称:'
          }, {
            itemId: 'itemId',
            xtype: 'textfield',
            allowBlank: false,
            width: 130,
            validator: Ide.compItemIdValidator,
            listeners: {
              change: function(me, value) {
                if (me.ownerCt.allowChange && me.isValid()) {
                  var comp = me.ownerCt.curPropComp;
                  comp._itemId = value;
                  Ide.updateLabel(comp);
                  comp.node.set('text', value);
                  comp.node.commit();
                  Ide.syncNodes(comp.node);
                  Ide.setModified();
                }
              }
            }
          }, {
            xtype: 'tbtext',
            text: '标签:'
          }, {
            itemId: 'text',
            xtype: 'textfield',
            width: 130,
            listeners: {
              change: function(me, value) {
                var comp = me.ownerCt.curPropComp;
                if (me.ownerCt.allowChange && me.isValid() && comp.handleText) {
                  comp[Wb.valuePart(comp.handleText)](value);
                  Ide.updateLabel(comp);
                  if (comp.header && !comp.isXWin)
                    comp.header.setVisible(comp.title);
                  Ide.setModified();
                }
              }
            }
          }, {
            xtype: 'tbtext',
            text: '左:'
          }, {
            itemId: 'x',
            method: 'setLocalX',
            xtype: 'numberfield',
            allowDecimals: false,
            step: 8,
            width: 70,
            listeners: {
              change: Ide.setCompPos
            }
          }, {
            xtype: 'tbtext',
            text: '上:'
          }, {
            itemId: 'y',
            method: 'setLocalY',
            xtype: 'numberfield',
            allowDecimals: false,
            step: 8,
            width: 70,
            listeners: {
              change: Ide.setCompPos
            }
          }, {
            xtype: 'tbtext',
            text: '宽:'
          }, {
            itemId: 'width',
            method: 'setWidth',
            xtype: 'numberfield',
            allowDecimals: false,
            minValue: 0,
            step: 8,
            width: 70,
            listeners: {
              change: Ide.setCompPos
            }
          }, {
            xtype: 'tbtext',
            text: '高:'
          }, {
            itemId: 'height',
            method: 'setHeight',
            xtype: 'numberfield',
            allowDecimals: false,
            minValue: 0,
            step: 8,
            width: 70,
            listeners: {
              change: Ide.setCompPos
            }
          }],
          tabConfig: {
            tooltip: Ide.getNodePath(node)
          },
          listeners: {
            activate: Ide.updateLayout,
            beforedeactivate: Ide.applyLayout,
            afterrender: {
              single: true,
              fn: function(me) {
                me.comps = {
                  toolbar: me.down('toolbar')
                };
                Wb.getRefer(me.comps.toolbar, me.comps);
              }
            }
          }
        });
      }
      card.setActiveTab(setCard);
    }
    if (!layout) {
      Wb.confirm('容器未设置为absolute布局，点击确定将设置。', doSetLayout);
    } else if (layout == 'absolute' || Ext.String.startsWith(layout, '@') &&
      Wb.decode(layout.substring(1)).type == 'absolute') {
      doSetLayout();
    } else {
      Wb.warn('该布局可在对象视图中直接进行编辑。');
    }
  },
  /**
   * 在设计器中根据属性设置控件位置。
   * @param {NumberField} me 设置位置值的控件。
   * @param {Number} value 位置值。
   */
  setCompPos: function(me, value) {
    if (me.ownerCt.allowChange && me.isValid()) {
      var comp = me.ownerCt.curPropComp;
      comp[me.method](value);
      if (comp.bindMask)
        comp.bindMask[me.method](value);
      Ide.setModified();
    }
  },
  /**
   * 把当前设计器中设计的布局应用到对应的组件树。
   */
  applyLayout: function() {
    Ide.doApplyLayout(this, true);
  },
  /**
   * 把指定设计器中设计的布局应用到对应的组件树。
   * @param {Panel} card 布局设计选项卡。
   * @param {Boolean} [refreshGrid] 是否刷新属性表格，默认为false。
   */
  doApplyLayout: function(card, refreshGrid) {
    var designer = card.designer;

    function applyData(comp, isDesigner) {
      var labelName, node = comp.node,
        configs = node.data.configs;
      if (!isDesigner) {
        configs.x = comp.getLocalX().toString();
        configs.y = comp.getLocalY().toString();
      }
      configs.width = comp.getWidth().toString();
      configs.height = comp.getHeight().toString();
      configs.itemId = comp._itemId;
      if ((comp instanceof Ext.form.field.Base || comp instanceof Ext.form.Label) &&
        !(comp instanceof Ext.form.field.Hidden)) {
        if (comp.labelAlign == 'left')
          configs.labelAlign = '';
        else
          configs.labelAlign = comp.labelAlign;
      }
      if (comp.handleText) {
        labelName = Wb.namePart(comp.handleText);
        if (comp[labelName])
          configs[labelName] = comp[labelName];
        else
          delete configs[labelName];
      }
      if (node.data.text !== configs.itemId) {
        node.set('text', configs.itemId);
        node.commit();
      }
    }
    applyData(designer, true);
    designer.items.each(function(comp) {
      if (!comp.isMask) {
        applyData(comp);
      }
    });
    if (refreshGrid)
      Ide.refreshGrid(card.ownerCt.property);
  },
  /**
   * 更新选项卡中的所有子控件。
   * @param {Panel} card 布局设计选项卡。
   */
  updateLayout: function(card) {
    var subNode, comp = card.designer,
      node = card.node;

    Ext.suspendLayouts();
    try {
      Ide.render(card, node, true);
      comp = card.designer;
      node.eachChild(function(node) {
        Ide.render(comp, node);
      });
      comp.items.each(function(item) {
        //如果绑定的节点已经删除则删除控件
        subNode = item.node;
        if (subNode && subNode.parentNode != node) {
          comp.remove(item);
          comp.remove(item.bindMask);
        }
      });
      Ide.loadProps(comp, true);
    } finally {
      Ext.resumeLayouts(true);
    }
  },
  findCompFromNode: function(card, node) {
    var comp = null;
    card.items.each(function(item) {
      if (item.node == node) {
        comp = item;
        return false;
      }
    });
    return comp;
  },
  setConfigs: function(comp, configs, meta) {
    var val;
    Wb.each(meta.configs, function(key, value) {
      if (value.method) {
        val = configs[key];
        if (val) {
          if (value.type == 'exp')
            val = parseInt(val, 10);
          else if (value.type == 'expBool')
            val = val == 'true';
          else if (value.type == 'glyph')
            val = parseInt(val, 16);
        } else val = value.defaultValue;
        if (!Wb.equals(comp[key], val))
          comp[value.method](val);
      }
    });
  },
  loadConfigs: function(props, configs, meta) {
    var val;
    Wb.each(meta.configs, function(key, value) {
      if (value.method && configs[key]) {
        val = configs[key];
        if (val) {
          if (value.type == 'exp')
            val = parseInt(val, 10);
          else if (value.type == 'expBool')
            val = val == 'true';
        }
        props[key] = val;
      }
    });
  },
  /*把值强制转换为字符串*/
  valueToString: function(obj) {
    var newObj = {};
    Wb.each(obj, function(k, v) {
      if (Ext.isString(v))
        newObj[k] = v;
      else
        newObj[k] = Wb.encode(v);
    });
    return newObj;
  },
  /*根据表格的数据源自动生成列模型*/
  createColumns: function() {
    var node = app.getNode(),
      baseNode, storeNode, editor, storeName, url, itemId, params, firstRow, editable;

    if (!node || node.data.type != 'grid') {
      Wb.warn('请选择1个表格控件。');
      return;
    }
    if (node.findChild('text', 'columns')) {
      Wb.warn('该表格的列已经存在。');
      return;
    }
    editable = Wb.parseBool(node.data.configs.editable);
    storeName = node.data.configs.store;
    if (storeName) {
      storeName = storeName.substring(4);
      baseNode = node.getOwnerTree().getRootNode().firstChild;
    } else {
      storeName = 'store';
      baseNode = node;
    }
    storeNode = baseNode.findChild('text', storeName);
    url = storeNode ? storeNode.data.configs.url : null;
    if (!url) {
      Wb.warn('未设置表格关联store的url属性。');
      return;
    }
    Wb.promptText('设置参数 - 自动生成列模型', function(value, win) {
      if (value == '(无)')
        value = null;
      if (value) {
        try {
          params = Wb.decode(value);
        } catch (e) {
          Wb.error('参数无效，参数应该为有效的JSON格式。');
          return;
        }
      }
      Wb.request({
        url: url,
        params: params,
        success: function(resp) {
          var respObject, columns, columnsNode;
          try {
            respObject = Wb.decode(resp.responseText);
          } catch (e) {
            Wb.error('表格数据源无效或参数错误。');
            return;
          }
          columns = respObject.columns;
          columnsNode = {
            text: 'columns',
            type: 'array',
            iconCls: 'ja_icon',
            expanded: true,
            children: [],
            configs: {
              itemId: 'columns'
            }
          };
          if (!columns) {
            //把首行结果作为列模型
            if (Ext.isArray(respObject) && respObject.length)
              firstRow = respObject[0];
            else if (respObject.rows && respObject.rows.length)
              firstRow = respObject.rows[0];
            if (firstRow) {
              columns = [];
              Wb.each(firstRow, function(k) {
                columns.push({
                  dataIndex: k
                });
              });
            }
          }
          Wb.each(columns, function(col) {
            if (col.hidden)
              return;
            itemId = (col.dataIndex || col.xtype || 'empty') + 'Col';
            var newCol = {
              text: itemId,
              type: 'column',
              iconCls: 'column_icon',
              children: [],
              configs: app.valueToString(Ext.copyTo({
                itemId: itemId
              }, col, 'align,autoWrap,dataIndex,keyName,showInMenu,text,width,xtype'))
            };
            if (editable && col.editor && col.category != 'blob') {
              editor = app.controlDefines[col.editor.xtype];
              if (editor) {
                newCol.expanded = true;
                newCol.children.push({
                  text: 'editor',
                  type: editor.type,
                  iconCls: editor.iconCls,
                  children: [],
                  configs: app.valueToString(Ext.copyTo({
                    itemId: 'editor'
                  }, col.editor, 'maxValue,minValue,maxLength,allowBlank,keyName,readOnly,decimalPrecision,height'))
                });
              }
            }
            columnsNode.children.push(newCol);
          });
          //如果表格可编辑添加editor
          Wb.append(columnsNode, node);
          Ide.lastCreateColParams = value;
          app.setModified();
          win.close();
        }
      });
    }, {
      iconCls: 'column_icon',
      value: Ide.lastCreateColParams || '(无)'
    });
  },
  /*根据数据源自动生成编辑控件*/
  createEditors: function() {
    Wb.run({
      url: 'module-selector',
      single: true,
      success: function(scope) {
        scope.win.addDocked({
          xtype: 'toolbar',
          itemId: 'paramBar',
          dock: 'top',
          items: ['参数：', {
            xtype: 'textfield',
            itemId: 'paramText',
            value: Ide.lastCreateColParams || '(无)',
            flex: 1
          }]
        });
        scope.hideHandler = function() {
          delete scope.hideHandler;
          scope.win.removeDocked(scope.win.down('#paramBar'));
        };
        scope.show(function(value, win) {
          var param, paramText = win.down('#paramText').getValue();
          if (paramText == '(无)')
            paramText = null;
          if (paramText) {
            try {
              param = Wb.decode(paramText);
            } catch (e) {
              Wb.error('参数无效，参数应该为有效的JSON格式。');
              return;
            }
          }
          Wb.request({
            url: value,
            params: param,
            success: function(resp) {
              var firstRow, editor, config, respObject, columns, isAbs, colCount, height, hasMulLine, offsetY = 0,
                width = 240,
                x = 0,
                y = 0,
                anchorRight = app.anchorRightBtn.pressed,
                editorNodes = [],
                node = app.getNode();

              try {
                respObject = Wb.decode(resp.responseText);
              } catch (e) {
                Wb.error('选择的模块不是有效的数据源或参数错误。');
                return;
              }
              columns = respObject.columns;
              if (!columns) {
                //把首行结果作为列模型
                if (Ext.isArray(respObject) && respObject.length)
                  firstRow = respObject[0];
                else if (respObject.rows && respObject.rows.length)
                  firstRow = respObject.rows[0];
                if (firstRow) {
                  columns = [];
                  Wb.each(firstRow, function(k) {
                    columns.push({
                      dataIndex: k
                    });
                  });
                }
              }
              //计算绝对布局控件的列数和宽度
              isAbs = node.data.configs.layout == 'absolute';
              if (isAbs) {
                colCount = parseInt(node.data.configs.width / 264, 10) || 1;
                if (colCount == 1 && node.data.configs.width)
                  width = Ext.Number.snap(node.data.configs.width - 48, 8);
              }
              Wb.each(columns, function(col) {
                if (col.hidden)
                  return;
                if (col.editor || col.blobEditor) {
                  if (col.blobEditor)
                    editor = app.controlDefines.blob;
                  else
                    editor = app.controlDefines[col.editor.xtype];
                  if (editor) {
                    config = Ext.copyTo({
                      itemId: col.dataIndex
                    }, col.editor || col.blobEditor, 'maxValue,minValue,maxLength,allowBlank,keyName,readOnly,decimalPrecision,height');
                    config.fieldLabel = col.text;
                    if (anchorRight)
                      config.labelAlign = 'right';
                    if (isAbs) {
                      if (x % colCount === 0) {
                        x = 0;
                        y++;
                        if (hasMulLine) {
                          offsetY += 136;
                          hasMulLine = false;
                        }
                      }
                      x++;
                      if (col.editor && col.editor.xtype == 'textarea') {
                        hasMulLine = true;
                        height = 160;
                      } else
                        height = 22;
                      Wb.apply(config, {
                        x: 16 + (x - 1) * 264,
                        y: 16 + (y - 1) * 40 + offsetY,
                        width: width,
                        height: height
                      });
                    }
                    editorNodes.push({
                      text: col.dataIndex,
                      type: editor.type,
                      iconCls: editor.iconCls,
                      children: [],
                      configs: app.valueToString(config)
                    });
                  }
                }
              });
              node.expand();
              Wb.append(editorNodes, node);
              app.lastCreateColParams = paramText;
              app.setModified();
              win.close();
            }
          });
        }, '设置数据源和参数 - 自动添加编辑控件');
      }
    });
  },
  /**
   * 根据节点数据创建或更新在指定容器内的组件。
   * @param {Panel} card 容器。
   * @param {NodeInterface} node 节点对象。
   * @param {Boolean} [isDesigner] 是否是设计器。
   */
  render: function(card, node, isDesigner) {
    var props = {},
      comp, autoScroll,
      controlData = Ide.getMetaControl(node).data,
      general = controlData.general,
      configWidth = parseInt(general.width, 10) || 120,
      configHeight = parseInt(general.height, 10) || 22,
      configs = node.data.configs;

    comp = Ide.findCompFromNode(card, node);
    if (!isDesigner) {
      Wb.each(['x', 'y'], function(name) {
        if (configs[name])
          props[name] = parseInt(configs[name], 10);
      });
      if (props.x === undefined)
        props.x = 8;
      if (props.y === undefined)
        props.y = 8;
    }
    Wb.each(['width', 'height'], function(name) {
      if (configs[name])
        props[name] = parseInt(configs[name], 10);
    });
    if (props.width === undefined && configWidth)
      props.width = isDesigner ? 480 : configWidth;
    if (props.height === undefined && configHeight)
      props.height = isDesigner ? 320 : configHeight;
    Ext.copyTo(props, configs, ['icon', 'iconCls', 'labelAlign', 'text', 'fieldLabel', 'title']);
    //更新控件
    if (comp) {
      Ext.suspendLayouts();
      try {
        comp._itemId = configs.itemId;
        Ide.setConfigs(comp, configs, controlData); //配置用户自定义项
        if (comp.setIcon && !Wb.equals(comp.icon, props.icon))
          comp.setIcon(props.icon);
        if (comp.setIconCls && !Wb.equals(comp.iconCls, props.iconCls))
          comp.setIconCls(props.iconCls);
        if (!Wb.equals(comp.labelAlign, props.labelAlign))
          Ide.setLabelAlign(comp, props.labelAlign);
        if (comp.setText && !Wb.equals(comp.text, props.text))
          comp.setText(props.text);
        if (comp.setTitle && !Wb.equals(comp.title, props.title))
          comp.setTitle(props.title);
        if (comp.setFieldLabel && !Wb.equals(comp.fieldLabel, props.fieldLabel))
          comp.setFieldLabel(props.fieldLabel);
        if (comp.header && comp.header.hidden !== Wb.isEmpty(props.title) && general.xtype != 'window')
          comp.header.setVisible(comp.header.hidden);
        if (!isDesigner) {
          if (comp.setLocalX && comp.getLocalX() !== props.x) {
            comp.setLocalX(props.x);
            comp.bindMask.setLocalX(props.x);
          }
          if (comp.setLocalY && comp.getLocalY() !== props.y) {
            comp.setLocalY(props.y);
            comp.bindMask.setLocalY(props.y);
          }
        }
        if (comp.setWidth && comp.getWidth() !== props.width) {
          comp.setWidth(props.width);
          if (!isDesigner)
            comp.bindMask.setWidth(props.width);
        }
        if (comp.setHeight && comp.getHeight() !== props.height) {
          comp.setHeight(props.height);
          if (!isDesigner)
            comp.bindMask.setHeight(props.height);
        }
        if (comp.bindMask)
          Ide.updateLabel(comp);
        if (isDesigner) {
          if (general.xtype == 'window') {
            comp.down('toolbar').setVisible(configs.dialog == 'true' || configs.editWin == 'true' || configs.buttons);
          }
          autoScroll = configs.autoScroll === 'true';
          if (comp.autoScroll !== autoScroll)
            comp.setAutoScroll(autoScroll);
        }
      } finally {
        Ext.resumeLayouts(true);
      }
    }
    //创建控件
    else {
      props._itemId = configs.itemId;
      props.handleText = general.handleText;
      Ide.loadConfigs(props, configs, controlData); //配置用户自定义项
      if (isDesigner) {
        props.xtype = 'panel';
        props.header = {
          height: 25,
          style: 'padding: 4px 5px 4px 5px;'
        };
        if (general.xtype != 'window' && !props.title)
          props.header.hidden = true;
        if (configs.autoScroll === 'true')
          props.autoScroll = true;
        props.cls = 'wb_design';
        props.bodyStyle = 'background-color:white;background-image:url(wb/images/app/dot.png);';
        if (Ext.String.startsWith(configs.layout, '@'))
          props.layout = Wb.decode(configs.layout.substring(1));
        else
          props.layout = configs.layout;
        props.plugins = {
          ptype: 'wbselector'
        };
        props.resizable = {
          handles: 's e se',
          pinned: true,
          widthIncrement: 8,
          heightIncrement: 8,
          listeners: {
            resize: function() {
              var me = this;
              Ide.loadProps(me.target, true);
              Ide.setModified();
            }
          }
        };
        props.listeners = {
          afterrender: {
            single: true,
            fn: function(me) {
              Ide.loadProps(me);
              me.mon(me.body, {
                scope: me.body,
                scroll: function() {
                  var me = this,
                    x = me.dom.scrollLeft,
                    y = me.dom.scrollTop;
                  me.setStyle('background-position', (-x % 8) + 'px ' + (-y % 8) + 'px');
                  //模拟兼容background-attachment:local效果，调整网格线位置
                }
              });
              me.mon(me.el, {
                scope: me,
                mousedown: function(e) {
                  var me = this;
                  if (Wb.fromPanel(me, e)) {
                    Ide.selectAll(me, false);
                    Ide.loadProps(me);
                  }
                  me.ownerCt.focus();
                  if (Wb.getSelText())
                    Wb.clearSelText();
                }
              });
              new Ext.dd.DropTarget(
                me.body.dom, {
                  ddGroup: 'controlList',
                  notifyDrop: function(d, e, data) {
                    Ide.addDesignComp(me, data.records[0],
                      e.getX() + me.body.dom.scrollLeft - me.body.getLeft(),
                      e.getY() + me.body.dom.scrollTop - me.body.getTop());
                  }
                });
            }
          }
        };
      } else {
        props.listeners = {
          focus: function(me) {
            if (me.blur)
              me.blur();
          }
        };
        //强制创建boxlabel，否则updateBoxLabel将不可用
        if ((general.xtype == 'checkbox' || general.xtype == 'radio') && !props.boxLabel) {
          props.boxLabel = ' ';
          props.listeners.afterrender = {
            single: true,
            fn: function(me) {
              me.setBoxLabel('');
            }
          };
        }
      }
      props.tabIndex = -1;
      if (!props.xtype)
        props.xtype = general.xtype;
      props.node = node;
      if (general.designXtype)
        props.xtype = general.designXtype;
      else if (!props.xtype || general.design === false) {
        //非可显示控件
        props.xtype = 'component';
        props.style = 'background:white;border:1px solid #bbb;';
        props.width = configWidth;
        props.height = configHeight;
      }
      if (general.xtype == 'window') {
        Ext.apply(props, {
          isXWin: true,
          padding: '0 5 0 5',
          bbar: {
            hidden: configs.dialog != 'true' && configs.editWin != 'true' && !configs.buttons,
            height: 32
          }
        });
      }
      comp = card.add(props);
      if (isDesigner)
        comp.ownerCt.designer = comp;
      else
        Ide.addMask(card, comp);
    }
  },
  /**
   * 在设计器中添加控件。
   * @param {Container} designer 设计器。
   * @param {NodeInterface} control 添加的控件。
   * @param {Number} 控件的X坐标。
   * @param {Number} 控件的Y坐标。
   */
  addDesignComp: function(designer, control, x, y) {
    var configs, node,
      general = control.data.general;
    configs = {
      node: designer.node,
      x: Ext.Number.snap(x, 8),
      y: Ext.Number.snap(y, 8),
      width: general.width,
      height: general.height
    };
    node = Ide.addControl(control, false, configs);
    Ide.doApplyLayout(designer.ownerCt);
    Ide.updateLayout(designer.ownerCt);
    Ide.selectAll(designer, false, Ide.findCompFromNode(designer, node).bindMask);
  },
  /**
   * 在控件上添加mask，用以拖动和调整控件。
   * @param {Container} card 被添加控件的容器对象。
   * @param {Component} component 添加的控件，mask将加在该控件上。
   */
  addMask: function(card, component) {
    card.add({
      xtype: 'box',
      isMask: true,
      style: (component instanceof Ext.form.field.Base || component instanceof Ext.form.FieldContainer ||
        component instanceof Ext.Img || component instanceof Ext.form.Label || component.xtype == 'component' ||
        component.xtype == 'container') ? 'border:1px dotted #bbb;' : '',
      cls: 'x-unselectable ide_mask',
      html: '<span></span>',
      draggable: {
        listeners: {
          drag: Ide.dragComp,
          mousedown: Ide.dragMousedown
        }
      },
      listeners: {
        afterrender: {
          single: true,
          fn: function(me) {
            me.label = me.el.down('span');
            me.card = card;
            me.bindComp = component;
            component.bindMask = me;
            Ide.updateLabel(component);
            Ide.fitComp(component, me);
            me.mon(me.el, {
              scope: me,
              dblclick: function(e, t) {
                var node = this.bindComp.node,
                  moduleCard = this.card.ownerCt.ownerCt;
                moduleCard.setActiveTab(moduleCard.designCard);
                node.getOwnerTree().selectPath(node.getPath('text'), 'text');
              },
              mousedown: function(e, t) {
                if (Ide.isResizer(e.target))
                  return;
                var me = this;
                if (e.shiftKey) {
                  Ide.doSelect(me, !me.isSelected);
                } else {
                  if (!me.isSelected)
                    Ide.selectAll(me.card, false, me);
                }
                Ide.loadProps(me.card);
              }
            });
          }
        }
      }
    });
  },
  /**
   * 判断设计器中指定对象是否是Resizer。
   * @param {HTMLElement} el 需要判断的HTML元素。
   * @return {Boolean} true是Resizer，否则不是。
   */
  isResizer: function(el) {
    return Ext.fly(el).hasCls('x-resizable-handle');
  },
  /**
   * 调整控件大小至Resizer大小。
   * @param {Resizer} resizer Resizer对象。
   */
  fitResizer: function(resizer) {
    var target = resizer.target;
    Wb.setBox(target, target.bindComp);
    target.el.setStyle('line-height', target.getHeight() + 'px');
    Ide.loadProps(target.ownerCt, true);
    Ide.setModified();
  },
  /**
   * 调整Resizer大小至控件大小。
   * @param {Component} component 控件对象。
   */
  fitComp: function(component) {
    var mask = component.bindMask;
    if (Wb.setBox(component, mask))
      mask.el.setStyle('line-height', component.height + 'px');
  },
  /**
   * 拖动控件句柄。
   * @param {Dragger} me Dragger。
   */
  dragComp: function(me) {
    var bindComp, comp = me.comp,
      xy = me.lastXY,
      fx = Ext.Number.snap(xy[0] - me.startXY[0], 8),
      fy = Ext.Number.snap(xy[1] - me.startXY[1], 8);

    Ext.suspendLayouts();
    comp.card.items.each(function(item) {
      if (item.isSelected) {
        item.setLocalXY(item.originXY[0] + fx, item.originXY[1] + fy);
        bindComp = item.bindComp;
        bindComp.setLocalXY(bindComp.originXY[0] + fx, bindComp.originXY[1] + fy);
      }
    });
    Ide.loadProps(comp.card, true);
    Ext.resumeLayouts(true);
    Ide.setModified();
  },
  /**
   * 拖动控件Mousedown句柄。
   * @param {Dragger} me Dragger。
   */
  dragMousedown: function(me, e) {
    if (Ide.isResizer(e.target))
      return false;
    var comp = me.comp;
    if (!comp.isSelected)
      return false;
    me.startXY = me.lastXY;
    comp.card.items.each(function(item) {
      item.originXY = item.getLocalXY();
    });
  },
  /**
   * 在设计器中设置控件的选择状态。
   * @param {Component} comp 需要选择的控件，如果为空选择全部控件。
   * @param {Boolean} selected 是否选择，否则为取消选择。
   */
  doSelect: function(comp, selected) {
    if (comp.isSelected === selected)
      return;
    comp.isSelected = selected;
    if (comp.resizer) {
      var dot, resizer = comp.resizer,
        positions = resizer.possiblePositions;
      Ext.suspendLayouts();
      Wb.each(positions, function(key, value) {
        dot = resizer[value];
        if (selected)
          dot.show();
        else
          dot.hide();
      });
      Ext.resumeLayouts(true);
    } else if (selected) {
      comp.initResizable({
        handles: 'all',
        pinned: true,
        widthIncrement: 8,
        heightIncrement: 8,
        listeners: {
          resize: Ide.fitResizer
        }
      });
    }
  },
  /**
   * 加载指定设计器容器内所选择控件或容器的属性。
   * @param {Container} owner 设计器容器。
   * @param {Boolean} forceLoad 是否强制加载属性。默认为false。
   */
  loadProps: function(owner, forceLoad) {
    if (!owner.rendered) return;
    var firstComp, handleText, noLabel, newValue, count = 0,
      comps = owner.ownerCt.comps,
      toolbar = comps.toolbar;
    owner.items.each(function(item) {
      if (item.isMask && item.isSelected) {
        count++;
        if (!firstComp)
          firstComp = item.bindComp;
      }
    });
    if (count === 0)
      firstComp = owner;
    if (count > 1)
      newValue = count;
    else
      newValue = firstComp;
    if (!forceLoad && toolbar.curPropComp === newValue)
      return;
    toolbar.curPropComp = newValue;
    Ext.suspendLayouts();
    try {
      toolbar.allowChange = false;
      toolbar.items.each(function(item) {
        item.setDisabled(count > 1);
      });
      if (count > 1) {
        Wb.setValue(toolbar, {
          itemId: count + ' 项',
          text: '',
          x: '',
          y: '',
          width: '',
          height: ''
        });
      } else {
        handleText = firstComp.handleText;
        noLabel = !Wb.getBool(handleText);
        if (comps.text.disabled != noLabel)
          comps.text.setDisabled(noLabel);
        if (comps.x.disabled != (count === 0))
          comps.x.setDisabled(count === 0);
        if (comps.y.disabled != (count === 0))
          comps.y.setDisabled(count === 0);
        Wb.setValue(toolbar, {
          itemId: firstComp._itemId,
          text: handleText ? firstComp[Wb.namePart(handleText)] : '',
          x: firstComp.getLocalX(),
          y: firstComp.getLocalY(),
          width: firstComp.getWidth(),
          height: firstComp.getHeight()
        });
      }
    } finally {
      Ext.resumeLayouts(true);
      toolbar.allowChange = true;
    }
  },
  /**
   * 更新设计器控件的mask上显示的标签。如果控件无任何可显示的标签，则在mask上显示itemId。
   * @param {Component} comp 控件对象。
   */
  updateLabel: function(comp) {
    if (!comp.bindMask)
      return;
    var str = comp._itemId;
    if (comp.handleText) {
      var text = comp[Wb.namePart(comp.handleText)];
      if (text)
        str = '';
    }
    if (comp.bindMask.label.innerLabel !== str) {
      comp.bindMask.label.innerLabel = str;
      comp.bindMask.label.update(str);
    }
  },
  /**
   * 在设计器中选择或取消选择所有的控件。
   * @param {Container} owner 设计器容器。
   * @param {Boolean} selected 是否是选择或取消选择。
   * @param {Component} [exceptComp] 例外控件，该控件将被选择。
   */
  selectAll: function(owner, selected, exceptComp) {
    Ext.suspendLayouts();
    owner.items.each(function(item) {
      if (item.isMask) {
        if (item == exceptComp)
          Ide.doSelect(item, true);
        else
          Ide.doSelect(item, selected);
      }
    });
    Ide.loadProps(owner);
    Ext.resumeLayouts(true);
  },
  /**
   * 同步设计视图树节点和选项卡之间的数据。
   * @param {NodeInterface[]} nodes 同步的节点列表。
   */
  syncNodes: function(nodes) {
    var cardNode, path, card = Ide.activeCard;
    if (!Ext.isArray(nodes))
      nodes = [nodes];
    card.items.each(function(subCard) {
      Wb.each(nodes, function(node) {
        cardNode = subCard.node;
        if (cardNode == node || cardNode && cardNode.isAncestor(node)) {
          path = Ide.getNodePath(cardNode);
          subCard.tab.setTooltip(path);
          if (subCard.layoutCard) {
            subCard.setTitle(cardNode.data.text);
          } else {
            subCard.setTitle(cardNode.data.text + '.' + subCard.itemName);
            subCard.funcBtn.setText(path);
          }
          return false;
        }
      });
    });
  },
  /**
   * 当前模块文件卡中对象itemId更改时同步更新绑定的名称。
   * @param {String} oldName 原名称。
   * @param {String} newName 新名称。
   */
  syncBindRef: function(oldName, newName) {
    var configs, items, card = Ide.activeCard,
      tree = card.tree;
    oldName = 'app.' + oldName;
    newName = 'app.' + newName;
    tree.getRootNode().cascadeBy(function(node) {
      if (node.getDepth() > 0) {
        configs = Ide.getMetaControl(node).data.configs;
        items = node.data.configs;
        Wb.each(items, function(key, value) {
          if (configs[key] && configs[key].type == 'expBind' && value == oldName) {
            items[key] = newName;
          }
        });
      }
    });
  },
  /**
   * 在当前编辑器中跳转到指定行。
   */
  gotoLine: function() {
    var editor = Ide.getEditor();
    if (editor) {
      Wb.prompt({
        title: '跳转到行',
        items: {
          fieldLabel: '行号',
          xtype: 'numberfield',
          allowDecimals: false,
          itemId: 'line',
          saveKeyname: 'sys.ide.gotoLine',
          minValue: 1
        },
        handler: function(values, win) {
          values.line--;
          editor.setCursor({
            line: values.line,
            ch: 0
          });
          var height = editor.getScrollInfo().clientHeight,
            coords = editor.charCoords({
              line: values.line,
              ch: 0
            }, "local");
          editor.scrollTo(null, (coords.top + coords.bottom - height) / 2);
          win.close();
          editor.focus();
        }
      });
    } else Wb.warn('当前不在编辑状态。');
  },
  /**
   * 记录选项卡和编辑框光标的位置，该位置信息用于位置导航。
   */
  recordActivity: function() {
    if (Ide.stopRecNav)
      return;
    var card = Ide.activeCard,
      subCard, lastInfo, info = {
        card: card.id
      };
    if (!card) return;
    if (card.cardType == 'module') {
      subCard = card.getActiveTab();
      if (!subCard)
        return;
      editor = subCard.editor;
      info.subCard = subCard.id;
    } else editor = card.editor;
    if (editor) {
      var scroll = editor.getScrollInfo();
      info.cursor = editor.getCursor();
      info.left = scroll.left;
      info.top = scroll.top;
    }
    lastInfo = Ide.backList[Ide.backList.length - 1];
    if (!lastInfo || lastInfo.card != info.card || lastInfo.subCard != info.subCard || (editor &&
        ((Math.abs(info.cursor.ch - lastInfo.cursor.ch) > 200) ||
          (Math.abs(info.cursor.line - lastInfo.cursor.line) > 20)))) {
      if (Ide.backList.length > 49)
        Ide.backList.splice(0, 1);
      Ide.backList.push(info);
    } else if (editor) {
      //更新编辑器光标位置信息
      lastInfo.cursor = info.cursor;
      lastInfo.left = info.left;
      lastInfo.top = info.top;
    }
  },
  /**
   * 根据指定信息转到对应的选项卡或编辑框内光标。
   * @param {Object} info 选项卡或光标信息。
   * @return {Boolean} 是否导航成功，true成功，false失败。
   */
  navigate: function(info) {
    var card, subCard;
    card = Ext.getCmp(info.card);
    if (card)
      Ide.fileTab.setActiveTab(card);
    else return false;
    if (info.subCard) {
      subCard = Ext.getCmp(info.subCard);
      if (subCard) {
        card.setActiveTab(subCard);
        if (info.cursor) {
          subCard.editor.scrollTo(info.left, info.top);
          subCard.editor.setCursor(info.cursor);
          subCard.editor.focus();
        }
      } else return false;
    } else {
      if (info.cursor) {
        card.editor.scrollTo(info.left, info.top);
        card.editor.setCursor(info.cursor);
        card.editor.focus();
      }
    }
    return true;
  },
  /**
   * 依次返回到上次选项卡或光标位置。
   */
  back: function() {
    if (Ide.backList.length < 2)
      return;
    var info = Ide.backList.pop();
    if (info) {
      if (Ide.forwardList.length > 49)
        Ide.forwardList.splice(0, 1);
      Ide.forwardList.push(info);
    } else return;
    Ide.stopRecNav = true;
    while (Ide.backList.length > 0 && !Ide.navigate(Ide.backList[Ide.backList.length - 1])) {
      Ide.backList.pop();
    }
    Ide.stopRecNav = false;
  },
  /**
   * 依次前进到返回过的选项卡或光标位置。
   */
  forward: function() {
    var info;
    Ide.stopRecNav = true;
    while ((info = Ide.forwardList.pop())) {
      if (Ide.navigate(info))
        break;
    }
    Ide.stopRecNav = false;
    if (info) {
      if (Ide.backList.length > 49)
        Ide.backList.splice(0, 1);
      Ide.backList.push(info);
    }
  },
  /**
   * 根据点击对象设置激活的对象。
   */
  setActiveComp: function(e, target) {
    if (Ide.fileTree.el.isAncestor(target)) {
      Ide.activeCmp = 'file';
      if (Wb.getSelText())
        Wb.clearSelText();
    } else if (Ide.fileTab.el.isAncestor(target)) {
      if (Wb.getSelText() && Wb.hasNS('activeCard.tree.el.isAncestor', Ide) && Ide.activeCard.tree.el.isAncestor(target))
        Wb.clearSelText();
      var subCard, card = Ide.activeCard;
      //模块页面
      if (card && card.designCard) {
        subCard = card.getActiveTab();
        //设计页
        if (subCard == card.designCard || subCard.layoutCard)
          Ide.activeCmp = 'control';
        else Ide.activeCmp = 'file';
      } else
        Ide.activeCmp = 'file';
    }
  },
  /**
   * 添加全局事件。
   */
  addEvents: function() {
    var doc = Ext.getDoc();
    //根据点击的对象来确定当前激活的对象
    doc.on('click', app.setActiveComp);
    doc.on('contextmenu', app.setActiveComp);
    /*有输入焦点时忽略处理*/
    new Ext.KeyNav({
      target: doc,
      ignoreInputFields: true,
      beforeCall: function(e) {
        if (Wb.getSelText() || Wb.isModal())
          return false;
        if (e.ctrlKey && e.getKey() == e.A && !Ide.getDesigner()) {
          return false;
        }
      },
      del: Ide.remove,
      A: {
        ctrl: true,
        fn: Ide.doSelectAll
      },
      C: {
        ctrl: true,
        fn: Ide.copy
      },
      X: {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.remove();
          else
            Ide.cut();
        }
      },
      V: {
        ctrl: true,
        fn: Ide.paste
      },
      left: Ide.adjustPosSize,
      up: Ide.adjustPosSize,
      right: Ide.adjustPosSize,
      down: Ide.adjustPosSize
    });

    /*全局处理*/
    new Ext.KeyNav({
      target: doc,
      beforeCall: function(e) {
        var key = e.getKey();
        if (Wb.isModal() && !(key == e.K && e.ctrlKey && e.shiftKey)) {
          e.stopEvent();
          return false;
        }
      },
      Q: {
        ctrl: true,
        fn: Ide.run
      },
      O: {
        ctrl: true,
        fn: Ide.open
      },
      S: {
        ctrl: true,
        fn: function(e) {
          Ide.saveFile(e.shiftKey);
        }
      },
      L: {
        ctrl: true,
        shift: true,
        fn: Ide.searchFile
      },
      J: {
        ctrl: true,
        fn: function(e) {
          Ide.doAdd(e.shiftKey);
        }
      },
      K: {
        ctrl: true,
        shift: true,
        fn: function() {
          Ide.fillForm();
        }
      },
      U: {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.adjustZIndex();
          else
            Ide.setProperty();
        }
      },
      H: {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.searchAgain();
          else
            Ide.search();
        }
      },
      B: {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.setSQL();
          else
            Ide.setLayout();
        }
      },
      I: {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.toggleViewBtn.toggle();
          else
            Ide.toggleOutputsBtn.toggle();
        }
      },
      '0': {
        ctrl: true,
        fn: Ide.forward
      },
      '1': {
        ctrl: true,
        fn: function(e) {
          if (e.shiftKey)
            Ide.addAppTpl();
          else
            Ide.addFuncNote();
        }
      },
      '2': {
        ctrl: true,
        fn: Ide.addPropertyNote
      },
      '3': {
        ctrl: true,
        fn: Ide.addTodo
      },
      '4': {
        ctrl: true,
        fn: Ide.addWbRequest
      },
      '5': {
        ctrl: true,
        fn: Ide.gotoLine
      },
      '6': {
        ctrl: true,
        fn: Ide.toDesign
      },
      '7': {
        ctrl: true,
        fn: Ide.toggleRun
      },
      '8': {
        ctrl: true,
        fn: Ide.toggleEditor
      },
      '9': {
        ctrl: true,
        fn: Ide.back
      }
    });
  },
  /**
   * 获取当前的布局设计器对象。
   * @return {Panel} 设计器对象。如果当前无设计器对象则返回null。
   */
  getDesigner: function() {
    var subCard;
    if (Ide.activeCard && Ide.activeCard.cardType == 'module') {
      subCard = Ide.activeCard.getActiveTab();
      if (subCard.layoutCard)
        return subCard.designer;
    }
    return null;
  },
  /**
   * 转到模块编辑器的设计页面。
   */
  toDesign: function() {
    var card = Ide.activeCard;
    if (card && card.cardType == 'module')
      card.setActiveTab(card.designCard);
  },
  /**
   * 允许通过箭头键微调控件大小和位置。
   * @param {Event} e 事件对象。
   */
  adjustPosSize: function(e) {
    if (!e.ctrlKey && !e.shiftKey)
      return;
    var comp, pos, changed,
      designer = Ide.getDesigner();
    if (!designer)
      return;
    designer.items.each(function(item) {
      if (item.isSelected) {
        if (!changed)
          changed = true;
        comp = item.bindComp;
        switch (e.getKey()) {
          case 37:
            if (e.shiftKey) {
              item.setWidth(item.getWidth() - 1);
              comp.setWidth(comp.getWidth() - 1);
            } else {
              pos = item.getLocalX();
              item.setLocalX(--pos);
              pos = comp.getLocalX();
              comp.setLocalX(--pos);
            }
            break;
          case 38:
            if (e.shiftKey) {
              item.setHeight(item.getHeight() - 1);
              comp.setHeight(comp.getHeight() - 1);
            } else {
              pos = item.getLocalY();
              item.setLocalY(--pos);
              pos = comp.getLocalY();
              comp.setLocalY(--pos);
            }
            break;
          case 39:
            if (e.shiftKey) {
              item.setWidth(item.getWidth() + 1);
              comp.setWidth(comp.getWidth() + 1);
            } else {
              pos = item.getLocalX();
              item.setLocalX(++pos);
              pos = comp.getLocalX();
              comp.setLocalX(++pos);
            }
            break;
          case 40:
            if (e.shiftKey) {
              item.setHeight(item.getHeight() + 1);
              comp.setHeight(comp.getHeight() + 1);
            } else {
              pos = item.getLocalY();
              item.setLocalY(++pos);
              pos = comp.getLocalY();
              comp.setLocalY(++pos);
            }
            break;
        }
      }
    });
    if (changed) {
      Ide.loadProps(designer, true);
      Ide.setModified();
    }
  },
  /**
   * 设置节点的当前路径至oldPath属性。
   */
  setOldPath: function(nodes) {
    Wb.each(nodes, function(node) {
      node.data.oldPath = Ide.getPath(node);
    });
  },
  /**
   * 获取XWL模块数据。
   * @param {Panel} card 编辑模块所在的选项卡。
   * @return {String} 以JSON字符串描述的模块数据。
   */
  getXwlData: function(card) {
    var loadJS, inframe, tree = card.tree,
      root = tree.getRootNode(),
      data = Ext.copyTo({}, root.data, ['title', 'hidden', 'inframe', 'pageLink', 'iconCls']);
    if (card.commitChange)
      card.commitChange();
    inframe = Ide.getChildrenData(root, data);
    loadJS = data.children[0].configs.loadJS;
    if (!inframe && loadJS && (loadJS.indexOf('touch') != -1 || loadJS.indexOf('bootstrap') != -1))
      inframe = true;
    if (inframe) {
      //强制指定模块需在独立框架中运行
      data.inframe = true;
      root.set('inframe', true);
      root.commit();
    }
    return Wb.encode(data);
  },
  /**
   * 设置当前页状态为被更改，在页的标题前加“*”符，并添加isModified属性为true。
   */
  setModified: function(card) {
    if (!card)
      card = Ide.activeCard;
    if (!card.isModified) {
      Wb.setModified(card);
      Ide.setButtons();
    }
  },
  /**
   * 定义IDE工具类。
   */
  defineClasses: function() {
    Ext.define('Wb.ide.DragSelector', {
      requires: ['Ext.dd.DragTracker',
        'Ext.util.Region'
      ],
      alias: 'plugin.wbselector',
      init: function(panel) {
        this.panel = panel;
        panel.mon(panel, {
          beforecontainerclick: this.cancelClick,
          scope: this,
          render: {
            fn: this.onRender,
            scope: this,
            single: true
          }
        });
      },
      onRender: function() {
        this.tracker = new Ext.dd.DragTracker({
          panel: this.panel,
          el: this.panel.body,
          dragSelector: this,
          onBeforeStart: this.onBeforeStart,
          onStart: this.onStart,
          onDrag: this.onDrag,
          onEnd: this.onEnd
        });
        this.dragRegion = new Ext.util.Region();
      },
      onBeforeStart: function(e) {
        return Wb.fromPanel(this.panel, e);
      },
      onStart: function(e) {
        var dragSelector = this.dragSelector;
        this.dragging = true;
        dragSelector.fillRegions();
        dragSelector.getProxy().show();
      },
      cancelClick: function() {
        return !this.tracker.dragging;
      },
      onDrag: function(e) {
        var dragSelector = this.dragSelector,
          dragRegion = dragSelector.dragRegion,
          bodyRegion = dragSelector.bodyRegion,
          proxy = dragSelector.getProxy(),
          startXY = this.startXY,
          currentXY = this.getXY(),
          minX = Math.min(startXY[0], currentXY[0]),
          minY = Math.min(startXY[1], currentXY[1]),
          width = Math.abs(startXY[0] - currentXY[0]),
          height = Math.abs(startXY[1] - currentXY[1]),
          region, selected;

        Ext.apply(dragRegion, {
          top: minY,
          left: minX,
          right: minX + width,
          bottom: minY + height
        });
        dragRegion.constrainTo(bodyRegion);
        proxy.setRegion(dragRegion);
        var firstComp = null,
          count = 0;
        this.panel.items.each(function(item) {
          if (item.isMask) {
            region = item.el.getRegion();
            selected = dragRegion.intersect(region);
            Ide.doSelect(item, selected);
            if (selected) {
              firstComp = item;
              count++;
            }
          }
        });
        Ide.loadProps(this.panel);
      },
      onEnd: Ext.Function.createDelayed(function(e) {
        var dragSelector = this.dragSelector;
        this.dragging = false;
        dragSelector.getProxy().hide();
      }, 1),
      getProxy: function() {
        if (!this.proxy) {
          this.proxy = this.panel.body.createChild({
            tag: 'div',
            cls: 'x-view-selector'
          });
        }
        return this.proxy;
      },
      fillRegions: function() {
        var panel = this.panel;
        this.bodyRegion = panel.body.getRegion();
      }
    });
  },
  /**
   * 对指定列表中的节点的itemId重命名，以避免在所在层级名称重复。
   * @param {NodeInterface} parentNode 上级节点。
   * @param {NodeInterface[]} nodes 重命名的节点列表。
   * @param {Object} dh 拖动句柄。
   */
  autoRename: function(parentNode, nodes, dh) {
    var nameMap = {},
      newNames = [],
      firstNewName, renameCount = 0,
      index = 0;
    parentNode.eachChild(function(node) {
      if (Wb.indexOf(nodes, node) == -1)
        nameMap[node.data.text] = true;
    });
    Wb.each(nodes, function(node) {
      var oldName = node.data.text,
        newName = Wb.uniqueName(nameMap, oldName);
      if (oldName != newName) {
        if (!firstNewName)
          firstNewName = oldName;
        renameCount++;
      }
      nameMap[newName] = true;
      newNames.push(newName);
    });
    if (renameCount) {
      if (dh) {
        dh.wait = true;
        Wb.confirm((renameCount > 1 ? ('"' + firstNewName + '" 等 ' + renameCount + ' 项') : ('"' + firstNewName + '" ')) +
          '名称重复，确定对拖动的重名节点重命名吗？', [function() {
            dh.processDrop();
          }, function() {
            dh.cancelDrop();
          }]
        );
      } else {
        Ext.suspendLayouts();
        Wb.each(nodes, function(node) {
          node.data.configs.itemId = newNames[index];
          node.set('text', newNames[index]);
          node.commit();
          index++;
        });
        Ext.resumeLayouts(true);
      }
    }
  },
  /**
   * 获取指定节点的数据，并保存到指定的对象中。
   * @param {NodeInterface} node 节点。
   * @param {Object} data 节点数据保存到该对象。
   * @return 是否需要在独立框架中运行。
   */
  getChildrenData: function(node, data) {
    var childData, items, meta, inframe = false,
      savedItems, keys = ['configs', 'events'];
    data.children = [];
    node.eachChild(function(child) {
      meta = Ide.getMetaControl(child);
      if (!inframe && meta.data.general.tag &&
        (meta.data.general.tag.lib == 2 || meta.data.general.tag.lib == 3)) //touch&&bs
        inframe = true;
      childData = {
        type: child.data.type,
        expanded: child.isExpanded()
      };
      data.children.push(childData);
      Wb.each(keys, function(key) {
        savedItems = {};
        items = child.data[key];
        Wb.each(items, function(name, value) {
          if (!Wb.isEmpty(value))
            savedItems[name] = value;
        });
        if (!Ext.Object.isEmpty(savedItems))
          childData[key] = savedItems;
      });
      if (child.firstChild) {
        if (Ide.getChildrenData(child, childData))
          inframe = true;
      } else childData.children = [];
    });
    return inframe;
  },
  /**
   * 校验CodeMirror内脚本的合法性。
   * @param {Panel} card CodeMirror所在选项卡。
   */
  lintScript: function(card) {
    var path = card.path,
      fileExt = Wb.extractFileExt(path).toLowerCase();

    function lint(editor, subCard) {
      if (editor.needLint)
        editor.startLinting(editor);
      if (!(subCard && subCard.sourceCard)) {
        Ide.clearMarkers(path, subCard);
        Ide.getMarkers(editor, path, subCard);
      }
    }
    if (fileExt == 'js' || fileExt == 'ss' || fileExt == 'css')
      lint(card.editor);
    else if (fileExt == 'xwl') {
      card.items.each(function(t) {
        if (t.editor && (t.fileExt == 'js' || t.fileExt == 'ss' || t.fileExt == 'css'))
          lint(t.editor, t);
      });
    }
  },
  exportModules: function() {
    function setHint() {
      var win = this.up('window'),
        fileRangeHint, hint = '',
        dateRange = win.down('#dateRange').getValue();
      win.down('#modifyDate').setDisabled(dateRange != 3);
      fileRangeHint = win.down('#fileRange').getValue() ? '全部' : '选择的';
      switch (dateRange) {
        case 0:
          hint = '模块';
          break;
        case 1:
          hint = '今天修改的模块';
          break;
        case 2:
          hint = '从昨天到今天修改的模块';
          break;
        case 3:
          hint = '从指定日期到今天修改的模块';
          break;
      }
      hint = '导出' + fileRangeHint + hint;
      win.down('#hintLabel').setValue(hint);
    }

    function getFileRange() {
      var nodes, result = []; //默认为空表示全部
      if (!win.down('#fileRange').getValue()) {
        //获得选择的目录或文件
        nodes = Ide.fileTree.getSelection();
        Wb.each(nodes, function(node) {
          result.push(Ide.getPath(node));
        });
      }
      return result;
    }

    var win = Wb.prompt({
      title: '导出模块包',
      iconCls: 'export_icon',
      items: [{
        xtype: 'combo',
        itemId: 'filename',
        fieldLabel: '文件名称',
        allowBlank: false,
        saveKeyname: 'sys.ide.module.exportFileName',
        pickKeyname: 'sys.ide.module.exportFileName',
        store: [],
        value: 'app(' + Wb.format(new Date(), 'Y-m-d') + ')'
      }, {
        xtype: 'radiogroup',
        fieldLabel: '导出范围',
        itemId: 'fileRange',
        saveKeyname: 'sys.ide.module.fileRange',
        items: [{
          boxLabel: '选择的文件或目录',
          checked: true
        }, {
          boxLabel: '全部文件或目录'
        }],
        listeners: {
          change: setHint
        }
      }, {
        xtype: 'radiogroup',
        fieldLabel: '修改日期',
        itemId: 'dateRange',
        saveKeyname: 'sys.ide.module.dateRange',
        items: [{
          boxLabel: '不限',
          checked: true
        }, {
          boxLabel: '今天'
        }, {
          boxLabel: '昨天'
        }, {
          boxLabel: '指定'
        }, {
          xtype: 'datefield',
          allowBlank: false,
          itemId: 'modifyDate',
          disabled: true,
          saveKeyname: 'sys.ide.module.exportSpecifyDate',
          width: 110
        }],
        listeners: {
          change: setHint
        }
      }, {
        hideEmptyLabel: false,
        itemId: 'hintLabel',
        xtype: 'displayfield',
        value: '导出选择的模块'
      }],
      handler: function(values, win) {
        var lastModified;
        switch (values.dateRange) {
          case 0:
            lastModified = -1;
            break;
          case 1:
            lastModified = Ext.Date.clearTime(new Date());
            break;
          case 2:
            lastModified = Ext.Date.add(Ext.Date.clearTime(new Date()), Ext.Date.DAY, -1);
            break;
          case 3:
            lastModified = values.modifyDate;
            break;
        }
        Wb.download('m?xwl=dev/ide/export-modules', {
          filename: values.filename,
          fileRange: getFileRange(),
          lastModified: lastModified
        });
        win.close();
      }
    });
  },
  importModules: function() {
    Wb.run({
      url: 'upload-dialog',
      single: true,
      success: function(app) {
        app.upload({
          url: 'm?xwl=dev/ide/import-modules',
          iconCls: 'import_icon',
          title: '导入模块包',
          success: function() {
            Wb.reload(Ide.fileTree);
          }
        });
        app.winWidth = app.win.getWidth();
        app.winHeight = app.win.getHeight();
        app.win.setWidth(500);
        app.win.setHeight(app.win.getHeight() + 30);
        app.form1.add({
          xtype: 'checkboxgroup',
          itemId: 'importOptionsGroup',
          x: 20,
          y: 60,
          items: [{
            boxLabel: '导入 URL 捷径',
            itemId: 'mergeUrl',
            checked: !Ide.importUrlChecked,
            listeners: {
              change: function(me, val) {
                Ide.importUrlChecked = !val;
              }
            }
          }, {
            boxLabel: '覆盖模块权限',
            itemId: 'mergePerm',
            checked: Ide.importPermChecked,
            listeners: {
              change: function(me, val) {
                Ide.importPermChecked = val;
              }
            }
          }, {
            boxLabel: '覆盖目录配置',
            itemId: 'mergeFolder',
            checked: Ide.importFolderConfig,
            listeners: {
              change: function(me, val) {
                Ide.importFolderConfig = val;
              }
            }
          }, {
            boxLabel: '覆盖存在文件',
            itemId: 'overwritten',
            checked: !Ide.importOverwritten,
            listeners: {
              change: function(me, val) {
                Ide.importOverwritten = !val;
              }
            }
          }]
        });
        //在窗口隐藏时还原
        app.win.mon(app.win, {
          hide: {
            single: true,
            fn: function(me) {
              app.win.setWidth(app.winWidth);
              app.win.setHeight(app.winHeight);
              app.form1.down('#importOptionsGroup').destroy();
            }
          }
        });
      }
    });
  },
  /**
   * 执行保存操作，保存当前打开且被修改的文件。
   */
  save: function() {
    Ide.saveFile();
  },
  /**
   * 执行保存全部操作，保存全部打开且被修改的文件。
   */
  saveAll: function() {
    Ide.saveFile(true);
  },
  /**
   * 保存文件。
   * @param {Boolean} isAll 是否保存全部，默认为false。
   * @param {Function} [callback] 保存完成之后的回调函数。
   * @param {Boolean} [noConfirm] 如果文件已经被修改是否不提示覆盖，默认为false。
   */
  saveFile: function(isAll, callback, noConfirm) {
    if (isAll && Ide.saveAllBtn.disabled || !isAll && Ide.saveBtn.disabled) {
      Ext.callback(callback);
      return;
    }
    var data = [],
      content, charsetBtn, charset, fileExt;
    Ide.fileTab.items.each(function(card) {
      if (card.isModified && (isAll || card == Ide.activeCard)) {
        fileExt = Wb.extractFileExt(card.path).toLowerCase();
        if (fileExt == 'xwl')
          content = Ide.getXwlData(card);
        else
          content = card.editor.getValue();
        charsetBtn = card.down('#funcBtn');
        if (fileExt == 'xwl')
          charset = 'utf-8';
        else if (!charsetBtn)
          charset = null;
        else {
          charset = charsetBtn.text;
          if (charset == 'default')
            charset = null;
        }
        data.push({
          file: card.path,
          lastModified: card.lastModified,
          content: content,
          charset: charset
        });
      }
    });
    if (data.length === 0) {
      Ext.callback(callback);
      return;
    }
    Wb.request({
      url: 'm?xwl=dev/ide/save',
      jsonData: data,
      timeout: -1,
      params: {
        noConfirm: Wb.getBool(noConfirm, false)
      },
      showError: false,
      success: function(resp) {
        var respObj = Wb.decode(resp.responseText),
          index = 0;
        Ide.fileTab.items.each(function(card) {
          if (card.isModified && (isAll || card == Ide.activeCard)) {
            Wb.unModified(card);
            if (card.cardType != 'module') //module在提交前已经设置
              card.editor.savedText = card.editor.getValue();
            card.lastModified = Wb.strToDate(respObj[index]);
            index++;
            Ide.lintScript(card);
          }
        });
        Ide.setButtons();
        Ext.callback(callback);
      },
      failure: function(resp) {
        var msg = resp.responseText,
          errMsg = Wb.getError(msg, 101);
        if (errMsg) {
          Wb.confirm(errMsg, function() {
            Ide.saveFile(isAll, callback, true);
          });
        } else
          Wb.except(resp);
      }
    });
  },
  /**
   * 生成模块编码。
   * @param {Panel} card 模块选项卡。
   * @param {Panel} subCard 编码选项卡。
   */
  createScript: function(card, subCard) {
    var root = card.tree.getRootNode(),
      script, editor = subCard.editor;
    script = 'module=' + Ide.getNodeScript(root) + ';';
    script = js_beautify(script, {
      indent_size: 2
    });
    if (editor.getValue() != script) {
      editor.notRecordChange = true;
      editor.setValue(script);
      delete editor.notRecordChange;
      editor.clearHistory();
    }
  },
  /**
   * 获取指定节点及其子节点的脚本，该脚本将以JSON的形式描述。
   * @param {NodeInterface} node 需要获取脚本的节点。
   * @return {String} 生成的脚本。
   */
  getNodeScript: function(node) {
    var script = [];

    function addScript(control, object, type) {
      var names, meta, value, text, dataType, segment = [];
      names = Ext.Object.getKeys(object);
      Ext.Array.sort(names);
      first = true;
      Wb.each(names, function(name) {
        meta = control.data[type][name];
        if (meta) {
          dataType = meta.type;
          if (Ext.String.startsWith(dataType, 'exp'))
            dataType = 'exp';
        } else
          dataType = 'string';
        value = object[name];
        if (Wb.isEmpty(value))
          return;
        switch (dataType) {
          case 'exp':
            if (value.indexOf('{#') == -1 && !Ext.String.startsWith(value, '@'))
              text = value;
            else
              text = Wb.encode(value);
            break;
          case 'js':
          case 'ss':
            text = 'function(' + (meta.params ? meta.params.join(', ') : '') + '){\n' + value + '\n}';
            break;
          default:
            text = Wb.encode(value);
        }
        segment.push(name + ':' + text);
      });
      return segment;
    }
    node.eachChild(function(child) {
      var configs, events = '',
        control = Ide.getMetaControl(child);
      configs = addScript(control, child.data.configs, 'configs');
      if (child.data.events) {
        events = addScript(control, child.data.events, 'events');
        if (events.length)
          events = ',events:{' + events.join(',') + '}';
      }
      if (child.hasChildNodes())
        configs.push('items:[' + Ide.getNodeScript(child) + ']');
      script.push('{' + configs.join(',') + events + '}');
    });
    return script.join(',');
  },
  closeInnerTab: function(btn) {
    var subCard, type = btn.type,
      card = Ide.activeCard;
    if (card.cardType == 'module') {
      subCard = card.getActiveTab();
      card.items.each(function(item) {
        if (item.closable && (type == 1 || item != subCard))
          item.close();
      });
    }
  },
  /**
   * 关闭当前文件之外的其他打开的文件。
   */
  closeOthers: function() {
    Ide.doClose(Ide.activeCard);
  },
  /**
   * 关闭全部打开的文件。
   */
  closeAll: function() {
    Ide.doClose();
  },
  /**
   * 关闭打开的文件。
   * @param {Panel} [withoutCard] 排除的选项卡。
   */
  doClose: function(withoutCard) {
    Ext.suspendLayouts();
    Ide.fileTab.items.each(function(card) {
      if (card == withoutCard)
        return;
      if (card.isModified) {
        Ide.fileTab.setActiveTab(card);
        Wb.choose('"' + card.file + '" 已经被修改，保存所做的更改吗？',
          function(btn) {
            if (btn == 'yes')
              Ide.saveFile(false, function() {
                Ide.doClose(withoutCard);
              });
            else if (btn == 'no') {
              Wb.unModified(card);
              Ide.doClose(withoutCard);
            }
          });
        return false;
      } else
        card.close();
    });
    Ext.resumeLayouts(true);
  },
  /**
   * 设置当前编辑器的字符编码格式。
   * @param {Object} values 参数列表。
   */
  setCharset: function() {
    var card = Ide.activeCard,
      btn = card.down('#funcBtn');
    Wb.prompt({
      title: '设置编码',
      items: {
        fieldLabel: '编码格式',
        itemId: 'charset',
        xtype: 'combo',
        value: btn.text,
        allowBlank: false,
        store: ['default', 'utf-8', 'gbk']
      },
      handler: function(values, win) {
        if (values.charset == btn.text) {
          win.close();
          return;
        }
        Wb.request({
          url: 'm?xwl=dev/ide/open',
          params: Ext.apply({
            fileNames: Wb.encode([card.path])
          }, values),
          success: function(resp) {
            var obj = Wb.decode(resp.responseText)[0];
            btn.setText(values.charset);
            card.lastModified = Wb.strToDate(obj.lastModified);
            card.editor.setValue(obj.content);
            win.close();
            card.editor.focus();
          }
        });
      }
    });
  },
  /**
   * 判断是否在文件列表中选择了文件或模块。
   * @return {Boolean} 如果选择了文件则返回true，否则返回false。
   */
  fileSelected: function() {
    var selNode = Ide.fileTree.getSelection()[0];
    return selNode && Wb.getNode(selNode, 1).data.type != 'module';
  },
  /**
   * 验证名称的合法性。如果名称的所有字符为字母、数字、'-'、'_'或'.'则合法，否则非法。
   * @param {String} name 需要验证的名称。
   * @return {Boolean/String} 如果合法则返回true，否则返回非法的提示信息。
   */
  verifyName: function(name) {
    var c, i, j = name.length;
    for (i = 0; i < j; i++) {
      c = name.charAt(i);
      if (!(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' ||
          c == '_' || c == '-' || c == '.' || c >= '0' && c <= '9'))
        return Wb.format(Str.invalidChar, c);
    }
    return true;
  },
  /**
   * 刷新线程列表。
   */
  refreshThread: function() {
    var date = new Date();
    Wb.request({
      url: 'm?xwl=dev/ide/get-thread-list',
      success: function(resp) {
        Ide.threadCard.update(resp.responseText);
      }
    });
  },
  /**
   * 刷新未关闭的数据库连接列表。
   */
  refreshConnection: function() {
    var date = new Date();
    Wb.request({
      url: 'm?xwl=dev/ide/get-conn-list',
      success: function(resp) {
        Ide.connCard.update(resp.responseText);
      }
    });
  },
  /**
   * 获得图标编辑器。
   */
  getIconEditor: function() {
    return {
      fieldLabel: '图标',
      itemId: 'iconCls',
      xtype: 'combobox',
      fieldCls: 'wb_comboicon',
      anyMatch: true,
      store: Ide.iconData,
      typeAhead: true,
      displayField: 'field1',
      valueField: 'field1',
      tpl: [
        '<div><tpl for=".">',
        '<div class="x-boundlist-item wb_thumb" data-qtip="{field1}"><div class="wb_icon1 {field1}"></div></div>',
        '</tpl></div>'
      ],
      listeners: {
        afterrender: {
          single: true,
          fn: function(me) {
            if (me.value)
              me.setFieldCls(me.value);
          }
        },
        change: function(me, value) {
          if (me.priorCls)
            me.inputEl.removeCls(me.priorCls);
          me.inputEl.addCls(value);
          me.priorCls = value;
        }
      }
    };
  },
  /**
   * 执行设置文件属性操作。
   */
  setProperty: function() {
    var selNode = Ide.fileTree.getSelection()[0];
    if (!selNode) {
      Wb.warn('请选择1个文件。');
      return;
    }
    var isModule, win, config, baseNode,
      isLeaf = selNode.isLeaf(),
      data = selNode.data,
      path = Ide.getPath(selNode),
      depth = selNode.getDepth();
    baseNode = Wb.getNode(selNode, 1);
    isModule = baseNode.data.type == 'module' && (!isLeaf || Ext.String.endsWith(data.text, '.xwl'));
    if (depth == 1 || depth == 2 && baseNode.data.type == 'file')
      config = [{
        fieldLabel: '名称',
        itemId: 'text',
        readOnly: true
      }];
    else
      config = [{
        fieldLabel: '名称',
        itemId: 'text',
        allowBlank: false,
        validator: isModule ? Ide.verifyName : Wb.verifyFile
      }];
    if (isModule) {
      if (depth > 1) {
        config.push({
          fieldLabel: '标题',
          itemId: 'title'
        }, Ide.getIconEditor());
        if (isLeaf)
          config.push({
            fieldLabel: '链接配置',
            itemId: 'pageLink'
          }, {
            fieldLabel: 'URL 捷径',
            itemId: 'url',
            value: '正在查询中...',
            readOnly: true
          });
      }
    }
    config.push({
      fieldLabel: '修改时间',
      readOnly: true,
      itemId: 'lastModified',
      value: '正在查询中...'
    });
    if (isLeaf)
      config.push({
        fieldLabel: '大小',
        readOnly: true,
        itemId: 'fileSize',
        value: '正在查询中...'
      });
    else if (Ide.isChild(path, Ide.webPath))
      config.push({
        fieldLabel: '统计信息',
        readOnly: true,
        itemId: 'total',
        value: '正在统计中...'
      });
    if (isModule) {
      if (isLeaf)
        config.push({
          fieldLabel: 'URL 地址',
          readOnly: true,
          value: Ide.getNodeUrl(selNode)
        });
    }
    config.push({
      fieldLabel: '完全路径',
      readOnly: true,
      value: path
    });
    if (isModule) {
      if (isLeaf) {
        config.push({
          xtype: 'container',
          layout: 'hbox',
          margin: '5 0 0 85',
          defaults: {
            flex: 1
          },
          items: [{
            itemId: 'hidden',
            boxLabel: '在模块列表中隐藏',
            xtype: 'checkbox'
          }, {
            itemId: 'inframe',
            boxLabel: '在独立框架中运行',
            xtype: 'checkbox'
          }]
        });
      } else {
        config.push({
          boxLabel: '在模块列表中隐藏',
          fieldLabel: '&nbsp;',
          labelSeparator: '',
          itemId: 'hidden',
          xtype: 'checkbox'
        });
      }
    }
    Ide.activeCmp = 'file';
    win = Wb.prompt({
      title: (isLeaf ? '文件' : '目录') + '属性 - ' + data.text,
      width: 580,
      iconCls: 'property_icon',
      focusControl: null,
      items: config,
      handler: function(values) {
        try {
          if (values.pageLink)
            Wb.decode(values.pageLink);
        } catch (e) {
          Wb.warn('链接配置项无效。', function() {
            win.down('#pageLink').focus(false, true);
          });
          return;
        }
        var urlText = win.down('#url');
        Wb.request({
          url: 'm?xwl=dev/ide/set-property',
          timeout: -1,
          params: Ext.apply({
            isModule: isModule,
            path: Ide.getPath(selNode),
            urlValid: urlText ? !urlText.readOnly : false
          }, values),
          success: function(resp) {
            var card, respObj = Wb.decode(resp.responseText);
            win.close();
            if (isLeaf && Wb.extractFileExt(data.text) != Wb.extractFileExt(values.text)) {
              values.icon = 'm?xwl=dev/ide/get-file-icon&file=' + encodeURIComponent(respObj.path);
              values.iconCls = '';
            }
            //oldPath用于syncFiles方法定位已经打开的card等其他组件
            values.cls = values.hidden ? 'x-highlight' : '';
            selNode.data.oldPath = Ide.getPath(selNode);
            values = Ext.copyTo({}, values, ['text', 'title', 'hidden', 'inframe', 'pageLink', 'icon', 'iconCls', 'cls']);
            Wb.update(selNode, values);
            card = Ide.fileTab.child('[path=' + selNode.data.oldPath + ']');
            if (card)
              card.lastModified = Wb.strToDate(respObj.lastModified);
            Ide.syncFiles(selNode);
            if (respObj.refactorInfo)
              Ide.syncData(respObj.refactorInfo);
          }
        });
      }
    });
    Wb.setValue(win, data);
    var textfield = win.down('#text');
    textfield.focus(false, true, function() {
      var pos = data.text.lastIndexOf('.');
      if (pos == -1) pos = data.text.length;
      textfield.selectText(0, pos);
    });
    Wb.request({
      url: 'm?xwl=dev/ide/total',
      params: {
        path: path
      },
      showMask: false,
      callback: function(a, success, response) {
        //如果win已经销毁
        if (!Ext.getCmp(win.id)) return;
        if (success) {
          var i, respObj = Wb.decode(response.responseText),
            data = respObj.total;
          Wb.setValue(win, {
            lastModified: Wb.dateToText(respObj.lastModified),
            url: respObj.url,
            fileSize: Wb.getFileSize(respObj.fileSize) + ' (' + respObj.fileSize + ' B)'
          });
          var urlText = win.down('#url');
          if (urlText) {
            urlText.setReadOnly(false);
            urlText.selectOnFocus = false;
            urlText.validator = Ide.verifyName;
          }
          if (data) {
            for (i = 0; i < 3; i++)
              data[i] = Wb.format(data[i], '#,##0');
            Wb.setValue(win, {
              total: '模块数：' +
                data[0] + '，文件数：' +
                data[1] + '，目录数：' +
                data[2] + '，合计大小：' +
                Wb.getFileSize(data[3])
            });
          }
        } else {
          var failStr = '查询失败';
          Wb.setValue(win, {
            url: failStr,
            lastModified: failStr,
            total: failStr,
            fileSize: failStr
          });
        }
      }
    });
  },
  /**
   * 把路径转换为用于显示目的的路径。位置模块或应用目录下的文件将以相对路径表示，否则以绝对路径表示。
   * @param {String} path 需要转换的路径。
   * @return {String} 转换后的路径。
   */
  getPathText: function(path) {
    if (Ide.isChild(path, Ide.modulePath))
      return path.substring(Ide.modulePath.length);
    else if (Ide.isChild(path, Ide.webPath))
      return path.substring(Ide.webPath.length);
    else
      return path;
  },
  /**
   * 把路径中指定字符串开始的源路径替换为目标路径。
   * @param {String} from 源路径。
   * @param {String} to 目标路径。
   * @param {String} path 替换前的路径。
   * @return {String} 替换后的路径。
   */
  getRefPath: function(from, to, path) {
    return to + '/' + path.substring(from.length);
  },
  /**
   * 同步表格中包含path字段内容。
   * @param {Ext.grid.Panel} grid 表格。
   * @param {String} oldPath 替换前的路径。
   * @param {String} newPath 替换后的路径。
   * @param {Boolean} isLeaf 同步的节点是否为叶子节点。   
   */
  syncGrid: function(grid, oldPath, newPath, isLeaf) {
    var setPath;
    grid.store.each(function(rec) {
      if (Ide.isChild(rec.data.path, oldPath)) {
        if (isLeaf)
          setPath = newPath;
        else
          setPath = Ide.getRefPath(oldPath, newPath, rec.data.path);
        rec.set('path', setPath);
      }
    });
    grid.store.commitChanges();
  },
  /**
   * 同步节点中的文件信息。同步的内容包括文件的显示名称、路径、图标和配置信息等。
   * @param {NodeInterface[]} nodes 节点列表。
   */
  syncFiles: function(nodes) {
    if (!Ext.isArray(nodes))
      nodes = [nodes];
    Ext.suspendLayouts();
    Wb.each(nodes, function(node) {
      var setPath, isLeaf = node.isLeaf(),
        data = node.data,
        oldPath = data.oldPath + '/',
        newPath = Ide.getPath(node);
      delete data.oldPath;
      //同步文件卡片
      Ide.fileTab.items.each(function(card) {
        if (Ide.isChild(card.path, oldPath) || card.runFile && Ide.isChild(card.runFile, oldPath)) {
          if (card.runFile) {
            if (isLeaf)
              setPath = newPath;
            else
              setPath = Ide.getRefPath(oldPath, newPath, card.runFile);
            card.runFile = setPath;
            card.bindFile = Ide.getPathText(setPath);
            if (isLeaf)
              card.setTitle(Ext.String.ellipsis(data.text, 20));
          } else {
            if (isLeaf)
              setPath = newPath;
            else
              setPath = Ide.getRefPath(oldPath, newPath, card.path);
            card.path = setPath;
          }
          card.tab.setTooltip(Ide.getPathText(setPath));
          if (isLeaf && !card.runFile) {
            if (card.tree) {
              var root = card.tree.getRootNode();
              root.data.title = data.title;
              root.data.hidden = data.hidden;
              root.data.inframe = data.inframe;
              root.data.pageLink = data.pageLink;
              root.data.iconCls = data.iconCls;
            }
            card.setTitle((card.isModified ? '*' : '') + Ext.String.ellipsis(data.text, 20));
            card.setIcon(data.icon);
            card.setIconCls(data.iconCls);
            card.file = data.text;
          }
        }
      });
      //同步标记表格文件
      Ide.syncGrid(Ide.markerGrid, oldPath, newPath, isLeaf);
      //同步搜索表格文件
      Ide.syncGrid(Ide.searchGrid, oldPath, newPath, isLeaf);
    });
    Ext.resumeLayouts(true);
  },
  /**
   * 执行添加文件或目录操作。如果文件列表中模块被选中则添加模块否则添加文件。
   * @param {Boolean} isFolder 是否是目录，默认为false。
   */
  doAdd: function(isFolder) {
    if (Ide.fileSelected())
      Ide.addFile(isFolder);
    else
      Ide.addModule(isFolder);
  },
  /**
   * 执行添加文件操作。如果文件列表中模块被选中则添加模块否则添加文件。
   */
  add: function() {
    Ide.doAdd();
  },
  /**
   * 执行添加目录操作。如果文件列表中模块被选中则添加模块目录否则添加文件目录。
   */
  addFolder: function() {
    Ide.doAdd(true);
  },
  /**
   * 添加模块或目录。
   * @param {Boolean} isDir 是否为目录，默认为false。
   */
  addModule: function(isDir) {
    var items, selNode = Ide.fileTree.getSelection()[0];
    if (!selNode)
      selNode = Ide.fileTree.getRootNode().firstChild;
    items = [{
      fieldLabel: '名称',
      itemId: 'name',
      allowBlank: false,
      validator: Ide.verifyName
    }, {
      fieldLabel: '标题',
      itemId: 'title'
    }, Ide.getIconEditor()];
    if (!isDir)
      items.push({
        fieldLabel: '链接配置',
        itemId: 'pageLink'
      }, {
        fieldLabel: 'URL 捷径',
        itemId: 'url',
        validator: Ide.verifyName
      });
    items.push({
      xtype: 'fieldcontainer',
      layout: 'hbox',
      hideEmptyLabel: false,
      defaults: {
        flex: 1
      },
      items: [{
        itemId: 'insert',
        boxLabel: '插入在选择节点上',
        xtype: 'checkbox',
        disabled: selNode.getDepth() == 1
      }, {
        itemId: 'hidden',
        boxLabel: '在模块列表中隐藏',
        xtype: 'checkbox'
      }]
    });
    if (!isDir)
      items[items.length - 1].items.push({
        itemId: 'inframe',
        boxLabel: '在独立框架中运行',
        xtype: 'checkbox'
      });
    Wb.prompt({
      title: '添加',
      width: 580,
      iconCls: isDir ? 'folder_add_icon' : 'file_add_icon',
      items: items,
      handler: function(values, win) {
        try {
          if (values.pageLink)
            Wb.decode(values.pageLink);
        } catch (e) {
          Wb.warn('链接配置项无效。', function() {
            win.down('#pageLink').focus(false, true);
          });
          return;
        }
        var folder, indexName, type;
        if (!values.insert && !selNode.isLeaf()) {
          folder = selNode;
          type = 'append';
        } else {
          folder = selNode.parentNode;
          type = values.insert ? 'before' : 'after';
          indexName = selNode.data.text;
        }
        Wb.request({
          url: 'm?xwl=dev/ide/add-module',
          params: Ext.apply(values, {
            isDir: isDir,
            path: Ide.getPath(folder),
            type: type,
            indexName: indexName
          }),
          success: function(resp) {
            var newNode, node, respObject = Wb.decode(resp.responseText);
            if (!isDir)
              respObject = respObject[0];
            newNode = {
              id: Wb.getId(),
              text: respObject.file,
              title: respObject.title,
              iconCls: respObject.iconCls,
              hidden: respObject.hidden,
              inframe: respObject.inframe,
              pageLink: respObject.pageLink
            };
            if (isDir)
              newNode.children = [];
            else
              newNode.leaf = true;
            if (newNode.hidden)
              newNode.cls = 'x-highlight';

            function setNode() {
              Ide.fileTree.setSelection(node);
              win.close();
              if (!isDir)
                Ide.fileTab.setActiveTab(Ide.openModule(respObject));
            }

            if (type == 'append') {
              var loaded = folder.data.loaded;
              folder.expand(false, function() {
                if (loaded) {
                  node = folder.appendChild(newNode);
                  node.commit();
                } else
                  node = folder.findChild('text', newNode.text);
                setNode();
              });
            } else {
              if (type == 'before') {
                node = folder.insertBefore(newNode, selNode);
                node.commit();
              } else if (type == 'after')
                node = Wb.insertAfter(newNode, selNode)[0];
              setNode();
            }
          }
        });
      }
    });
  },
  /**
   * 添加文件或目录。
   * @param {Boolean} isDir 是否为目录，默认为false。
   */
  addFile: function(isDir) {
    Wb.prompt({
      title: '添加',
      iconCls: isDir ? 'folder_add_icon' : 'file_add_icon',
      items: [{
        fieldLabel: '名称',
        itemId: 'name',
        allowBlank: false,
        validator: Wb.verifyFile
      }],
      handler: function(values, win) {
        var folder = Ide.fileTree.getSelection()[0];
        if (folder.isLeaf())
          folder = folder.parentNode;
        Wb.request({
          url: 'm?xwl=dev/ide/add-file',
          params: {
            isDir: isDir,
            path: Ide.getPath(folder),
            name: values.name
          },
          success: function(resp) {
            Ide.activeCmp = 'file';
            var loaded = folder.data.loaded,
              respObject = Wb.decode(resp.responseText);
            folder.expand(false, function() {
              if (loaded)
                Wb.append(respObject, folder);
              else
                Ide.fileTree.setSelection(folder.findChild('text', respObject.text));
              win.close();
            });
          }
        });
      }
    });
  },
  /**
   * 删除当前设计器选择的控件，并选择删除控件在对象视图中的节点。
   * @return 如果有控件删除返回true，否则返回false。
   */
  removeComp: function() {
    var comp, designer = Ide.activeCard.getActiveTab().designer,
      nodes = [];
    designer.items.each(function(item) {
      if (item.isSelected) {
        comp = item.bindComp;
        designer.remove(comp);
        nodes.push(comp.node);
        designer.remove(item);
      }
    });
    if (nodes.length > 0) {
      Ide.activeCard.tree.setSelection(nodes);
      return true;
    } else
      return false;
  },
  /**
   * 删除当前对象视图选择的节点。
   * @return 如果有节点删除返回true，否则返回false。
   */
  removeNode: function() {
    var root, sels = Ide.activeCard.tree.getSelection();
    Ide.activeCard.items.each(function(card) {
      var found = false,
        cardNode = card.node;
      if (cardNode) {
        Wb.each(sels, function(node) {
          if (cardNode.isAncestor(node) || node == cardNode) {
            found = true;
            return false;
          }
        });
        if (found)
          card.close();
      }
    });
    if ((root = Ide.getModuleNode(sels))) {
      root.remove();
      Ide.addControl(Ide.moduleNode, true);
      return true;
    } else {
      Wb.remove(Ide.activeCard.tree);
      return sels.length > 0;
    }
  },
  /**
   * 执行删除当前选择的对象，删除操作包括删除文件和节点。
   */
  remove: function() {
    if (Ide.activeCmp == 'control') {
      Ext.suspendLayouts();
      try {
        if (Ide.activeCard.getActiveTab().layoutCard) {
          if (Ide.removeComp()) {
            Ide.removeNode();
            Ide.loadProps(Ide.activeCard.getActiveTab().designer);
            Ide.setModified();
          }
        } else {
          if (Ide.removeNode())
            Ide.setModified();
        }
      } finally {
        Ext.resumeLayouts(true);
      }

    } else
      Ide.removeFiles();
  },
  /**
   * 获取文件列表中文件节点的绝对路径。
   * @param {NodeInterface} node 节点对象。
   * @return {String} 绝对路径。
   */
  getPath: function(node) {
    if (!node || node.isRoot()) return '';
    var path = Wb.getSection(node.getPath('text'), '/', 3),
      baseNode = Wb.getNode(node, 1),
      basePath = baseNode.data.base;
    if (!path)
      basePath = basePath.slice(0, -1);
    if (baseNode == Ide.sysNode)
      return basePath + path.replace('//', '/');
    else
      return basePath + path;
  },
  /**
   * 获取文件列表中文件节点的URL路径。
   * @param {NodeInterface} node 节点对象。
   * @return {String} URL路径。如果节点是目录或在应用目录之外返回null。
   */
  getNodeUrl: function(node) {
    if (node.isLeaf())
      return Ide.getFileUrl(Ide.getPath(node));
    else
      return null;
  },
  /**
   * 添加监听服务器信息的WebSocket控件。
   */
  addSocket: function() {
    Ide.msgSocket = new Ext.data.Socket({
      name: 'ide.console',
      listeners: {
        success: function(socket, data) {
          if (!data)
            return;
          var object, msg;
          object = Wb.decode(data);
          msg = object.msg;
          if (object.encode)
            msg = Wb.decode(msg);
          if (object.type)
            Cs[object.type](msg);
          else
            Cs.log(msg);
        },
        onclose: function() {
          app.toggleOutputsBtn.toggle(false, true);
        },
        onopen: function() {
          app.toggleOutputsBtn.toggle(true, true);
        }
      }
    });
  },
  /**
   * 获取对象视图中节点的路径。
   * @param {NodeInterface} node 节点对象。
   * @return {String} URL路径。
   */
  getNodePath: function(node) {
    return Wb.getSection(node.getPath('text'), '/', node.getDepth() == 1 ? 2 : 3);
  },
  /**
   * 把文件路径转换为URL路径。如果文件不在web应用目录内则返回null。
   * @param {String} path 文件路径。
   * @return {String} 转换后的URL路径。
   */
  getFileUrl: function(path) {
    if (!path) return null;
    var lowerPath = path.toLowerCase();

    if (Ide.isChild(path, Ide.modulePath) && Ext.String.endsWith(lowerPath, '.xwl'))
      return 'm?xwl=' + path.substring(Ide.modulePath.length).slice(0, -4);
    else if (Ide.isChild(path, Ide.webPath))
      return path.substring(Ide.webPath.length);
    return null;
  },
  /**
   * 获取节点对应文件的web或模块目录下的相对路径。
   * @param {NodeInterface} node 文件节点。
   * @return {String} 节点对应文件的web目录下的相对路径。如果文件在web目录之外则返回null。
   */
  getWebPath: function(node) {
    var path = Ide.getPath(node);
    if (Ide.isChild(path, Ide.modulePath))
      return path.substring(Ide.modulePath.length);
    else if (Ide.isChild(path, Ide.webPath))
      return path.substring(Ide.webPath.length);
    else
      return null;
  },
  /**
   * 获取当前编辑器或其所在选项卡对象。
   * @param {Boolean} returnOwner true返回编辑器所在选项卡，false返回编辑器。
   * @return {Panel/CodeMirror} 选项卡或编辑器。
   */
  getEditor: function(returnOwner) {
    var card, activeCard = Ide.activeCard;
    if (activeCard) {
      if (activeCard.editor)
        return returnOwner ? activeCard : activeCard.editor;
      else {
        if (activeCard instanceof Ext.tab.Panel) {
          card = activeCard.getActiveTab();
          if (card.editor)
            return returnOwner ? card : card.editor;
        }
      }
    }
    return null;
  },
  /**
   * 同步数据，包括修改日期和路径等。
   * @param {Object} data 需要同步的包含文件、修改日期和路径等数据。
   */
  syncData: function(data) {
    var i, j, files = data.files,
      changes = data.change;
    j = changes.length;
    Wb.each(changes, function(change) {
      change[0] = new RegExp(change[0]);
    });
    Wb.each(files, function(file) {
      card = Ide.fileTab.child('[path=' + file.path + ']');
      if (card) {
        card.lastModified = Wb.strToDate(file.lastModified);
        for (i = 0; i < j; i++)
          Ide.replaceText(card, changes[i][0], changes[i][1]);
      }
    });
  },
  /**
   * 取消选择全部对象。
   */
  doSelectAll: function() {
    var card = Ide.activeCard;
    if (card && card.cardType == 'module') {
      card = card.getActiveTab();
      if (card.layoutCard)
        Ide.selectAll(card.designer, true);
    }
  },
  /**
   * 执行剪切或复制当前选择的对象。
   * @param {Boolean} isCopy 是否是复制。
   */
  cutCopy: function(isCopy) {
    if (Ide.activeCmp == 'control')
      Ide.copyNode(isCopy);
    else
      Ide.copyFile(isCopy);
  },
  /**
   * 执行复制当前选择的对象。
   */
  copy: function() {
    Ide.cutCopy(true);
  },
  /**
   * 执行剪切当前选择的对象。
   */
  cut: function() {
    Ide.cutCopy(false);
  },
  /**
   * 复制或剪切控件节点至虚拟剪贴板中，虚拟剪贴板为当前window中的内存变量。
   * @param {Boolean} isCopy 是否为复制，如果为false则为剪切。
   */
  copyNode: function(isCopy) {
    var card = Ide.activeCard.getActiveTab();
    if (card.layoutCard) {
      if (Ide.syncSelect())
        Ide.doApplyLayout(card);
      else
        return;
    }
    var tree = Ide.activeCard.tree,
      nodes = tree.getSelection(),
      copied = [];
    if (!nodes.length)
      return;
    Wb.each(nodes, function(node) {
      copied.push(Wb.copy(node));
    });
    Ide.clipboardType = 'node';
    Ide.clipboard = copied;
    if (!isCopy) {
      Ide.remove();
      Ide.setModified();
    }
  },
  /**
   * 复制或剪切文件至虚拟剪贴板中，虚拟剪贴板为当前window中的内存变量。
   * @param {Boolean} isCopy 是否为复制，如果为false则为剪切。
   */
  copyFile: function(isCopy) {
    var sels = Ide.fileTree.getSelection();
    if (sels.length) {
      Ide.isCopy = isCopy;
      Ide.clipboardType = 'file';
      Ide.clipboard = sels;
    }
  },
  /**
   * 在当前选择的对象上执行粘贴操作。
   */
  paste: function() {
    var shift = Ext.EventObject.shiftKey;
    if (Ide.activeCmp == 'control') {
      if (Ide.clipboardType == 'node')
        Ide.pasteNode(shift);
    } else if (Ide.clipboardType == 'file')
      Ide.pasteFile(false, shift);
  },
  /**
   * 在当前选择器页面中同步选择对象视图中的节点。
   * @return {Boolean} 如果有节点被选择返回true，否则返回false。
   */
  syncSelect: function() {
    var designer = Ide.activeCard.getActiveTab().designer,
      nodes = [];
    designer.items.each(function(item) {
      if (item.isSelected) {
        nodes.push(item.bindComp.node);
      }
    });
    if (nodes.length > 0) {
      Ide.activeCard.tree.setSelection(nodes);
      return true;
    } else
      return false;
  },
  /**
   * 查找节点列表中的模块节点。
   * @param {NodeInterface[]} nodes 节点列表。
   * @return {type} 如果模块节点存在则返回，否则返回null。
   */
  getModuleNode: function(nodes) {
    var moduleNode = null;
    Wb.each(nodes, function(node) {
      if (node.type == 'module' || node.data && node.data.type == 'module') {
        moduleNode = node;
        return false;
      }
    });
    return moduleNode;
  },
  /**
   * 在当前选择的对象上粘贴树节点。
   * @param {Boolean} [appendMode] 是否在当前选择节点粘贴为子节点，如果为false，将在平级添加。
   */
  pasteNode: function(appendMode) {
    var selNode, moduleNode, card = Ide.activeCard.getActiveTab();
    if (card.layoutCard) {
      Ide.doApplyLayout(card);
      selNode = card.designer.node;
      appendMode = true;
    } else
      selNode = Ide.activeCard.tree.getSelection()[0];
    if (!selNode) {
      Wb.warn('请选择1个节点。');
      return;
    }
    Ide.setModified();
    moduleNode = Ide.getModuleNode(Ide.clipboard);
    if (moduleNode) {
      var root = Ide.activeCard.tree.getRootNode();
      Ext.suspendLayouts();
      Ide.activeCard.items.each(function(card) {
        if (card.closable)
          card.close();
      });
      root.removeChild(root.firstChild);
      Wb.append(Ext.clone(moduleNode), root);
      Ext.resumeLayouts(true);
      return;
    }
    if (selNode.getDepth() == 1)
      appendMode = true;
    var nodes, parentNode, fromNodes = Ext.clone(Ide.clipboard),
      namesObj = {};

    function setId(items) {
      Wb.each(items, function(item) {
        item.id = Wb.getId();
        if (item.children)
          setId(item.children);
      });
    }
    setId(fromNodes);
    if (appendMode)
      parentNode = selNode;
    else
      parentNode = selNode.parentNode;
    parentNode.eachChild(function(node) {
      namesObj[node.data.text] = true;
    });
    Wb.each(fromNodes, function(node) {
      var name = Wb.uniqueName(namesObj, node.configs.itemId);
      node.configs.itemId = name;
      node.text = name;
      namesObj[name] = true;
    });
    if (appendMode) {
      selNode.expand();
      nodes = Wb.append(fromNodes, selNode);
    } else {
      nodes = Wb.insertAfter(fromNodes, selNode);
    }
    if (card.layoutCard) {
      Ide.updateLayout(card);
      Ext.suspendLayouts();
      try {
        card.designer.items.each(function(item) {
          if (item.isMask) {
            Ide.doSelect(item, Wb.indexOf(nodes, item.bindComp.node) != -1);
          }
        });
        Ide.loadProps(card.designer);
      } finally {
        Ext.resumeLayouts(true);
      }
    }
  },
  /**
   * 在当前选择的对象上粘贴文件。
   * @param {Boolean} [noConfirm] 如果同名文件存在是否不提示覆盖，默认为false。
   * @param {Boolean} [appendMode] 是否在当前选择节点粘贴为子节点，如果为false，将在平级添加。
   */
  pasteFile: function(noConfirm, appendMode) {
    var selNode = Ide.fileTree.getSelection()[0];
    if (!selNode) {
      Wb.warn('请选择1个文件或目录节点。');
      return;
    }
    if (selNode.getDepth() == 1) {
      if (selNode.data.base === '') {
        Wb.warn('无法粘贴在此目录下。');
        return;
      }
      appendMode = true;
    }
    var isCopy = Ide.isCopy,
      fromNodes = Ext.Array.clone(Ide.clipboard),
      fromPaths = [],
      dp = appendMode && !selNode.isLeaf() ? 'append' : 'after';
    Wb.each(fromNodes, function(node) {
      fromPaths.push(Ide.getPath(node));
    });
    Wb.request({
      url: 'm?xwl=dev/ide/move',
      showError: false,
      timeout: -1,
      params: {
        isCopy: isCopy,
        noConfirm: Wb.getBool(noConfirm, true),
        src: Wb.encode(fromPaths),
        dst: Ide.getPath(selNode),
        dropPosition: dp,
        type: Wb.getNode(selNode, 1).data.type
      },
      success: function(resp) {
        var nodes, folderNode, i, j, k = 0,
          syncMode = true,
          name, respObj = Wb.decode(resp.responseText),
          moveTo = respObj.moveTo,
          syncPaths = [];

        function doSync() {
          var node, nodes = [],
            selModel = Ide.fileTree.selModel,
            i = 0;
          selModel.deselectAll();
          Wb.each(syncPaths, function() {
            node = folderNode.findChild('text', syncPaths[i][1]);
            //刷新覆盖的节点
            if (node.isLoaded() && syncPaths[i][2]) {
              node.expand();
              Ide.fileTree.store.load({
                node: node
              });
            }
            selModel.select(node, true);
            if (!isCopy) {
              node.data.oldPath = syncPaths[i][0];
              nodes.push(node);
            }
            i++;
          });
          if (!isCopy) {
            Ide.syncFiles(nodes);
            Ide.syncData(respObj);
          }
        }

        j = moveTo.length;
        for (i = 0; i < j; i++) {
          syncPaths.push([Ide.getPath(fromNodes[k]), Wb.getFilename(moveTo[i][0]), moveTo[i][1]]);
          if (!isCopy)
            fromNodes[k].remove();
          //如果被覆盖则不生成新节点
          if (moveTo[i][1])
            fromNodes.splice(k, 1);
          else
            k++;
        }
        if (dp == 'append') {
          folderNode = selNode;
          if (selNode.isLoaded()) {
            selNode.expand();
            nodes = Wb.append(fromNodes, selNode, isCopy);
          } else {
            syncMode = false;
            selNode.expand(false, doSync);
          }
        } else {
          folderNode = selNode.parentNode;
          nodes = Wb.insertAfter(fromNodes, selNode, isCopy);
        }
        if (nodes) {
          k = 0;
          for (i = 0; i < j; i++) {
            //如果没有覆盖则重命名
            if (!moveTo[i][1]) {
              nodes[k].set('text', Wb.getFilename(moveTo[i][0]));
              nodes[k].commit();
              k++;
            }
          }
        }
        if (syncMode)
          doSync();
      },
      failure: function(resp) {
        var msg = resp.responseText,
          errMsg = Wb.getError(msg, 101);
        if (errMsg) {
          Wb.confirm(errMsg, function() {
            Ide.pasteFile(true, appendMode);
          });
        } else
          Wb.except(resp);
      }
    });
  },
  /**
   * 判断子文件/目录是否是指定目录的下级目录。
   * @param {String} parent 上级目录。
   * @param {String} child 下级目录。
   * @return {Boolean} true子目录，false不是。
   */
  isChild: function(child, parent) {
    return Ext.String.startsWith(child + '/', parent);
  },
  /**
   * 在当前编辑器中插入文本。
   * @param {String} text 插入的文本。
   */
  insertText: function(text) {
    var editor = Ide.getEditor();
    if (editor && !editor.options.readOnly) {
      editor.replaceSelection(text);
      editor.focus();
    }
  },
  /**
   * 在当前编辑器中插入函数注释模板。
   */
  addFuncNote: function() {
    Ide.addScript([
      '/**',
      ' * 文档注释。',
      ' *',
      ' * Example:',
      ' *',
      ' *     var foo = bar();',
      ' *',
      ' * @param {type} name1 必须参数说明。',
      ' * @param {type} [name2] 可选参数说明。',
      ' * @return {type} 返回值说明。',
      ' */'
    ]);
  },
  /**
   * 在当前编辑器中插入属性注释模板。
   */
  addPropertyNote: function() {
    Ide.addScript(['/** @property {type} name 参数说明 */']);
  },
  /**
   * 在当前编辑器中插入TODO内容。
   */
  addTodo: function() {
    Ide.addScript(['// TO' + 'DO: ']);
  },
  /**
   * 在当前编辑器中插入app模板内容。
   */
  addAppTpl: function() {
    Ide.addScript([
      "Wb.apply(app, {",
      "",
      "});"
    ]);
  },
  /**
   * 在当前编辑器中插入 Wb.request 请求模板。
   */
  addWbRequest: function() {
    Ide.addScript([
      "Wb.request({",
      "  url: '',",
      "  params: {},",
      "  success: function(resp) {}",
      "});"
    ]);
  },
  /**
   * 在脚本编辑器中插入预定义的脚本模板。
   * @param {Array} script 脚本数组，每行占一个条目。
   */
  addScript: function(script) {
    var i, j, ch, editor = Ide.getEditor();
    if (!editor) return;
    ch = editor.getCursor().ch;
    j = script.length;
    for (i = 1; i < j; i++)
      script[i] = Ext.String.leftPad('', ch) + script[i];
    editor.replaceSelection(script.join('\n'));
    editor.focus();
  },
  /**
   * 清除当前编辑器的所有书签。
   */
  clearBookmark: function() {
    var card = Ide.getEditor(true);
    if (!card) return;
    Wb.remove(card.toolbar, card.toolbar.query('splitbutton'));
  },
  /**
   * 在当前编辑器中添加书签。
   */
  addBookmark: function() {
    var card = Ide.getEditor(true);
    if (!card) return;
    Ide.doAddBookmark(card.editor);
  },
  /**
   * 为指定编辑器添加书签。
   * @param {CodeMirror} cm 编辑器对象。
   */
  doAddBookmark: function(cm) {
    var cursor = cm.getCursor(),
      line = Ext.htmlEncode(Ext.String.trim(cm.getLine(cursor.line))),
      buttons = cm.card.toolbar.query('splitbutton'),
      exists = false;
    Wb.each(buttons, function(button) {
      var bm = button.bookmark.find();
      if (bm) {
        if (bm.line == cursor.line) {
          exists = true;
          return false;
        }
      } else
        cm.card.toolbar.remove(button);
    });
    if (exists) return;
    cm.card.toolbar.insert(2, {
      text: Ext.String.ellipsis(line, 15) || '书签',
      bookmark: cm.setBookmark(cursor),
      scrollInfo: cm.getScrollInfo(),
      cursor: cursor,
      xtype: "splitbutton",
      minWidth: 50,
      handler: function(me) {
        var bm = me.bookmark.find();
        if (bm) {
          if (bm.line === cursor.line)
            cm.scrollTo(me.scrollInfo.left, me.scrollInfo.top);
          cm.setCursor(bm);
          cm.focus();
        } else {
          cm.card.toolbar.remove(me);
          Wb.warn('该书签已经被删除。');
        }
      },
      menu: {
        xtype: "menu",
        items: [{
          text: "删除书签",
          handler: function(me) {
            var btn = me.up('splitbutton');
            btn.bookmark.clear();
            cm.card.toolbar.remove(btn);
          }
        }]
      }
    }).el.highlight();
  },
  /**
   * 执行删除文件操作。
   */
  removeFiles: function() {
    var sels = Ide.fileTree.getSelection(),
      files = [],
      stopNode;
    if (!sels.length)
      return;
    sels = Wb.reverse(sels);
    Wb.each(sels, function(node) {
      Wb.highlight(node, true);
      if (node.getDepth() == 1) {
        stopNode = node;
        return false;
      }
      files.push(Ide.getPath(node));
    });
    if (stopNode) {
      Wb.warn('不能删除 \"' + stopNode.data.text + '\" 的所有文件。', null, Ide.fileTree.view.getNode(stopNode));
      return;
    }
    Wb.confirm(sels.length === 1 ? '确定要删除 "' + sels[0].data.text + '" 吗？' :
      '确定要删除选择的 ' + sels.length + ' 项吗？',
      function() {
        Wb.request({
          url: 'm?xwl=dev/ide/delete',
          timeout: -1,
          params: {
            files: Wb.encode(files)
          },
          success: function() {
            var path;
            Wb.each(sels, function(node) {
              path = Ide.getPath(node) + '/';
              Ide.fileTab.items.each(function(card) {
                if (Ide.isChild(card.path, path) || card.runFile && Ide.isChild(card.runFile, path)) {
                  card.isModified = false;
                  card.close();
                }
              });
            });
            Wb.remove(Ide.fileTree, sels);
          }
        });
      }, Ide.fileTree.view.getNode(sels[0]));
  },
  /**
   * 设置界面方案。
   * @param {Button} me 触发的按钮。
   */
  setTheme: function(me) {
    var theme = me.itemId.slice(0, -3);
    Wb.request({
      url: 'm?xwl=dev/ide/set-options',
      params: {
        name: 'theme',
        value: theme,
        sessionName: 'sys.theme'
      },
      success: function() {
        Wb.confirm('设置成功，刷新当前窗口吗？', function() {
          location.reload();
        });
      }
    });
  },
  /**
   * 设置脚本编辑器方案。
   * @param {Button} me 触发的按钮。
   */
  setEditTheme: function(me) {
    var editTheme = me.itemId.slice(0, -5);
    Wb.request({
      url: 'm?xwl=dev/ide/set-options',
      params: {
        name: 'editTheme',
        value: editTheme,
        sessionName: 'sys.editTheme'
      },
      success: function() {
        Wb.editTheme = editTheme;
        Ide.fileTab.items.each(function(card) {
          if (card.editor)
            card.editor.setOption('theme', editTheme);
          card.items.each(function(subCard) {
            if (subCard.editor)
              subCard.editor.setOption('theme', editTheme);
          });
        });
      }
    });
  },
  /**
   * 打开当前选择的一个或多个文件。
   */
  open: function() {
    var sels = Ide.fileTree.getSelection(),
      files = [];
    Wb.each(sels, function(node) {
      if (node.isLeaf())
        files.push(Ide.getPath(node));
    });
    if (!files.length) {
      Wb.warn('请选择至少一个需要打开的文件。');
      return;
    }
    Ide.doOpen(files);
  },
  /**
   * 打开文件列表中的指定文件。
   * @param {String[]} files 文件列表。
   * @param {Function} callback 文件打开成功后的回调函数。   
   */
  doOpen: function(files, callback) {
    if (!Ext.isArray(files))
      files = [files];
    var openFiles = [],
      card, firstCard;
    Wb.each(files, function(file) {
      card = Ide.fileTab.child('[path=' + file + ']');
      if (card) {
        if (!firstCard)
          firstCard = card;
      } else
        openFiles.push(file);
    });
    if (!openFiles.length) {
      Ide.fileTab.setActiveTab(firstCard);
      Ext.callback(callback, this, [firstCard], 20);
      return;
    }
    Wb.request({
      url: 'm?xwl=dev/ide/open',
      params: {
        fileNames: Wb.encode(openFiles)
      },
      success: function(resp) {
        var contents = Wb.decode(resp.responseText),
          fileExt;
        Ext.suspendLayouts();
        Wb.each(contents, function(content) {
          fileExt = content.path.slice(-3).toLowerCase();
          if (fileExt == 'xwl')
            card = Ide.openModule(content);
          else
            card = Ide.openFile(Ide.fileTab, content);
          if (!firstCard)
            firstCard = card;
        });
        Ide.fileTab.setActiveTab(firstCard);
        Ext.callback(callback, this, [firstCard], 20);
        Ext.resumeLayouts(true);
      }
    });
  },
  /**
   * 打开指定的文件在新的选项卡中。
   * @param {Ext.tab.Panel} tab tab对象。
   * @param {Object} content 文件内容。
   * @param {Boolean} innerMode 是否为内部模式，内部模式指模块内编辑脚本。
   * @param {Function} callback 打开文件完成之后的回调函数。   
   * @return {Panel} 打开文件后的选项卡。
   */
  openFile: function(tab, content, innerMode, callback) {
    var cardConfig, fileExt, sourceCard = content.sourceCard;
    fileExt = Wb.extractFileExt(content.file).toLowerCase();
    cardConfig = {
      html: '<textarea></textarea>',
      title: Ext.String.ellipsis(innerMode ? content.title : content.file, 20),
      closable: !sourceCard,
      border: innerMode,
      hideMode: Ext.isIE ? 'offsets' : 'display',
      reorderable: !sourceCard,
      bbar: ['->', {
        text: '1 : 1',
        xtype: 'tbtext',
        itemId: 'cursorLabel',
        minWidth: 90,
        style: 'text-align:right'
      }, ' '],
      listeners: {
        activate: function(me) {
          if (sourceCard)
            Ide.createScript(me.ownerCt, me);
          if (me.lastScrollInfo)
            me.editor.scrollTo(me.lastScrollInfo.left, me.lastScrollInfo.top);
          setTimeout(function() {
            try {
              if (me.editor.needRefresh) {
                me.editor.refresh();
                me.editor.needRefresh = false;
              }
              me.editor.focus();
            } catch (e) {
              //忽略
            }
          }, 10);
        },
        beforedeactivate: function(me) {
          me.lastScrollInfo = me.editor.getScrollInfo();
        },
        resize: function(me, width, height) {
          if (me.editor && !me.destroying) {
            Ext.fly(me.editor.getScrollerElement()).setHeight(height - me.toolbar.getHeight());
            me.editor.refresh();
          }
        },
        close: function(me) {
          Ide.clearMarkers(me.innerMode ? me.ownerCt.path : me.path, me.innerMode ? me : null);
        },
        afterrender: {
          single: true,
          fn: function(me) {
            var editor, config, extConfig;
            me.toolbar = me.down('toolbar');
            me.cursorLabel = me.down('[itemId=cursorLabel]');
            me.funcBtn = me.down('[itemId=funcBtn]');
            me.paramsLbl = me.down('[itemId=paramsLbl]');
            if (content.params)
              me.paramsLbl.setText('(' + content.params.join(', ') + ')');
            else me.toolbar.remove(me.paramsLbl);
            if (me.innerMode) {
              if (sourceCard) {
                me.funcBtn.setText('只读');
                me.funcBtn.setDisabled(true);
              } else
                me.funcBtn.setText(Ide.getNodePath(content.node));
            }
            config = {
              lineNumbers: true,
              readOnly: sourceCard,
              theme: Wb.editTheme,
              extraKeys: {
                'Ctrl-/': 'toggleComment',
                'Ctrl-,': function(doc) {
                  if (doc.modifyCursor)
                    doc.setCursor(doc.modifyCursor);
                },
                'Shift-Ctrl-F': function(doc) {
                  if (doc.options.readOnly)
                    return;
                  var cursor = doc.getCursor(),
                    scroll = doc.getScrollInfo();
                  Ide.clearBookmark();
                  doc.autoFormatRange({
                    line: 0,
                    ch: 0
                  }, {
                    line: Number.MAX_VALUE,
                    ch: Number.MAX_VALUE
                  });
                  doc.scrollTo(scroll.left, scroll.top);
                  doc.setCursor(cursor);
                }
              }
            };
            switch (fileExt) {
              case 'js':
              case 'ss':
                config.highlightSelectionMatches = {
                  showToken: /\w/
                };
                config.isServerScript = fileExt == 'ss';
                config.extraKeys['Alt-/'] = 'autocomplete';
                config.extraKeys['.'] = function(doc) {
                  if (doc.options.readOnly)
                    return;
                  doc.replaceSelection('.');
                  if (doc.hintTimer)
                    clearTimeout(doc.hintTimer);
                  doc.hintTimer = setTimeout(function() {
                    CodeMirror.showHint(doc);
                  }, 100);
                };
                extConfig = {
                  mode: {
                    name: 'text/javascript',
                    globalVars: true
                  },
                  gutters: ['CodeMirror-lint-markers'],
                  lint: true,
                  matchBrackets: true
                };
                break;
              case 'css':
                extConfig = {
                  mode: 'text/css',
                  gutters: ['CodeMirror-lint-markers'],
                  lint: true,
                  matchBrackets: true
                };
                break;
              case 'java':
                config.highlightSelectionMatches = {
                  showToken: /\w/
                };
                extConfig = {
                  mode: 'text/x-java',
                  matchBrackets: true
                };
                break;
              case 'xml':
                extConfig = {
                  mode: 'application/xml',
                  matchBrackets: true
                };
                break;
              case 'html':
              case 'htm':
              case 'htxt':
                extConfig = {
                  mode: 'htmlmixed',
                  matchBrackets: true
                };
                break;
              case 'jsp':
              case 'jspx':
                config.highlightSelectionMatches = {
                  showToken: /\w/
                };
                extConfig = {
                  mode: 'application/x-jsp',
                  matchBrackets: true
                };
                break;
              case 'json':
              case 'expjson':
                extConfig = {
                  mode: 'application/json',
                  gutters: ['CodeMirror-lint-markers'],
                  matchBrackets: true
                };
                break;
              case 'sql':
                extConfig = {
                  mode: 'text/x-sql',
                  matchBrackets: true
                };
                break;
              default:
                extConfig = {
                  mode: 'text/plain'
                };
            }
            Ext.apply(config, extConfig);
            editor = CodeMirror.fromTextArea(me.el.down('textarea', true), config);
            editor.card = me;
            editor.cursorLabel = me.cursorLabel;
            me.editor = editor;
            setTimeout(function() {
              if (fileExt == 'js' || fileExt == 'ss' || fileExt == 'css')
                if (content.content.length > 0)
                  editor.lintCallback = function(cm) {
                    Ide.getMarkers(editor, content.path, innerMode ? editor.card : null);
                  };
              editor.setValue(content.content);
              editor.savedText = content.content;
              editor.on('change', function(doc) {
                if (doc.notRecordChange)
                  return;
                var card = doc.card;
                doc.modifyCursor = Ext.apply({}, doc.lastCursor);
                if (!card.isModified && doc.savedText !== doc.getValue()) {
                  if (card.innerMode) {
                    card.isModified = true;
                    Ide.setModified(card.ownerCt);
                  } else
                    Ide.setModified(card);
                }
              });
              editor.on('cursorActivity', function(doc) {
                var cur = doc.getCursor();
                doc.lastCursor = cur;
                doc.cursorLabel.setText((cur.line + 1) + ' : ' + (cur.ch + 1));
                Ide.recordActivity();
              });
              editor.clearHistory();
              Ext.callback(callback, this, [editor]);
            }, 10);
          }
        }
      }
    };
    if (!sourceCard) {
      Ext.apply(cardConfig, {
        tabConfig: {
          tooltip: innerMode ? (Ide.getNodePath(content.node) + '/' + content.itemName) : Ide.getPathText(content.path)
        }
      });
    }
    if (innerMode) {
      cardConfig.bbar.unshift({
        itemId: 'funcBtn',
        handler: Ide.toggleEditor
      });
      cardConfig.bbar.push({
        itemId: 'paramsLbl',
        xtype: 'tbtext'
      });
      Ext.apply(cardConfig, {
        iconCls: content.iconCls,
        node: content.node,
        innerMode: true,
        sourceCard: sourceCard,
        fileExt: fileExt,
        itemName: content.itemName,
        itemType: content.itemType
      });
      if (!sourceCard) {
        Ext.apply(cardConfig, {
          commitChange: function() {
            var me = this;
            if (me.isModified) {
              Ide.updateProperty(me.ownerCt.property, me.node, me.itemType, me.itemName, me.editor.getValue(), true);
              me.editor.savedText = me.editor.getValue();
              me.isModified = false;
            }
          }
        });
        Ext.apply(cardConfig.listeners, {
          beforedeactivate: function(me) {
            me.commitChange();
          }
        });
      }
    } else {
      var isImage = Wb.indexOf(['gif', 'jpg', 'png', 'bmp'], fileExt) != -1;
      cardConfig.bbar.unshift({
        itemId: 'funcBtn',
        text: isImage ? 'Base64' : content.charset,
        disabled: isImage,
        handler: Ide.setCharset
      });
      Ext.apply(cardConfig, {
        path: content.path,
        file: content.file,
        icon: content.icon,
        lastModified: Wb.strToDate(content.lastModified)
      });
      Ext.apply(cardConfig.listeners, {
        beforeclose: function(card) {
          if (card.isModified) {
            Wb.choose('"' + card.file + '" 已经被修改，保存所做的更改吗？',
              function(btn) {
                if (btn == 'yes')
                  Ide.saveFile(false, function() {
                    card.close();
                  });
                else if (btn == 'no') {
                  Wb.unModified(card);
                  card.close();
                }
              });
            return false;
          }
        }
      });
    }
    return tab.add(cardConfig);
  },
  /**
   * 更改模块指定节点的配置项/事件。
   * @param {PropertyGrid} grid 配置项/事件编辑器。
   * @param {NodeInterface} node 节点对象。
   * @param {String} type 类型，配置项或事件。
   * @param {String} name 名称。
   * @param {String} value 更改的值。
   */
  updateProperty: function(grid, node, type, name, value, ellipsis) {
    var rec, recIndex;
    if (node == grid.node) {
      recIndex = grid.store.findBy(function(rec) {
        return rec.data.type == type && rec.data.name == name;
      });
      rec = grid.store.getAt(recIndex);
      grid.store.stopUpdate = true;
      if (ellipsis)
        rec.set('value', Wb.toLine(value, 200));
      else
        rec.set('value', value);
      grid.store.stopUpdate = false;
    }
    type = type.toLowerCase();
    if (!node.data[type])
      node.data[type] = {};
    node.data[type][name] = value;
    if (name == 'itemId') {
      node.set('text', value);
      node.commit();
    }
  },
  /**
   * 设置表格可拖放文件。
   * @param {GridPanel} grid 设置的表格。
   */
  setFileDrop: function(grid) {
    function getRecord(e) {
      var view = grid.view,
        cellSelector = e.getTarget(view.cellSelector.cellSelector);
      if (cellSelector)
        return view.getRecord(view.findItemByChild(cellSelector));
      else
        return null;
    }
    new Ext.dd.DropTarget(grid.body.dom, {
      ddGroup: 'file',
      notifyOver: function(source, e, data) {
        var accept, invalid, record;
        record = getRecord(e);
        if (record) {
          Wb.each(data.records, function(node) {
            if (!node.isLeaf() || !Ide.getWebPath(node)) {
              invalid = true;
              return false;
            }
          });
          if (!invalid)
            accept = true;
        }
        this.acceptDrop = accept;
        if (accept) {
          grid.setSelection(record);
          return this.dropAllowed;
        }
      },
      notifyDrop: function(source, e, data) {
        if (this.acceptDrop) {
          var meta, path, isList, index, record = getRecord(e),
            orgType = record.data.type,
            type = orgType.toLowerCase(),
            name = record.data.name,
            value = record.get('value');
          meta = Ide.getMetaControl(grid.node).data[type][name];
          isList = meta.type == 'urlList';
          if ((e.ctrlKey || e.shiftKey) && value && isList && Ext.String.startsWith(Ext.String.trim(value), '['))
            value = Wb.decode(value);
          else
            value = [];
          Wb.each(data.records, function(node) {
            path = Ide.getNodeUrl(node);
            index = Wb.indexOf(value, path);
            if (e.shiftKey) {
              //删除
              if (index != -1)
                value.splice(index, 1);
            } else {
              //添加
              if (index == -1)
                value.push(path);
            }
          });
          if (value.length) {
            if (isList)
              value = '["' + value.join('", "') + '"]';
            else
              value = value[0];
          } else value = '';
          Ide.updateProperty(grid, grid.node, orgType, name, value);
          Ide.setModified();
        }
      }
    });
  },
  /**
   * 单元格编辑时设置文件选项卡的状态为被修改。
   */
  notifyChange: function() {
    Ide.setModified();
  },
  /**
   * 获取选择的文件。选择的文件将排序子文件和目录。
   * @return {String[]/Boolean} 如果未选择文件将返回false，否则返回选择的文件。
   */
  getSelFiles: function() {
    var parentSel,
      nodes = app.fileTree.getSelection(),
      files = [],
      selModel = app.fileTree.selModel;
    if (!nodes.length) {
      Wb.warn('请选择至少1个文件或目录。');
      return false;
    }
    Wb.each(nodes, function(node) {
      parentSel = false;
      node.bubble(function(n) {
        if (n == node)
          return;
        if (selModel.isSelected(n)) {
          parentSel = true;
          return false;
        }
      });
      if (parentSel)
        return;
      files.push(app.getPath(node));
    });
    return files;
  },
  /**
   * 执行版本控制的检入功能。
   */
  checkIn: function() {
    var path, file, files = app.fileTree.getSelection();
    if (files.length != 1) {
      Wb.warn('请选择1个需要检入的文件或目录。');
      return;
    }
    file = files[0];
    path = Ide.getPath(file);
    if (!Ext.String.startsWith(path + '/', Ide.webPath)) {
      Wb.warn('选择的文件“' + path + '”位于应用目录之外。');
      return;
    }
    Wb.run({
      url: 'm?xwl=dev/ide/version/check-in-win',
      single: true,
      success: function(scope) {
        scope.show(function(win, params) {
          Wb.request({
            url: 'm?xwl=dev/ide/version/check-in',
            params: params,
            timeout: -1,
            success: function(resp) {
              win.close();
              Wb.reload(app.fileTree);
            }
          });
        }, path.substring(Ide.webPath.length) + (file.isLeaf() ? '' : '/'), Wb.getInfo(app.fileTree));
      }
    });
  },
  /**
   * 执行版本控制的检出功能。
   */
  checkOut: function() {
    var outOfScope, files = app.getSelFiles();
    if (!files)
      return;
    Wb.each(files, function(file) {
      if (!Ext.String.startsWith(file + '/', Ide.webPath)) {
        Wb.warn('选择的文件“' + file + '”位于应用目录之外。');
        outOfScope = true;
        return false;
      }
    });
    if (outOfScope)
      return;
    Wb.run({
      url: 'm?xwl=dev/ide/version/check-out-win',
      single: true,
      success: function(scope) {
        scope.show(function(win) {
          Wb.request({
            url: 'm?xwl=dev/ide/version/check-out',
            params: {
              files: files
            },
            timeout: -1,
            out: win,
            success: function(resp) {
              win.close();
              Wb.tip('选择的文件已经成功检出。');
            }
          });
        }, Wb.getInfo(app.fileTree));
      }
    });
  },
  /**
   * 定义文本编辑器。
   *
   * @param {Boolean} isItemId 是否是itemId属性。
   */
  editString: function(isItemId) {
    var configs = {
      xtype: 'textfield',
      listeners: {
        change: Ide.notifyChange
      }
    };
    if (isItemId) {
      Ext.apply(configs, {
        allowBlank: false,
        validator: Ide.nodeItemIdValidator
      });
    }
    return configs;
  },
  /**
   * 定义绑定编辑器。
   *
   * @param {Object} confg 配置参数。
   */
  editBind: function(config) {
    return {
      xtype: 'combo',
      store: [],
      bindConfig: config,
      listeners: {
        change: Ide.notifyChange,
        focus: Ide.getBindData
      }
    };
  },
  /**
   * 获取绑定的数据。
   */
  getBindData: function(combo) {
    var type, parentType, baseNode, tree = Ide.activeCard.tree,
      config = combo.bindConfig,
      rootNode = tree.getRootNode(),
      addApp = config.app !== false,
      data = [];

    if (config.owned)
      baseNode = Ide.activeCard.property.node;
    else
      baseNode = rootNode;

    function maybeAdd(item) {
      var found = false;
      Wb.each(data, function(val) {
        if (val.field1 == item.field1) {
          found = true;
          return false;
        }
      });
      if (!found)
        data.push(item);
    }

    function match(node) {
      var found;
      Wb.each(config.controls, function(item) {
        var controlType = Wb.namePart(item),
          subControlType = Wb.valuePart(item);
        if ((controlType == type || controlType == '*') && (subControlType === '' ||
            node.firstChild && subControlType == node.firstChild.data.type)) {
          found = true;
          return false;
        }
      });
      return found;
    }
    baseNode[config.deep !== false ? 'cascadeBy' : 'eachChild'](function(node) {
      if (config.owned && baseNode == node || node === rootNode)
        return;
      type = node.data.type;
      parentType = node.parentNode ? node.parentNode.data.type : '';
      if ((config.root === false || parentType == 'module' || parentType == 'folder') &&
        match(node)) {
        if (Wb.verifyName(node.data.text) === true)
          maybeAdd({
            field1: (addApp ? 'app.' : '') + node.data.text
          });
        else {
          if (addApp)
            maybeAdd({
              field1: 'app["' + node.data.text + '"]'
            });
          else
            maybeAdd({
              field1: node.data.text
            });
        }
      }
    });
    data.sort(function(v1, v2) {
      return v1.field1.toUpperCase().localeCompare(v2.field1.toUpperCase());
    });
    combo.store.loadData(data);
  },
  /**
   * JNDI枚举编辑器。
   */
  editJndi: function() {
    return {
      xtype: 'combo',
      store: Ide.jndiList,
      listeners: {
        change: Ide.notifyChange
      }
    };
  },
  /**
   * 定义枚举编辑器。
   *
   * @param {Array} list 枚举列表数据。
   */
  editEnum: function(list) {
    return {
      xtype: 'combo',
      store: list,
      listeners: {
        change: Ide.notifyChange
      }
    };
  },
  /**
   * 定义图标样式编辑器。
   */
  editIconCls: function() {
    return {
      xtype: 'combo',
      store: Ide.iconData,
      anyMatch: true,
      getValue: function() {
        var rec, val = Ext.form.field.ComboBox.prototype.getValue.apply(this, arguments);
        if (val && !Ext.String.endsWith(val, '_icon')) {
          rec = this.store.findExactRec('field1', val + '_icon');
          if (rec)
            return rec.data.field1;
        }
        return val;
      },
      tpl: [
        '<div><tpl for=".">',
        '<div class="x-boundlist-item wb_thumb" data-qtip="{field1}"><div class="wb_icon1 {field1}"></div></div>',
        '</tpl></div>'
      ],
      listeners: {
        change: Ide.notifyChange
      }
    };
  },
  /**
   * 定义glyph图标编辑器。
   */
  editGlyph: function() {
    return {
      xtype: 'combo',
      store: Ide.glyphClasses,
      anyMatch: true,
      tpl: [
        '<div><tpl for=".">',
        '<div class="x-boundlist-item wb_thumb wb_glyph3" data-qtip="{field2} ({field1})">',
        '{[String.fromCharCode(parseInt(values.field1,16))]}',
        '</div></tpl></div>'
      ],
      getValue: function() {
        var rec, val = Ext.form.field.ComboBox.prototype.getValue.apply(this, arguments);
        rec = this.store.findExactRec('field2', val);
        if (rec)
          return rec.data.field1;
        else
          return val;
      },
      listeners: {
        change: Ide.notifyChange
      }
    };
  },
  /**
   * 编辑属性编辑器中的脚本对象。文本对象允许使用富编辑器来编辑脚本。
   * @param {Boolean} [silence] 是否显示反馈的对话框信息。
   * @param {Number} [lineNo] 打开后转到的行号。
   * @param {Number} [ch] 打开后转到的列号。
   */
  doEdit: function(silence, lineNo, ch) {
    var grid = Ide.activeCard.property,
      rec = grid.getSelection()[0],
      node = grid.store.node,
      control = Ide.getMetaControl(node),
      itemType, itemName, lowerItemType, metaType, editType, card,
      icon = {
        text: 'file_txt_icon',
        html: 'web_icon',
        js: 'file_js_icon',
        ss: 'file_ss_icon',
        sql: 'sql_icon',
        expJson: 'object_icon'
      };

    if (!rec) {
      if (!silence)
        Wb.warn('请选择需要编辑的属性/事件。');
      return;
    }
    if (!control) {
      if (!silence)
        Wb.warn('控件 "' + node.data.type + '" 没有找到。');
      return;
    }
    itemType = rec.data.type;
    lowerItemType = itemType.toLowerCase();
    itemName = rec.data.name;
    metaType = control.data[lowerItemType][itemName];
    if (!metaType) {
      if (!silence)
        Wb.warn('该属性没有定义。');
      return;
    }
    editType = metaType.type;
    if (!icon[editType]) {
      if (!silence)
        Wb.warn('该属性没有定义编辑器。');
      return;
    }
    grid.editPlugin.completeEdit();
    Ide.activeCard.items.each(function(subCard) {
      if (subCard.editor && subCard.node == node &&
        subCard.itemName == itemName && subCard.itemType == itemType) {
        card = subCard;
        return false;
      }
    });

    function selLine() {
      card.ownerCt.setActiveTab(card);
      if (lineNo !== undefined) {
        card.editor.setCursor(lineNo - 1, ch);
        card.editor.focus();
      }
    }
    if (card) {
      selLine();
    } else {
      card = Ide.openFile(Ide.activeCard, {
        content: (node.data[lowerItemType] || {})[itemName] || '',
        file: '.' + editType,
        title: node.data.text + '.' + itemName,
        node: node,
        path: Ide.activeCard.path,
        params: metaType.params,
        itemName: itemName,
        itemType: itemType,
        iconCls: icon[editType]
      }, true, selLine);
    }
  },
  /**
   * 定义颜色编辑器。
   */
  editColor: function() {
    return {
      xtype: 'colorfield',
      listeners: {
        change: Ide.notifyChange
      }
    };
  },
  /**
   * 定义脚本编辑器。脚本编辑器类型包括js, ss, css, sql, html和普通文本等。
   */
  editText: function() {
    return {
      xtype: 'trigger',
      editable: false,
      fieldCls: 'wb-disabled x-form-field',
      triggerCls: 'x-form-ellipsis-trigger',
      onTriggerClick: function() {
        this.ownerCt.completeEdit();
        Ide.doEdit();
      },
      listeners: {
        afterrender: {
          single: true,
          fn: function(me) {
            me.mon(me.inputEl, 'dblclick', function() {
              me.ownerCt.completeEdit();
              Ide.doEdit();
            });
          }
        }
      }
    };
  },
  /**
   * 根据设计视图中控件节点获取控件树中的元控件节点对象。
   * @param {NodeInterface} node 包含控件类别的节点对象。
   * @return {NodeInterface} 元控件节点对象。
   */
  getMetaControl: function(node) {
    return Ide.controlMap[node.data.type];
  },
  /**
   * 销毁属性编辑器所有的控件。
   * @param {PropertyGrid} propertygrid 属性编辑器对象。
   */
  destroyEditors: function(propertygrid) {
    var editor, cfgs = propertygrid.sourceConfig;
    Wb.each(cfgs, function(key, value) {
      editor = value.editor;
      if (Ext.isFunction(editor.destroy))
        editor.destroy();
    });
  },
  forceVisible: function(card) {
    var oh = Ide.fileTab.tabBar.layout.overflowHandler;
    if (oh && card)
      oh.scrollToItem(card.tab);
  },
  /**
   * 加载节点中的配置项和事件至属性编辑器。
   * @param {NodeInterface} node 节点对象。
   * @param {Ext.grid.property.Grid} property 属性编辑器。
   */
  loadProperties: function(node, property) {
    var data = [],
      sourceConfig = {},
      control = Ide.getMetaControl(node);
    if (!control) {
      Wb.warn('控件 "' + node.data.type + '" 没有找到。');
      return;
    }

    function getData(nodeData, controlData, type) {
      var isText, nodeValue;
      Wb.each(controlData, function(key, value) {
        if (key == 'itemId') {
          value.bold = true;
        }
        isText = false;
        switch (value.type) {
          case 'expBool':
            sourceConfig[key] = {
              editor: Ide.editEnum(['true', 'false'])
            };
            break;
          case 'enum':
            sourceConfig[key] = {
              editor: Ide.editEnum(value.list || value.params)
            };
            break;
          case 'jndi':
            sourceConfig[key] = {
              editor: Ide.editJndi()
            };
            break;
          case 'iconCls':
            sourceConfig[key] = {
              editor: Ide.editIconCls()
            };
            break;
          case 'glyph':
            sourceConfig[key] = {
              editor: Ide.editGlyph()
            };
            break;
          case 'bind':
          case 'expBind':
            sourceConfig[key] = {
              editor: Ide.editBind(value)
            };
            break;
          case 'color':
            sourceConfig[key] = {
              editor: Ide.editColor()
            };
            break;
          case 'text':
          case 'html':
          case 'js':
          case 'ss':
          case 'sql':
          case 'expJson':
            isText = true;
            sourceConfig[key] = {
              editor: Ide.editText()
            };
            break;
          default:
            sourceConfig[key] = {
              editor: Ide.editString(key == 'itemId')
            };
            break;
        }
        nodeValue = nodeData[key] || '';
        data.push({
          type: type,
          name: key,
          value: isText ? Wb.toLine(nodeValue, 200) : nodeValue,
          meta: value
        });
      });

      Wb.each(nodeData, function(key, value) {
        //如果控件没有定义该属性
        if (!controlData[key]) {
          data.push({
            type: type,
            name: key,
            value: value,
            meta: Ext.apply({
              deprecated: true
            }, value)
          });
          sourceConfig[key] = {
            editor: Ide.editString()
          };
        }
      });
    }
    getData(node.data.configs || {}, control.data.configs, 'Configs');
    getData(node.data.events || {}, control.data.events, 'Events');
    property.node = node;
    property.store.node = node;
    property.suspendEvents();
    Ide.destroyEditors(property);
    property.sourceConfig = sourceConfig;
    property.store.loadData(data);
    property.resumeEvents();
  },
  /**
   * 根据当前运行的模块转到对应的模块文件。
   */
  toggleRun: function() {
    if (Ide.runBtn.disabled)
      return;
    var card, path = Ide.activeCard.runFile;
    if (path)
      Ide.doOpen(path);
    else if (Ide.activeCard.path) {
      card = Ide.fileTab.child('[runFile=' + Ide.activeCard.path + ']');
      if (card)
        Ide.fileTab.setActiveTab(card);
      else Ide.run();
    }
  },
  /**
   * 打开模块至新的选项卡。
   * @param {Object} tree 模块数据对象。
   * @return {Panel} 打开模块的选项卡。
   */
  openModule: function(tree) {
    var card;
    card = Ide.fileTab.add({
      xtype: 'tabpanel',
      title: Ext.String.ellipsis(tree.file, 20),
      tabConfig: {
        tooltip: Ide.getPathText(tree.path)
      },
      iconCls: tree.iconCls,
      path: tree.path,
      cardType: 'module',
      border: false,
      file: tree.file,
      hideMode: Ext.isIE ? 'offsets' : 'display',
      lastModified: tree.lastModified,
      closable: true,
      deferredRender: false,
      region: 'center',
      plugins: ['tabreorderer', 'tabclosemenu'],
      commitChange: function() {
        var me = this,
          card = me.getActiveTab();

        if (card.commitChange)
          card.commitChange();
      },
      listeners: {
        afterrender: {
          single: true,
          fn: function(me) {
            var designCard = me.getComponent('designCard');
            me.designCard = designCard;
            me.property = designCard.getComponent('property');
            me.tree = designCard.getComponent('tree');
          }
        },
        activate: function(me) {
          var card = me.getActiveTab();
          if (!card) return;
          if (card.lastScrollInfo)
            card.editor.scrollTo(card.lastScrollInfo.left, card.lastScrollInfo.top);
          setTimeout(function() {
            try {
              if (card.editor.needRefresh) {
                card.editor.refresh();
                card.editor.needRefresh = false;
              }
              card.editor.focus();
            } catch (e) {
              //忽略
            }
          }, 10);
        },
        beforetabchange: function(me, newCard, oldCard) {
          var designCard = newCard.itemId == 'designCard';
          if (newCard.layoutCard || designCard)
            Ide.controlTree.show();
          else
            Ide.controlTree.hide();
          Ide.forceVisible(newCard.ownerCt);
        },
        tabchange: function(me, newCard, oldCard) {
          Ide.recordActivity();
        },
        beforeclose: function(card) {
          if (card.isModified) {
            Wb.choose('"' + card.file + '" 已经被修改，保存所做的更改吗？',
              function(btn) {
                if (btn == 'yes')
                  Ide.saveFile(false, function() {
                    card.close();
                  });
                else if (btn == 'no') {
                  Wb.unModified(card);
                  card.close();
                }
              });
            return false;
          }
        },
        close: function(me) {
          Ide.clearMarkers(me.path);
        }
      },
      items: [{
        xtype: 'container',
        itemId: 'designCard',
        layout: 'border',
        title: '设计',
        border: false,
        iconCls: 'model_icon',
        reorderable: false,
        commitChange: function() {
          var grid = this.ownerCt.property,
            plug = grid.editPlugin;
          if (plug.editing)
            plug.completeEdit();
        },
        items: [{
          itemId: 'property',
          xtype: 'propertygrid',
          region: 'west',
          split: true,
          width: 440,
          style: 'border:0 1px 0 0;',
          nameColumnWidth: 150,
          viewConfig: {
            stripeRows: false
          },
          store: new Ext.data.Store({
            fields: ['type', 'meta', 'name', 'value'],
            groupField: 'type',
            listeners: {
              update: function(me, record, operation) {
                if (operation == 'commit' && !me.stopUpdate) {
                  var name = record.get('name'),
                    value = record.get('value') || '',
                    node = me.node,
                    type = record.get('type').toLowerCase();
                  if (!node.data[type])
                    node.data[type] = {};
                  node.data[type][name] = value;
                  if (name == 'itemId') {
                    Ide.syncBindRef(node.data.text, value);
                    node.set('text', value);
                    node.commit();
                    Ide.syncNodes(node);
                  } else if (name == 'normalName') {
                    node.set('normalName', value);
                    node.commit();
                  }
                }
              }
            }
          }),
          features: [{
            ftype: 'grouping',
            groupHeaderTpl: '{name}',
            collapsible: false
          }],
          listeners: {
            beforedestroy: function(me) {
              Ide.destroyEditors(me);
            },
            afterrender: {
              single: true,
              fn: function(me) {
                Ide.setFileDrop(me);
                me.editPlugin = me.findPlugin('cellediting');
                me.columns[0].renderer = function(value, meta, record) {
                  var config = record.data.meta;
                  meta.tdCls = 'wb-solid';
                  if (config.deprecated)
                    meta.style = 'text-decoration:line-through;';
                  if (config.type == 'exp')
                    value += ':';
                  if (config.bold)
                    return '<strong>' + value + '</strong>';
                  else return value;
                };
                me.columns[1].renderer = function(value, meta, record) {
                  if (value) {
                    if (!Ext.String.startsWith(value, '@')) {
                      var glyph, type = record.data.meta.type;
                      switch (type) {
                        case 'iconCls':
                          value = Wb.getIcon(value) + value;
                          break;
                        case 'color':
                          value = '<div class="wb_icon" style="background-color:' + value + ';"></div>' + value;
                          break;
                        case 'glyph':
                          glyph = Wb.find(Ide.glyphClasses, 0, value);
                          value = '<span class="wb_glyph"> ' + String.fromCharCode(parseInt(value, 16)) +
                            '</span> ' + (glyph ? glyph[1] : '') + ' (' + value + ')';
                          break;
                        default:
                          value = Ext.htmlEncode(Ext.String.ellipsis(value, 200));
                      }
                    } else
                      value = Ext.htmlEncode(Ext.String.ellipsis(value, 200));
                  }
                  return value;
                };
              }
            }
          }
        }, {
          itemId: 'tree',
          xtype: 'treepanel',
          region: 'center',
          title: '对象视图',
          iconCls: 'list_icon',
          multiSelect: true,
          popupMenu: app.objectViewMenu,
          tools: Wb.getTreeTools({
            refresh: false,
            search: true
          }),
          rootVisible: false,
          hideHeaders: true,
          cls: 'x-autowidth-table',
          columns: [{
            xtype: 'treecolumn',
            dataIndex: 'text',
            width: Ext.isIE6 ? '100%' : 10000,
            renderer: function(value, meta, record) {
              var normalName = record.data.configs.normalName;
              value = Wb.encodeHtml(value);
              if (normalName)
                return value + ' (' + Wb.encodeHtml(normalName) + ')';
              else return value;
            }
          }],
          store: {
            fields: ['type', 'text', 'configs', 'events', 'meta', 'title', 'pageLink', {
              name: 'hidden',
              type: 'bool'
            }, {
              name: 'inframe',
              type: 'bool'
            }],
            root: tree
          },
          listeners: {
            selectionchange: function(a, selected) {
              var node = selected[0];
              if (!node) node = this.getRootNode().firstChild;
              Ide.loadProperties(node, this.up('tabpanel').property);
            }
          },
          viewConfig: {
            plugins: {
              ptype: 'treeviewdragdrop',
              ddGroup: 'controlList'
            },
            listeners: {
              beforedrop: function(node, data, om, dp, dh) {
                if (data.view === Ide.controlTree.view)
                  data.copy = true;
                Ide.autoRename(dp == 'append' ? om : om.parentNode, data.records, dh);
              },
              drop: function(node, data, om, dp) {
                var newNode, tree = om.getOwnerTree();
                if (data.view == Ide.controlTree.view) {
                  newNode = data.records[0];
                  Ide.setNewNode(newNode, newNode.parentNode);
                  tree.setSelection(newNode);
                  Ide.activeCmp = 'control';
                } else {
                  Ide.autoRename(dp == 'append' ? om : om.parentNode, data.records);
                  tree.setSelection(data.records);
                  Ide.syncNodes(data.records);
                }
                Ide.setModified();
              },
              nodedragover: function(node, dp, data) {
                var sourceNode = data.records[0];
                if (sourceNode.getOwnerTree() == Ide.controlTree && !sourceNode.data.control ||
                  node.getDepth() == 1 && dp != 'append')
                  return false;
              }
            }
          }
        }]
      }]
    });
    Ide.fileTab.setActiveTab(card);
    Wb.selFirst(card.tree);
    Ide.openFile(Ide.activeCard, {
      content: '',
      file: '.js',
      title: '源码',
      sourceCard: true,
      itemId: 'scriptCard',
      path: Ide.activeCard.path,
      iconCls: 'script_icon',
      reorderable: false
    }, true);
    Ide.activeCmp = 'control';
    return card;
  },
  /**
   * 设置新添加节点的属性。对itemId重命名，初始化配置项和事件。
   * @param {NodeInterface} node 节点对象。
   * @param {NodeInterface} parentNode 设置节点的父节点对象。
   * @param {Boolean} noNewItemId 是否不自动设置itemId属性，默认为false。
   * @param {Object} extraConfigs 配置项参数。
   */
  setNewNode: function(node, parentNode, noNewItemId, extraConfigs) {
    function getNewItemId(itemId, autoName) {
      var foundName, itemIdMap = {},
        index = 1;
      parentNode.eachChild(function(n) {
        itemIdMap[n.data.configs.itemId] = true;
      });
      if (autoName) {
        Wb.each(autoName, function(name) {
          if (!itemIdMap[name]) {
            foundName = name;
            return false;
          }
        });
        if (foundName)
          return foundName;
      }
      while (itemIdMap[itemId + index]) {
        index++;
      }
      return itemId + index;
    }
    var tree = parentNode.getOwnerTree(),
      itemId = node.data.id,
      nodeMeta = Ide.getMetaControl(node),
      parentMeta = Ide.getMetaControl(parentNode),
      autoNames = node.data.general.autoNames,
      autoName, newItemId, configs;
    if (nodeMeta.data.general.tag && nodeMeta.data.general.tag.lib == 2 && Ext.String.startsWith(itemId, 't'))
      itemId = itemId.substring(1);
    if (autoNames && (autoName = (autoNames[parentNode.data.type] ||
        (parentMeta.data.general.root ? null : autoNames.any)))) {
      newItemId = getNewItemId(itemId, autoName.split(','));
    } else {
      if (noNewItemId) newItemId = itemId;
      else newItemId = getNewItemId(itemId);
    }
    tree.suspendEvents();
    node.set('id', Wb.getId());
    node.set('text', newItemId);
    delete node.data.general;
    configs = {
      itemId: newItemId
    };
    Wb.each(nodeMeta.data.configs, function(name, value) {
      if (Wb.isValue(value.value))
        configs[name] = value.value.toString();
    });
    if (Ide.anchorRightBtn.pressed && node.data.configs.labelAlign)
      configs.labelAlign = 'right';
    if (extraConfigs)
      Ext.apply(configs, extraConfigs);
    node.set('configs', configs);
    node.set('events', null);
    node.commit();
    tree.resumeEvents();
  },
  /**
   * 根据控件树的控件在模块中添加新的控件。
   * @param {Ext.data.Record} record 添加的控件。
   * @param {Boolean} noNewItemId 是否不自动设置itemId属性，默认为false。
   * @param {Object} [extraConfigs] 该参数为设计模式下附加的参数。
   * @return {NodeInterface} node 添加的节点对象。
   */
  addControl: function(record, noNewItemId, extraConfigs) {
    if (!Ide.activeCard || !record.data.control)
      return;
    var tree = Ide.activeCard.tree,
      ns = tree.getSelection(),
      node, root = tree.getRootNode(),
      newNode, id, designNode;
    newNode = record.copy();
    if (extraConfigs) {
      //设计模式下
      designNode = extraConfigs.node;
      delete extraConfigs.node;
      Ide.setNewNode(newNode, designNode, noNewItemId, extraConfigs);
      node = Wb.append(newNode, designNode, false, false);
    } else {
      if (root.firstChild)
        root = root.firstChild;
      if (ns.length === 0)
        node = root;
      else
        node = ns[0];
      if (Ext.EventObject.ctrlKey || node == root) {
        Ide.setNewNode(newNode, node, noNewItemId);
        node = Wb.append(newNode, node);
      } else {
        Ide.setNewNode(newNode, node.parentNode, noNewItemId);
        node = Wb.insertAfter(newNode, node);
      }
    }
    Ide.activeCmp = 'control';
    Ide.setModified();
    //设计模式下
    if (extraConfigs)
      Ide.activeCard.getActiveTab().comps.itemId.focus(true, true);
    return node[0];
  },
  /**
   * 保存并运行当前打开的模块。
   */
  run: function() {
    if (Ide.runBtn.disabled)
      return;
    var card = Ide.activeCard;
    if (card.bindFile) {
      Wb.open({
        reloadCard: card,
        success: function(scope) {
          if (Ide.activeCard === this)
            Ide.activeScope = scope;
        }
      });
    } else {
      Ide.saveFile(false, function() {
        var newCard, relPath = Ide.getPathText(card.path),
          nodeData = card.tree ? card.tree.getRootNode().data : null;
        newCard = Wb.open(Ext.apply({
          url: Wb.toUrl(relPath),
          title: card.file,
          iconCls: 'web_icon',
          inframe: nodeData ? nodeData.inframe : true,
          tooltip: relPath,
          reload: true,
          success: function(scope) {
            if (Ide.activeCard === this)
              Ide.activeScope = scope;
          }
        }, (nodeData && nodeData.pageLink) ? Wb.decode(nodeData.pageLink) : null));
        if (newCard)
          newCard.runFile = card.path;
      });
    }
  },
  /**
   * 在配置项/事件和其编辑器之间进行切换。
   */
  toggleEditor: function() {
    var subCard, card = Ide.activeCard;
    if (card && card.cardType == 'module')
      subCard = card.getActiveTab();
    if (!(subCard && (subCard == card.designCard || subCard.itemType && subCard.itemName))) {
      Wb.warn('请在模块编辑器属性或脚本编辑器之间进行切换。');
      return;
    }
    if (card.getActiveTab() == card.designCard) {
      Ide.doEdit();
    } else {
      var recIndex, grid = card.property;
      card.setActiveTab('designCard');
      card.tree.setSelection(subCard.node);
      recIndex = grid.store.findBy(function(rec) {
        return rec.data.type == subCard.itemType && rec.data.name == subCard.itemName;
      });
      grid.setSelection(recIndex);
      grid.view.focusRow(recIndex);
    }
  },
  /**
   * 设置按钮是否有效。
   */
  setButtons: function() {
    var card = Ide.activeCard,
      hasModified = Wb.getModifiedTitle(Ide.fileTab) !== null;
    Ide.saveBtn.setDisabled(!(card && card.isModified));
    Ide.saveBtn.setIconCls('save' + (Ide.saveBtn.disabled ? '_disabled' : '') + '_icon');
    Ide.saveAllBtn.setDisabled(!hasModified);
    Ide.saveAllBtn.setIconCls('save_all' + (Ide.saveAllBtn.disabled ? '_disabled' : '') + '_icon');
    Ide.runBtn.setDisabled(!(card && (card.bindFile || Ide.getFileUrl(card.path))));
    Ide.runBtn.setIconCls('run' + (Ide.runBtn.disabled ? '_disabled' : '') + '_icon');
  },
  /**
   * 清除文件相关的所有标记。
   * @param {String[]} files 文件列表。
   * @param {Panel} subCard 子面板。
   */
  clearMarkers: function(files, subCard) {
    var rows = [];
    if (!Ext.isArray(files))
      files = [files];
    Ide.markerGrid.store.each(function(record) {
      if ((!subCard || record.get('cardId') == subCard.id) && Wb.indexOf(files, record.get('path')) != -1)
        rows.push(record);
    });
    Ide.markerGrid.store.remove(rows);
  },
  /**
   * 获取指定编辑器的标记信息。
   * @param {CodeMirror} editor 编辑器对象。
   * @param {String} path 文件路径。
   * @param {Panel} subCard 子面板。
   */
  getMarkers: function(editor, path, subCard) {
    var markers = [],
      lint, annotation, curLine, priorLine, curCh, priorCh;

    if (editor.state) {
      lint = editor.state.lint;
      if (lint && lint.marked) {
        priorLine = -1;
        priorCh = -1;
        Wb.each(lint.marked, function(mark) {
          annotation = mark.__annotation;
          curLine = annotation.from.line;
          curCh = annotation.from.ch;
          if (priorLine != curLine || curCh != priorCh)
            markers.push({
              message: annotation.message,
              path: path,
              line: curLine + 1,
              ch: annotation.from.ch,
              type: annotation.severity,
              cardId: subCard ? subCard.id : ''
            });
          priorLine = curLine;
          priorCh = curCh;
        });
      }
    }
    Ide.markerGrid.store.loadData(markers, true);
    if (markers.length > 0)
      Wb.highlight(Ide.markerGrid.tab.btnEl);
  },
  /**
   * 显示/隐藏多功能视图。
   */
  toggleView: function(a, pressed) {
    Ide.utilView.setVisible(pressed);
  },
  /**
   * 搜索文件。
   */
  searchFile: function() {
    Ide.doSearchFile();
  },
  /**
   * 显示/隐藏搜索文件框。
   * @param {Boolean} toggle 是否切换显示/隐藏操作，否则显示。
   */
  doSearchFile: function(toggle) {
    var bar = Ide.fileTree.getDockedComponent('searchBar'),
      visible = !toggle || !bar.isVisible();
    bar.setVisible(visible);
    if (visible)
      bar.getComponent('combo').focus(false, true);
  },
  /**
   * 根据文件路径选择文件节点。
   * @param {String} path 文件路径。
   */
  selectPath: function(path) {
    var baseNode;
    path = path || '';
    if (Ext.String.startsWith(path, 'm?xwl='))
      path = Ide.modulePath + path.substring(6) + '.xwl';
    path = path.replace(/\\/g, '/');
    if (Ide.isChild(path, Ide.modulePath))
      baseNode = Ide.modNode;
    else if (Ide.isChild(path, Ide.webPath))
      baseNode = Ide.appNode;
    else {
      path = '/Root/' + Ide.sysNode.get('text') + '/' + Ide.getPathText(path);
      path = path.split('/');
      path[3] = path[3] + '/'; //系统根目录补上/
      Ide.fileTree.selectPath(path.join('\n'), 'text', '\n');
      return;
    }
    Ide.fileTree.selectPath('/Root/' + baseNode.get('text') + '/' + Ide.getPathText(path), 'text');
  },
  /**
   * 获取当前模块对象视图中选择的节点。
   * @param {Boolean} all 是否返回所有选择的节点，默认返回第1个节点。
   * @return {NodeInterface} 当前模块中选择的节点。如果未选择则返回null。
   */
  getNode: function(all) {
    var card = Ide.activeCard,
      sels;
    if (!card || card.cardType != 'module' ||
      card.getActiveTab().itemId != 'designCard' ||
      (sels = card.tree.getSelection()).length === 0) {
      return null;
    }
    return all ? sels : sels[0];
  },
  /**
   * 清除当前模块选择节点的所有子节点的x, y, width和height属性。
   */
  clearCoord: function() {
    var nodes = Ide.getNode(true),
      data;
    if (!nodes) {
      Wb.warn('请在模块对象视图中选择至少1个节点。');
      return;
    }
    Wb.each(nodes, function(node) {
      data = node.data.configs;
      delete data.x;
      delete data.y;
      delete data.width;
      delete data.height;
    });
    Ide.refreshGrid();
    Ide.setModified();
  },
  /**
   * 批量更新所选择节点的配置项和事件。
   */
  batchUpdate: function() {
    var nodes = Ide.getNode(true);
    if (!nodes) {
      Wb.warn('请在对象视图中选择至少1个节点。');
      return;
    }
    Wb.prompt({
      title: '批量属性设置',
      width: 600,
      autoScroll: false,
      layout: {
        type: 'vbox',
        align: 'stretch'
      },
      defaults: {
        xtype: 'textarea',
        labelWidth: 60,
        flex: 1
      },
      items: [{
        fieldLabel: '配置项',
        itemId: 'configs'
      }, {
        fieldLabel: '事件',
        itemId: 'events'
      }],
      handler: function(values, win) {
        var configs, events;
        try {
          if (values.configs)
            configs = Wb.decode(values.configs);
          if (values.events)
            events = Wb.decode(values.events);
        } catch (e) {
          Wb.warn('配置项/事件中存在无效的值。');
          return;
        }
        Ide.doBatchUpdate(nodes, configs, events);
        win.close();
      }
    });
  },
  /**
   * 批量更新指定节点的配置项和事件。
   * @param {NodeInterface[]} nodes 更新的节点列表。
   * @param {Object} [configs] 更新的配置项对象。
   * @param {Object} [events] 更新的事件对象。
   */
  doBatchUpdate: function(nodes, configs, events) {
    var modified, control;
    Wb.each(nodes, function(node) {
      control = Ide.getMetaControl(node).data;
      if (configs) {
        Wb.each(configs, function(key, value) {
          if (control.configs[key]) {
            node.data.configs[key] = value.toString();
            modified = true;
          }
        });
      }
      if (events) {
        if (!node.data.events)
          node.data.events = {};
        Wb.each(events, function(key, value) {
          if (control.events && control.events[key]) {
            node.data.events[key] = value.toString();
            modified = true;
          }
        });
      }
    });
    Ide.refreshGrid();
    if (modified)
      Ide.setModified();
  },
  /**
   * 设置控件标签的对齐方式。
   * @param {Component} comp 设置的控件对象，通常为标签或表单字段。
   * @param {align} align 对齐方式。
   */
  setLabelAlign: function(comp, align) {
    if (comp instanceof Ext.form.field.Base || comp instanceof Ext.form.FieldContainer) {
      if (align == 'left') {
        comp.labelAlign = align;
        comp.labelEl.removeCls('x-form-item-label-right');
      } else if (align == 'right') {
        comp.labelAlign = align;
        comp.labelEl.addCls('x-form-item-label-right');
      }
    } else {
      comp.labelAlign = align;
      comp.el.setStyle('text-align', align);
    }
  },
  /**
   * 设置标签文本对齐方式触发的事件句柄。
   * @param {Button} button 点击的按钮。
   */
  setFieldAlign: function(button) {
    var done, comp, invalidAlign, control, baseField, align = button.alignValue,
      card = Ide.activeCard;
    if (card && card.cardType == 'module')
      card = card.getActiveTab();
    if (card && (card.layoutCard || card.itemId == 'designCard')) {
      if (card.layoutCard) {
        card.designer.items.each(function(item) {
          if (item.isSelected) {
            comp = item.bindComp;
            baseField = comp instanceof Ext.form.field.Base || comp instanceof Ext.form.FieldContainer;
            if (baseField || comp instanceof Ext.form.Label) {
              if (!done) done = true;
              if (baseField && align == 'center')
                invalidAlign = true;
              else Ide.setLabelAlign(comp, align);
            }
          }
        });
      } else {
        Wb.each(Ide.activeCard.tree.getSelection(), function(node) {
          control = Ide.getMetaControl(node);
          if (control.data.configs.labelAlign) {
            if (!done) done = true;
            if (control.data.id != 'label' && align == 'center')
              invalidAlign = true;
            else node.data.configs.labelAlign = align == 'left' ? '' : align;
          }
        });
        Ide.refreshGrid();
      }
    }
    button.ownerCt.ownerCt.hide();
    if (invalidAlign) Wb.warn('居中只对标签控件有效。');
    if (done) Ide.setModified();
    else Wb.warn('操作无任何效果。');
  },
  /**
   * 导出当前选择的目录。
   * @param {Boolean} zip 是否压缩导出的文件。
   */
  exportFile: function(zip) {
    var files = app.getSelFiles();
    if (!files)
      return;
    Wb.download('download', {
      files: files,
      zip: zip
    });
  },
  /**
   * 导入文件至当前选择的目录。
   * @param {Boolean} unzip 导入后是否解压缩zip文件。
   */
  importFile: function(unzip) {
    var path, node = Ide.fileTree.getSelection()[0];
    if (!node) {
      Wb.warn('请选择1个导入的目标目录。');
      return;
    }
    node = node.isLeaf() ? node.parentNode : node;
    path = Ide.getPath(node);
    Wb.run({
      url: 'upload-dialog',
      single: true,
      success: function(app) {
        Wb.highlight(node);
        app.upload({
          url: 'upload',
          iconCls: 'import_icon',
          title: (unzip ? '导入到选择目录并解压 - ' : '导入到选择目录 - ') + node.data.text,
          params: {
            path: path,
            sync: true,
            unzip: unzip
          },
          beforeUpload: unzip ? function() {
            if (!Ext.String.endsWith(app.file.getValue().toLowerCase(), '.zip')) {
              Wb.warn('请选择1个 zip 格式的文件。');
              return false;
            }
          } : null,
          success: function() {
            Wb.reload(Ide.fileTree);
          }
        });
      }
    });
  },
  /**
   * 向当前激活的窗口或面板随机填充数据。
   */
  fillForm: function() {
    var win = Ext.WindowManager.getActive();
    if (win instanceof Ext.container.Container) {
      Ide.fillData(win);
    } else if (Ide.activeCard && Ide.activeCard.bindFile)
      Ide.fillData(Ide.activeCard);
  },
  /**
   * 遍历容器所有控件，并对所有可赋值控件随机填充数据。
   * @param {Container} container 需要填充数据的容器。
   */
  fillData: function(container) {
    Ext.suspendLayouts();
    var strIndex = 1,
      num = 1;
    container.items.each(function(item) {
      if (!item.disabled && !item.readOnly && item.isVisible && item.isVisible()) {
        if (item instanceof Ext.form.field.Checkbox)
          item.setValue(true);
        else if (item instanceof Ext.form.field.Date || item instanceof Ext.form.field.Time ||
          item instanceof Ext.form.field.Datetime)
          item.setValue(new Date());
        else if (item instanceof Ext.form.field.ComboBox) {
          if (item.store && item.valueField && item.store.getCount() > 0)
            item.setValue(item.store.getAt(0).get(item.valueField));
          else item.setValue('v' + (strIndex++));
        } else if (item instanceof Ext.form.field.Number)
          item.setValue(num++);
        else if (item instanceof Ext.form.field.Text && !(item instanceof Ext.form.field.File)) {
          if (item.vtype == 'email')
            item.setValue('v' + (strIndex++) + '@d.com');
          else if (item.vtype == 'url')
            item.setValue('http://www.v' + (strIndex++) + '.com');
          else if (item.minLength)
            item.setValue(Ext.String.repeat('a', item.minLength));
          else item.setValue('v' + (strIndex++));
        } else if (item instanceof Ext.container.Container)
          Ide.fillData(item);
      }
    });
    Ext.resumeLayouts(true);
  },
  /**
   * 设置控件对齐方式触发的事件句柄。
   * @param {Button} button 点击的按钮。
   */
  setAlign: function(button) {
    var card = Ide.activeCard;
    if (card && card.cardType == 'module')
      card = card.getActiveTab();
    if (!card || !card.layoutCard) {
      Wb.warn('请在布局设计器中选择需要对齐的控件。');
      return;
    }
    var type = button.type,
      v, u, w, h, p = card.designer,
      tl, tr, tw, ml = null,
      mr = null,
      mw = null,
      fw = p.getWidth(),
      offL, offH, flg = false,
      tt, tb, th, mt = null,
      mb = null,
      mh = null,
      fh = p.getHeight() - (p.header ? p.header.getHeight() : 0);
    p.items.each(function(o) {
      if (o.isSelected) {
        u = o.getLocalXY();
        w = o.getWidth();
        h = o.getHeight();
        tl = u[0];
        if (ml === null || tl < ml)
          ml = tl;
        tr = u[0] + w;
        if (mr === null || tr > mr)
          mr = tr;
        tw = w;
        if (mw === null || tw > mw)
          mw = tw;
        tt = u[1];
        if (mt === null || tt < mt)
          mt = tt;
        tb = u[1] + h;
        if (mb === null || tb > mb)
          mb = tb;
        th = h;
        if (mh === null || th > mh)
          mh = th;
      }
    });
    offL = (fw - mr + ml) / 2 - ml;
    offH = (fh - mb + mt) / 2 - mt;
    p.items.each(function(o) {
      if (o.isSelected) {
        flg = true;
        u = o.bindComp;
        w = o.getLocalXY();
        switch (type) {
          case 1:
            v = Ext.Number.snap(ml, 8);
            o.setLocalX(v);
            u.setLocalX(v);
            break;
          case 2:
            v = Ext.Number.snap(ml + (mw - o.getWidth()) / 2, 8);
            o.setLocalX(v);
            u.setLocalX(v);
            break;
          case 3:
            v = Ext.Number.snap(w[0] + offL, 8);
            o.setLocalX(v);
            u.setLocalX(v);
            break;
          case 4:
            v = Ext.Number.snap(mr - o.getWidth(), 8);
            o.setLocalX(v);
            u.setLocalX(v);
            break;
          case 5:
            v = Ext.Number.snap(mt, 8);
            o.setLocalY(v);
            u.setLocalY(v);
            break;
          case 6:
            v = Ext.Number.snap(mt + (mh - o.getHeight()) / 2, 8);
            o.setLocalY(v);
            u.setLocalY(v);
            break;
          case 7:
            v = Ext.Number.snap(w[1] + offH, 8);
            o.setLocalY(v);
            u.setLocalY(v);
            break;
          case 8:
            v = Ext.Number.snap(mb - o.getHeight(), 8);
            o.setLocalY(v);
            u.setLocalY(v);
            break;
        }
      }
    });
    button.ownerCt.ownerCt.hide();
    if (flg)
      Ide.setModified();
  },
  getPack: function(type) {
    Wb.request({
      url: 'm?xwl=dev/ide/get-pack',
      params: {
        type: type
      },
      timeout: -1,
      success: function(resp) {
        Wb.info('已经成功在目录 “' + resp.responseText + '” 生成软件包。');
      }
    });
  },
  /**
   * 创建视图界面。
   */
  createView: function() {
    new Ext.container.Viewport({
      layout: 'border',
      listeners: {
        afterrender: {
          single: true,
          fn: function(me) {
            Wb.getRefer(me, Ide);
          }
        }
      },
      items: [{
        xtype: 'toolbar',
        region: 'north',
        border: false,
        enableOverflow: true,
        weight: 90,
        items: [{
          text: '文件',
          menu: {
            minWidth: 220,
            items: [{
              text: '打开选择的文件<span class="wb_right">Ctrl+O</span>',
              iconCls: 'open_icon',
              handler: Ide.open
            }, '-', {
              text: '导入模块包...',
              iconCls: 'import_icon',
              handler: function() {
                Ide.importModules();
              }
            }, {
              text: '导出模块包...',
              iconCls: 'export_icon',
              handler: function() {
                Ide.exportModules();
              }
            }, '-', {
              text: '导入到选择目录...',
              handler: function() {
                Ide.importFile();
              }
            }, {
              text: '导入到选择目录并解压...',
              handler: function() {
                Ide.importFile(true);
              }
            }, {
              text: '导出选择文件',
              handler: function() {
                Ide.exportFile();
              }
            }, {
              text: '导出选择文件并压缩',
              handler: function() {
                Ide.exportFile(true);
              }
            }, '-', {
              text: '检出...',
              iconCls: 'check_out_icon',
              handler: app.checkOut
            }, {
              text: '检入...',
              iconCls: 'check_in_icon',
              handler: app.checkIn
            }, {
              text: '版本文件管理',
              iconCls: 'file_edit_icon',
              handler: function() {
                Wb.open({
                  url: 'm?xwl=dev/ide/version/version-mng',
                  title: '版本文件管理',
                  iconCls: 'file_edit_icon'
                });
              }
            }, '-', {
              text: '关闭模块全部标签页',
              type: 1,
              handler: Ide.closeInnerTab
            }, {
              text: '关闭模块其他标签页',
              type: 2,
              handler: Ide.closeInnerTab
            }, '-', {
              text: '关闭全部文件',
              handler: Ide.closeAll
            }, {
              text: '关闭其他文件',
              handler: Ide.closeOthers
            }]
          }
        }, {
          text: '编辑',
          menu: {
            minWidth: 220,
            listeners: {
              show: function() {
                var noEditor = !Ide.getEditor();
                var btns = ['addBookmarkBtn', 'delBookmarkBtn', 'insertFnNoteBtn', 'insertPropNoteBtn',
                  'insertTodoBtn', 'insertAjaxBtn', 'addAppBtn'
                ];
                Wb.each(btns, function(btn) {
                  Ide[btn].setDisabled(noEditor);
                });
              }
            },
            items: [{
              text: '剪切<span class="wb_right">Ctrl+X</span>',
              iconCls: 'cut_icon',
              handler: Ide.cut
            }, {
              text: '复制<span class="wb_right">Ctrl+C</span>',
              iconCls: 'copy_icon',
              handler: Ide.copy
            }, {
              text: '粘贴<span class="wb_right">Ctrl[+Shift]+V</span>',
              iconCls: 'paste_icon',
              handler: Ide.paste
            }, {
              text: '删除<span class="wb_right">Ctrl+Shift+X|Delete</span>',
              iconCls: 'delete_icon',
              handler: Ide.remove
            }, '-', {
              text: '添加书签<span class="wb_right">Ctrl+M</span>',
              itemId: 'addBookmarkBtn',
              handler: Ide.addBookmark
            }, {
              text: '删除所有书签',
              itemId: 'delBookmarkBtn',
              handler: Ide.clearBookmark
            }, '-', {
              text: '插入函数注释<span class="wb_right">Ctrl+1</span>',
              itemId: 'insertFnNoteBtn',
              handler: Ide.addFuncNote
            }, {
              text: '插入属性注释<span class="wb_right">Ctrl+2</span>',
              itemId: 'insertPropNoteBtn',
              handler: Ide.addPropertyNote
            }, {
              text: '插入 TODO<span class="wb_right">Ctrl+3</span>',
              itemId: 'insertTodoBtn',
              handler: Ide.addTodo
            }, {
              text: '插入 Wb.request<span class="wb_right">Ctrl+4</span>',
              itemId: 'insertAjaxBtn',
              handler: Ide.addWbRequest
            }, {
              text: '插入 app<span class="wb_right">Ctrl+Shift+1</span>',
              itemId: 'addAppBtn',
              handler: Ide.addAppTpl
            }]
          }
        }, {
          text: '查看',
          menu: {
            minWidth: 180,
            items: [{
              text: '外观',
              hideOnClick: false,
              menu: {
                listeners: {
                  show: function() {
                    Ide[Wb.theme + 'Btn'].setChecked(true);
                  }
                },
                items: [{
                  text: '经典',
                  checked: false,
                  itemId: 'classicBtn',
                  group: 'theme',
                  handler: Ide.setTheme
                }, {
                  text: '灰色',
                  checked: false,
                  itemId: 'grayBtn',
                  group: 'theme',
                  handler: Ide.setTheme
                }, {
                  text: '海王星',
                  checked: false,
                  itemId: 'neptuneBtn',
                  group: 'theme',
                  handler: Ide.setTheme
                }, {
                  text: '现代',
                  checked: false,
                  itemId: 'modernBtn',
                  group: 'theme',
                  handler: Ide.setTheme
                }]
              }
            }, {
              text: '脚本编辑器',
              hideOnClick: false,
              menu: {
                listeners: {
                  show: function() {
                    Ide[Wb.editTheme + 'Theme'].setChecked(true);
                  }
                },
                items: [{
                  text: '默认',
                  checked: false,
                  itemId: 'defaultTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }, {
                  text: 'Night',
                  checked: false,
                  itemId: 'nightTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }, {
                  text: 'Blackboard',
                  checked: false,
                  itemId: 'blackboardTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }, {
                  text: 'Eclipse',
                  checked: false,
                  itemId: 'eclipseTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }, {
                  text: 'MBO',
                  checked: false,
                  itemId: 'mboTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }, {
                  text: 'Rubyblue',
                  checked: false,
                  itemId: 'rubyblueTheme',
                  group: 'edit',
                  handler: Ide.setEditTheme
                }]
              }
            }, {
              text: '文件标题',
              itemId: 'useFileTitleBtn',
              toggle: true,
              checked: app.initParams.fileTitle,
              handler: function(btn) {
                app.initParams.fileTitle = btn.checked;
                btn.ownerCt.hide();
                app.fileTree.view.refresh();
              }
            }]
          }
        }, {
          text: '搜索',
          menu: {
            minWidth: 220,
            items: [{
              text: '搜索文本...<span class="wb_right">Ctrl+H</span>',
              iconCls: 'textarea_icon',
              handler: Ide.search
            }, {
              text: '重新搜索<span class="wb_right">Ctrl+Shift+H</span>',
              handler: Ide.searchAgain
            }, {
              text: '替换...',
              handler: Ide.replace
            }, '-', {
              text: '搜索文件...',
              iconCls: 'file_default_icon',
              handler: function() {
                Wb.prompt({
                  title: '搜索文件',
                  iconCls: 'file_default_icon',
                  items: [{
                    xtype: 'combo',
                    fieldLabel: '文件名称',
                    itemId: 'query',
                    saveKeyname: 'sys.ide.find.fileList',
                    pickKeyname: 'sys.ide.find.fileList',
                    store: []
                  }, {
                    xtype: 'radiogroup',
                    fieldLabel: '修改日期',
                    itemId: 'dateRange',
                    saveKeyname: 'sys.ide.find.lastModified',
                    items: [{
                      boxLabel: '全部',
                      checked: true
                    }, {
                      boxLabel: '今天'
                    }, {
                      boxLabel: '昨天'
                    }, {
                      boxLabel: '指定'
                    }, {
                      xtype: 'datefield',
                      allowBlank: false,
                      itemId: 'modifyDate',
                      disabled: true,
                      saveKeyname: 'sys.ide.find.specifyDate',
                      width: 110
                    }],
                    listeners: {
                      change: function(me, value) {
                        var dateControl = me.getComponent('modifyDate'),
                          dateValue;
                        dateControl.setDisabled(value != 3);
                        dateValue = dateControl.getValue();
                        var hint = '';
                        switch (value) {
                          case 0:
                            hint = '查询所有文件';
                            break;
                          case 1:
                            hint = '查询今天修改的所有文件';
                            break;
                          case 2:
                            hint = '查询从昨天到今天修改的所有文件';
                            break;
                          case 3:
                            hint = '查询从指定日期到今天修改的所有文件';
                            break;
                        }
                        me.nextSibling().setValue(hint);
                      }
                    }
                  }, {
                    hideEmptyLabel: false,
                    xtype: 'displayfield',
                    value: '查询所有文件'
                  }],
                  handler: function(values, win) {
                    var lastModified;
                    switch (values.dateRange) {
                      case 0:
                        lastModified = -1;
                        break;
                      case 1:
                        lastModified = Ext.Date.clearTime(new Date());
                        break;
                      case 2:
                        lastModified = Ext.Date.add(Ext.Date.clearTime(new Date()), Ext.Date.DAY, -1);
                        break;
                      case 3:
                        lastModified = values.modifyDate;
                        break;
                    }
                    Ide.searchGrid.store.load({
                      params: {
                        lastModified: lastModified,
                        searchType: 'filelist',
                        searchList: true,
                        query: values.query
                      },
                      callback: function(a, b, success) {
                        if (success) {
                          Ide.showSearch();
                          Ide.searchGrid.searched = true;
                          win.close();
                        }
                      }
                    });
                  }
                });
              }
            }, {
              text: '快速检索文件...<span class="wb_right">Ctrl+Shift+L</span>',
              handler: Ide.searchFile
            }, {
              text: '搜索 TODO',
              handler: Ide.searchTodo
            }, {
              text: '搜索重复模块',
              handler: function() {
                Ide.searchGrid.store.load({
                  params: {
                    searchType: 'duplicate'
                  },
                  callback: function(a, b, success) {
                    if (success) {
                      Ide.showSearch();
                      Ide.searchGrid.searched = true;
                    }
                  }
                });
              }
            }, {
              text: '搜索隐患模块',
              handler: function() {
                Ide.searchGrid.store.load({
                  params: {
                    searchType: 'bug'
                  },
                  callback: function(a, b, success) {
                    if (success) {
                      Ide.showSearch();
                      Ide.searchGrid.searched = true;
                    }
                  }
                });
              }
            }, {
              text: '搜索 URL 捷径...',
              handler: function() {
                Wb.prompt({
                  title: '搜索 URL 捷径',
                  iconCls: 'search_icon',
                  items: [{
                    xtype: 'combo',
                    fieldLabel: 'URL 捷径',
                    itemId: 'shortcut',
                    allowBlank: false,
                    saveKeyname: 'sys.ide.find.shortcut',
                    pickKeyname: 'sys.ide.find.shortcut',
                    store: []
                  }],
                  handler: function(values, win) {
                    Ide.searchGrid.store.load({
                      params: {
                        searchType: 'shortcut',
                        shortcut: values.shortcut
                      },
                      callback: function(a, b, success) {
                        if (success) {
                          Ide.showSearch();
                          Ide.searchGrid.searched = true;
                          win.close();
                        }
                      }
                    });
                  }
                });
              }
            }, {
              text: '跳转到行...<span class="wb_right">Ctrl+5</span>',
              handler: Ide.gotoLine
            }]
          }
        }, {
          text: '设计',
          menu: {
            minWidth: 190,
            items: [{
              text: '布局设计器<span class="wb_right">Ctrl+B</span>',
              iconCls: 'window_icon',
              handler: Ide.setLayout
            }, {
              text: '自动调整控件顺序<span class="wb_right">Ctrl+Shift+U</span>',
              iconCls: 'order_icon',
              handler: Ide.adjustZIndex
            }, {
              text: '批量属性设置...',
              handler: Ide.batchUpdate
            }, {
              text: '清除控件位置信息',
              handler: Ide.clearCoord
            }, {
              text: '纸张大小设置...',
              handler: Ide.setPaper
            }, '-', {
              text: 'SQL 生成器<span class="wb_right">Ctrl+Shift+B</span>',
              iconCls: 'sql_icon',
              handler: Ide.setSQL
            }, {
              text: '自动填充表单<span class="wb_right">Ctrl+Shift+K</span>',
              iconCls: 'db_field_edit_icon',
              handler: Ide.fillForm
            }, '-', {
              xtype: 'buttongroup',
              title: '文本对齐方式',
              columns: 4,
              defaults: {
                xtype: 'button',
                iconAlign: 'top', //使按钮居中显示
                text: ' ',
                handler: Ide.setFieldAlign,
                width: 35
              },
              items: [{
                tooltip: '左对齐',
                alignValue: 'left',
                iconCls: 'text_align_left_icon'
              }, {
                tooltip: '居中对齐',
                alignValue: 'center',
                iconCls: 'text_align_center_icon'
              }, {
                tooltip: '右对齐',
                alignValue: 'right',
                iconCls: 'text_align_right_icon'
              }, {
                itemId: 'anchorRightBtn',
                iconCls: 'text_align_right_pin_icon',
                enableToggle: true,
                pressed: false,
                handler: Ext.emptyFn,
                tooltip: '新添加的控件文本锁定右对齐'
              }]
            }, {
              xtype: 'buttongroup',
              title: '控件对齐方式',
              columns: 4,
              defaults: {
                xtype: 'button',
                scale: 'large',
                width: 35,
                handler: Ide.setAlign
              },
              items: [{
                iconCls: 'ide_h1',
                tooltip: '左对齐',
                type: 1
              }, {
                iconCls: 'ide_h2',
                tooltip: '水平居中对齐',
                type: 2
              }, {
                iconCls: 'ide_h3',
                tooltip: '容器内水平居中对齐',
                type: 3
              }, {
                iconCls: 'ide_h4',
                tooltip: '右对齐',
                type: 4
              }, {
                iconCls: 'ide_v1',
                tooltip: '顶部对齐',
                type: 5
              }, {
                iconCls: 'ide_v2',
                tooltip: '垂直居中对齐',
                type: 6
              }, {
                iconCls: 'ide_v3',
                tooltip: '容器内垂直居中对齐',
                type: 7
              }, {
                iconCls: 'ide_v4',
                tooltip: '底部对齐',
                type: 8
              }]
            }]
          }
        }, {
          text: '工具',
          menu: {
            minWidth: 180,
            items: [{
              text: '数据库浏览器',
              iconCls: 'db_icon',
              handler: function() {
                Wb.open({
                  url: 'dbe',
                  title: '数据库浏览器',
                  iconCls: 'db_icon'
                });
              }
            }, {
              text: '文件管理器',
              iconCls: 'explorer_icon',
              handler: function() {
                Wb.open({
                  url: 'file',
                  title: '文件管理器',
                  iconCls: 'explorer_icon'
                });
              }
            }, {
              text: '键值编辑器',
              iconCls: 'dp_icon',
              handler: function() {
                Wb.open({
                  url: 'kve',
                  title: '键值编辑器',
                  iconCls: 'dp_icon'
                });
              }
            }, {
              text: '数据字典',
              iconCls: 'book_icon',
              handler: function() {
                Wb.open({
                  url: 'dict',
                  title: '数据字典',
                  iconCls: 'book_icon'
                });
              }
            }, '-', {
              text: '生成软件包',
              menu: {
                items: [{
                  text: '演示版本',
                  itemId: 'getRelPackBtn',
                  handler: function() {
                    if (Ide.versionType != 'x')
                      Ide.getPack('r');
                    else
                      Ide.getPack('d');
                  }
                }, {
                  text: '企业版本 (简化版)',
                  itemId: 'getStdPackBtn',
                  handler: function() {
                    Ide.getPack('s');
                  }
                }, {
                  text: '企业版本 (完全版)',
                  itemId: 'getEntPackBtn',
                  handler: function() {
                    Ide.getPack('e');
                  }
                }]
              }
            }, {
              text: '压缩 JS/CSS 文件',
              iconCls: 'file_zip_icon',
              handler: function() {
                Wb.choose('确定要压缩应用目录下以“-debug”结尾的所有调试文件吗？<br>' +
                  '警告：压缩生成的新文件名为去除“-debug”的文件名，如果文件存在将被覆盖。<br>' +
                  '[是]：压缩所有文件，[否]：压缩修改过的文件，[取消]：取消操作。',
                  function(btn) {
                    if (btn != 'cancel') {
                      Wb.request({
                        url: 'm?xwl=dev/ide/compress',
                        params: {
                          compressAll: btn == 'yes'
                        },
                        timeout: -1,
                        success: function() {
                          Wb.info('所有文件已经压缩完成。');
                        }
                      });
                    }
                  });
              }
            }, {
              text: '刷新系统',
              iconCls: 'start_icon',
              handler: function() {
                Wb.request({
                  url: 'm?xwl=dev/ide/reload',
                  success: function() {
                    Wb.tip('已经成功刷新系统。');
                  }
                });
              }
            }]
          }
        }, '-', {
          tooltip: '添加文件 (Ctrl+J)',
          overflowText: '添加文件',
          iconCls: 'file_add_icon',
          handler: Ide.add,
          xtype: 'splitbutton',
          menu: {
            items: [{
              text: '模块文件...',
              handler: app.add
            }, {
              text: '增删改查框架...',
              handler: app.createCRUDFrame
            }, {
              text: '主页面框架...',
              handler: app.createMainFrame
            }, {
              text: '公共对话框框架...',
              handler: app.createDialogFrame
            }]
          }
        }, {
          tooltip: '添加目录 (Ctrl+Shift+J)',
          overflowText: '添加目录',
          iconCls: 'folder_add_icon',
          handler: Ide.addFolder
        }, {
          tooltip: '属性 (Ctrl+U)',
          overflowText: '属性',
          iconCls: 'property_icon',
          handler: Ide.setProperty
        }, {
          tooltip: '布局设计器 (Ctrl+B)',
          overflowText: '布局设计器',
          itemId: 'layoutBtn',
          iconCls: 'window_icon',
          handler: Ide.setLayout
        }, {
          itemId: 'runBtn',
          tooltip: '保存当前模块并运行 (Ctrl+Q)',
          overflowText: '保存当前模块并运行',
          iconCls: 'run_icon',
          handler: Ide.run
        }, '-', {
          itemId: 'saveBtn',
          tooltip: '保存 (Ctrl+S)',
          overflowText: '保存',
          iconCls: 'save_icon',
          handler: Ide.save
        }, {
          itemId: 'saveAllBtn',
          tooltip: '保存全部 (Ctrl+Shift+S)',
          overflowText: '保存全部',
          iconCls: 'save_all_icon',
          handler: Ide.saveAll
        }, '-', {
          tooltip: '后退 (Ctrl+9)',
          overflowText: '后退',
          iconCls: 'left_icon',
          handler: Ide.back
        }, {
          tooltip: '前进 (Ctrl+0)',
          overflowText: '前进',
          iconCls: 'right_icon',
          handler: Ide.forward
        }, {
          tooltip: '转到设计页面 (Ctrl+6)',
          overflowText: '转到设计页面',
          iconCls: 'model_icon',
          handler: Ide.toDesign
        }, {
          tooltip: '切换文件/运行页面 (Ctrl+7)',
          overflowText: '切换文件/运行页面',
          iconCls: 'set_icon',
          handler: Ide.toggleRun
        }, {
          tooltip: '切换属性/脚本编辑器 (Ctrl+8)',
          overflowText: '切换属性/脚本编辑器',
          iconCls: 'move_icon',
          handler: Ide.toggleEditor
        }, '-', {
          tooltip: '显示/隐藏多功能视图 (Ctrl+Shift+I)',
          overflowText: '显示/隐藏多功能视图',
          itemId: 'toggleViewBtn',
          iconCls: 'view_icon',
          enableToggle: true,
          listeners: {
            toggle: Ide.toggleView
          }
        }, {
          tooltip: '服务端信息显示在控制台 (Ctrl+I)',
          overflowText: '服务端信息显示在控制台',
          itemId: 'toggleOutputsBtn',
          iconCls: 'console_icon',
          enableToggle: true,
          pressed: true,
          listeners: {
            toggle: function(a, pressed) {
              if (pressed)
                Ide.msgSocket.open();
              else
                Ide.msgSocket.close();
            }
          }
        }, '->', {
          text: '主卡',
          menu: {
            items: [{
              text: ''
            }],
            listeners: {
              beforeshow: function(me) {
                var items = [];
                Ide.fileTab.items.each(function(card) {
                  items.push({
                    iconCls: card.iconCls,
                    icon: card.icon,
                    text: card.title,
                    noStarText: Ext.String.startsWith(card.title, '*') ? card.title.substring(1) : card.title,
                    cardId: card.id,
                    tooltip: card.title == card.tab.tooltip ? '' : card.tab.tooltip
                  });
                });
                me.removeAll(true);
                if (items.length === 0)
                  items.push({
                    text: '(无)'
                  });
                Wb.sort(items, 'noStarText');
                me.add(items);
              },
              click: function(menu, item) {
                if (item.cardId)
                  Ide.fileTab.setActiveTab(Ext.getCmp(item.cardId));
              }
            }
          }
        }, {
          text: '子卡',
          menu: {
            items: [{
              text: ''
            }],
            listeners: {
              beforeshow: function(me) {
                var items = [];
                if (Ide.activeCard && Ide.activeCard instanceof Ext.tab.Panel) {
                  Ide.activeCard.items.each(function(card) {
                    items.push({
                      iconCls: card.iconCls,
                      icon: card.icon,
                      text: card.title,
                      cardId: card.id,
                      tooltip: card.title == card.tab.tooltip ? '' : card.tab.tooltip
                    });
                  });
                }
                me.removeAll(true);
                if (items.length === 0)
                  items.push({
                    text: '(无)'
                  });
                Wb.sort(items, 'text');
                me.add(items);
              },
              click: function(menu, item) {
                if (item.cardId)
                  Ide.activeCard.setActiveTab(Ext.getCmp(item.cardId));
              }
            }
          }
        }]
      }, {
        itemId: 'fileTree',
        xtype: 'treepanel',
        title: '文件列表',
        iconCls: 'explorer_icon',
        region: 'west',
        weight: 30,
        rootVisible: false,
        multiSelect: true,
        width: 230,
        split: true,
        collapsible: true,
        hideHeaders: true,
        cls: 'x-autowidth-table',
        popupMenu: {
          xtype: "menu",
          minWidth: 200,
          items: [{
              text: "添加文件...<span class='wb_right'>Ctrl+J</span>",
              iconCls: "file_add_icon",
              handler: app.add
            }, {
              text: "添加目录...<span class='wb_right'>Ctrl+Shift+J</span>",
              iconCls: "folder_add_icon",
              handler: app.addFolder
            }, '-', {
              text: '检出...',
              iconCls: 'check_out_icon',
              handler: app.checkOut
            }, {
              text: '检入...',
              iconCls: 'check_in_icon',
              handler: app.checkIn
            }, '-', {
              text: '添加框架模块',
              menu: {
                items: [{
                  text: '增删改查...',
                  handler: app.createCRUDFrame
                }, {
                  text: '主页面...',
                  handler: app.createMainFrame
                }, {
                  text: '公共对话框...',
                  handler: app.createDialogFrame
                }]
              }
            },
            "-", {
              text: "剪切<span class='wb_right'>Ctrl+X</span>",
              iconCls: "cut_icon",
              handler: app.cut
            }, {
              text: "复制<span class='wb_right'>Ctrl+C</span>",
              iconCls: "copy_icon",
              handler: app.copy
            }, {
              text: "粘贴<span class='wb_right'>Ctrl+V</span>",
              iconCls: "paste_icon",
              handler: app.paste
            }, {
              text: "删除<span class='wb_right'>Delete</span>",
              iconCls: "delete_icon",
              handler: app.remove
            }
          ]
        },
        columns: [{
          xtype: 'treecolumn',
          dataIndex: 'text',
          width: Ext.isIE6 ? '100%' : 10000,
          renderer: function(value, meta, record) {
            var title = record.data.title;
            value = Wb.encodeHtml(value);
            if (app.initParams.fileTitle && title)
              return value + '&nbsp;&nbsp;<span style="color:#999;">' + Wb.encodeHtml(title) + '</span>';
            else return value;
          }
        }],
        tbar: {
          itemId: 'searchBar',
          hidden: true,
          items: [{
            itemId: 'combo',
            xtype: 'combobox',
            displayField: 'name',
            valueField: 'path',
            triggerAction: 'last',
            triggerCls: 'x-form-search-trigger',
            onTriggerClick: function() {
              var value = this.getValue();
              if (value)
                Ide.selectPath(value);
            },
            flex: 1,
            listConfig: {
              itemTpl: [
                '<div>{text}</div>'
              ]
            },
            store: {
              url: 'm?xwl=dev/ide/search-file',
              fields: ['path', {
                name: 'text',
                convert: function(v, rec) {
                  return Ide.getPathText(rec.data.path);
                }
              }, {
                name: 'name',
                convert: function(v, rec) {
                  return Wb.getFilename(rec.data.path);
                }
              }]
            },
            listeners: {
              beforequery: function(plan) {
                if (plan.query.indexOf('/') != -1 || plan.query.indexOf('\\') != -1) {
                  plan.combo.collapse();
                  return false;
                }
              },
              select: function(a, records) {
                Ide.doOpen(records[0].data.path, function(card) {
                  if (card.editor)
                    card.editor.focus();
                });
              },
              specialkey: function(me, e) {
                if (e.getKey() == e.ENTER && !me.isExpanded) {
                  Ide.selectPath(me.getValue());
                }
              }
            }
          }]
        },
        tools: [{
          type: 'refresh',
          tooltip: '刷新',
          callback: function() {
            Wb.reload(Ide.fileTree);
          }
        }, {
          type: 'search',
          tooltip: '显示/隐藏搜索框',
          callback: function() {
            Ide.doSearchFile(true);
          }
        }],
        store: {
          url: 'm?xwl=dev/ide/get-tree',
          fields: ['base', 'text', 'type', 'title', 'hidden', 'inframe', 'pageLink'],
          listeners: {
            beforeload: function(store, operation) {
              var node = operation.node;
              Ext.apply(operation.params, {
                path: Ide.getPath(node),
                type: Wb.getNode(node, 1).data.type
              });
            },
            success: function(a, node) {
              if (node.isRoot()) {
                var firstChild = node.firstChild;
                Ide.modulePath = firstChild.data.base;
                Ide.webPath = firstChild.nextSibling.data.base;
                //Ide.modNode是文件列表模块节点，Ide.moduleNode是控件中的模块控件节点
                Ide.modNode = firstChild;
                Ide.appNode = firstChild.nextSibling;
                Ide.sysNode = Ide.appNode.nextSibling;
              }
            }
          }
        },
        viewConfig: {
          plugins: {
            ptype: 'treeviewdragdrop',
            ddGroup: 'file'
          },
          listeners: {
            beforedrop: function(node, data, om, dp, dh) {
              var sels = Wb.reverse(data.records),
                files = [];
              Wb.each(sels, function(n) {
                files.push(Ide.getPath(n));
              });
              dh.wait = true;
              Wb.request({
                url: 'm?xwl=dev/ide/move',
                timeout: -1,
                params: {
                  src: Wb.encode(files),
                  dst: Ide.getPath(om),
                  dropPosition: dp,
                  type: Wb.getNode(om, 1).data.type
                },
                callback: function(options, succ, resp) {
                  function doSync() {
                    Ide.syncFiles(sels);
                    Ide.syncData(Wb.decode(resp.responseText));
                    Ide.fileTree.setSelection(sels);
                  }
                  if (succ) {
                    Ide.setOldPath(sels);
                    if (dp == 'append' && !om.isLoaded()) {
                      //如果没有加载只需展开节点即可，否则造成节点重复
                      var nodeData = [];
                      dh.cancelDrop();
                      Wb.each(sels, function(node) {
                        nodeData.push([node.data.text, Ide.getPath(node)]);
                      });
                      Wb.remove(sels);
                      om.expand(false, function() {
                        sels = [];
                        Wb.each(nodeData, function(item) {
                          var node = om.findChild('text', item[0]);
                          node.data.oldPath = item[1];
                          sels.push(node);
                        });
                        doSync();
                      });
                    } else {
                      dh.processDrop();
                      doSync();
                    }
                  } else
                    dh.cancelDrop();
                }
              });
            },
            nodedragover: function(node, dp, data) {
              var hasRootMoved, hasBaseMoved, hasSameParent, parentNode = node.parentNode,
                isFileNode = Wb.getNode(node, 1).data.type != 'module';
              Wb.each(data.records, function(n) {
                if (n.getDepth() == 1) {
                  hasRootMoved = true;
                  return false;
                }
                if (n.getDepth() == 2 && Wb.getNode(n, 1).data.type == 'file') {
                  hasBaseMoved = true;
                  return false;
                }
                if (n.parentNode == parentNode) {
                  hasSameParent = true;
                  return false;
                }
              });
              if (hasRootMoved || hasBaseMoved || node.getDepth() == 1 && dp != 'append' ||
                isFileNode && hasSameParent && dp != 'append')
                return false;
            }
          }
        },
        listeners: {
          itemkeydown: Wb.mimicClick,
          itemdblclick: function(view, record, item, index, e) {
            if (record.isLeaf()) {
              if (e.ctrlKey) {
                var text = Ide.getNodeUrl(record);
                if (text)
                  Ide.insertText(text);
              } else
                Ide.open();
            }
          }
        }
      }, {
        xtype: 'tabpanel',
        region: 'center',
        itemId: 'fileTab',
        deferredRender: false,
        closeOther: Ide.closeOthers,
        closeAll: Ide.closeAll,
        plugins: ['tabreorderer', 'tabclosemenu'],
        listeners: {
          afterrender: {
            single: true,
            fn: function(me) {
              me.mon(me.tabBar.el, 'dblclick', function(e, target) {
                var card = Ide.activeCard;
                if (card && card.bindFile && !card.hasParams && card.tab.el.isAncestor(target)) {
                  if (Ext.String.endsWith(card.bindFile, '.xwl'))
                    window.open('m?xwl=' + card.bindFile.slice(0, -4));
                  else
                    window.open(card.bindFile);
                }
              }, me);
            }
          },
          beforetabchange: function(me, newCard) {
            var subCard;
            if (newCard.cardType == 'module')
              subCard = newCard.getActiveTab();
            Ide.controlTree.setVisible(subCard && (subCard.itemId == 'designCard' || subCard.layoutCard));
          },
          tabchange: function(me, newCard) {
            Ide.activeCard = newCard;
            Ide.activeScope = newCard.appScope;
            Ide.setButtons();
            Ide.recordActivity();
          },
          remove: function(me) {
            if (me.items.length === 0) {
              Ide.activeCard = null;
              Ide.activeScope = null;
              Ide.activeCmp = 'file';
            }
            Ide.setButtons();
          }
        }
      }, {
        region: 'east',
        itemId: 'controlTree',
        title: '控件箱',
        width: 160,
        tools: Wb.getTreeTools({
          search: true,
          expand: false,
          collapse: false
        }),
        xtype: 'treepanel',
        iconCls: 'tool_icon',
        collapsible: true,
        rootVisible: false,
        split: true,
        ddGroup: 'controlList',
        store: {
          url: 'm?xwl=dev/cm/get-tree&type=ide',
          fields: ['id', 'text', 'control', 'type', 'general', 'configs', 'events'],
          listeners: {
            success: function() {
              Ide.moduleNode = Ide.controlTree.getRootNode().findChild('id', 'module', true);
              Ide.controlMap = {
                module: Ide.moduleNode
              };
              Ide.moduleNode.remove();
              Ide.controlTree.getRootNode().cascadeBy(function(node) {
                if (node.data.control) {
                  Ide.controlMap[node.data.id] = node;
                }
              });
            }
          }
        },
        listeners: {
          itemkeydown: Wb.mimicClick,
          itemdblclick: function(me, record) {
            var designer, card = Ide.activeCard;
            if (card && record.data.control && card.cardType == 'module' && card.getActiveTab().layoutCard) {
              designer = card.getActiveTab().designer;
              Ide.addDesignComp(designer, record, designer.body.dom.scrollLeft + 8, designer.body.dom.scrollTop + 8);
            } else
              Ide.addControl(record);
          }
        },
        viewConfig: {
          plugins: {
            ptype: 'treeviewdragdrop',
            ddGroup: 'controlList',
            enableDrop: false
          }
        }
      }, {
        region: 'south',
        itemId: 'utilView',
        xtype: 'tabpanel',
        split: true,
        hidden: true,
        deferredRender: false,
        height: 120,
        listeners: {
          afterrender: {
            single: true,
            fn: function(me) {
              me.fireEvent('tabchange', me, me.items.items[0]);
            }
          },
          tabchange: function(tab, card) {
            var itemId = card.itemId;
            Ext.suspendLayouts();
            tab.tabBar.items.each(function(item) {
              if (!(item instanceof Ext.tab.Tab) && !item.ignoreItem)
                item.setVisible(item.belong === itemId || Wb.indexOf(item.belong, itemId) != -1);
            });
            Ext.resumeLayouts(true);
          }
        },
        tabBar: {
          defaultType: 'button',
          items: [{
            xtype: 'tbfill',
            ignoreItem: true
          }, {
            tooltip: '刷新',
            iconCls: 'refresh_icon',
            handler: function() {
              var card = Ide.utilView.getActiveTab();
              if (card == Ide.threadCard)
                app.refreshThread();
              else if (card == Ide.connCard)
                app.refreshConnection();
              else
                Ide.searchAgain();
            },
            belong: ['threadCard', 'connCard', 'searchGrid']
          }, {
            tooltip: '清除',
            iconCls: 'file_delete_icon',
            handler: function() {
              var card = Ide.utilView.getActiveTab();
              if (card == Ide.threadCard)
                Ide.threadCard.update('');
              else if (card == Ide.connCard)
                Ide.connCard.update('');
              else if (card.store)
                card.store.removeAll();
            },
            belong: 'searchGrid',
            ignoreItem: true
          }, {
            xtype: 'tbspacer',
            width: 8,
            ignoreItem: true
          }]
        },
        items: [{
          itemId: 'markerGrid',
          title: '标记',
          xtype: 'grid',
          pagingBar: false,
          iconCls: 'registration_icon',
          store: {
            fields: ['message', 'type', 'path', 'line', 'ch', 'cardId']
          },
          columns: [{
            xtype: 'rownumberer'
          }, {
            text: '内容',
            dataIndex: 'message',
            flex: 2,
            renderer: function(value, meta, record) {
              var type = record.get('type'),
                icons = {
                  error: 'error_icon',
                  warning: 'warning_icon'
                };
              return Wb.getIcon(icons[type] || 'info_icon') + Ext.htmlEncode(value);
            }
          }, {
            text: '文件',
            dataIndex: 'path',
            flex: 1,
            renderer: function(value) {
              return Ext.htmlEncode(Ide.getPathText(value));
            }
          }, {
            text: '位置',
            dataIndex: 'line',
            width: 70,
            align: 'right'
          }, {
            text: '类型',
            dataIndex: 'type',
            width: 70
          }],
          listeners: {
            itemkeydown: Wb.mimicClick,
            itemdblclick: function(view, record) {
              Ide.doOpen(record.get('path'), function(card) {
                var subCard;
                if (record.get('cardId')) {
                  subCard = card.getComponent(record.get('cardId'));
                  card.setActiveTab(subCard);
                  card = subCard;
                }
                card.editor.setCursor(record.get('line') - 1, record.get('ch'));
                card.editor.focus();
              });
            }
          }
        }, {
          itemId: 'searchGrid',
          title: '搜索',
          xtype: 'grid',
          plugins: {
            ptype: 'bufferedrenderer'
          },
          pagingBar: false,
          iconCls: 'search_icon',
          store: {
            url: 'm?xwl=dev/ide/search-text',
            timeout: -1,
            message: '正在搜索中，请稍候...',
            listeners: {
              success: function() {
                Ide.utilView.setActiveTab(Ide.searchGrid);
              }
            },
            fields: ['content', 'path', 'line', 'ch', 'nodePath', 'itemName', {
              name: 'pathText',
              convert: function(v, record) {
                var value = Ide.getPathText(record.data.path);
                if (Ext.String.endsWith(value, '.xwl')) {
                  if (record.data.nodePath)
                    return value + '@' + Wb.getSection(record.data.nodePath, '/', 1);
                }
                return value;
              }
            }, {
              name: 'lastModified',
              type: 'date',
              dateFormat: Wb.dateFormat
            }]
          },
          columns: [{
            xtype: 'rownumberer'
          }, {
            text: '内容',
            dataIndex: 'content',
            flex: 2,
            defaultRenderer: false
          }, {
            text: '文件',
            dataIndex: 'pathText',
            flex: 1
          }, {
            text: '位置',
            dataIndex: 'line',
            width: 70,
            align: 'right'
          }],
          listeners: {
            itemkeydown: Wb.mimicClick,
            itemdblclick: function(view, record) {
              var nodePath, subCard, path = record.get('path'),
                type = Wb.extractFileExt(path);
              if (!path) return;
              Ide.doOpen(path, function(card) {
                if (type == 'xwl') {
                  subCard = card.getActiveTab();
                  if (subCard.node)
                    nodePath = '/' + Wb.getSection(subCard.node.getPath('text'), '/', 2);
                  else
                    nodePath = '';
                  if (card.path == record.data.path && nodePath == record.data.nodePath && (subCard.itemType + '=' + subCard.itemName) == record.data.itemName) {
                    subCard.editor.setCursor(record.data.line - 1, record.data.ch);
                    subCard.editor.focus();
                  } else {
                    card.setActiveTab(card.designCard);
                    if (record.data.nodePath) {
                      card.tree.selectPath('/Root' + record.data.nodePath, 'text', '/', function() {
                        var type = Wb.namePart(record.data.itemName),
                          name = Wb.valuePart(record.data.itemName),
                          store = card.property.store,
                          index;
                        index = store.findBy(function(rec) {
                          return rec.data.type == type && rec.data.name == name;
                        });
                        if (index != -1) {
                          setTimeout(function() {
                            card.property.editPlugin.startEdit(store.getAt(index), 1);
                            Ide.doEdit(true, record.get('line'), record.get('ch'));
                          }, 10);
                        } else Wb.warn('没有找到 "' + name + '"。');
                      });
                    }
                  }
                } else {
                  card.editor.setCursor(record.get('line') - 1, record.get('ch'));
                  setTimeout(function() {
                    card.editor.scrollIntoView();
                    card.editor.focus();
                  }, 10);
                }
              });
            }
          }
        }, {
          itemId: 'connCard',
          title: '连接',
          xtype: 'container',
          iconCls: 'db_icon',
          autoScroll: true,
          padding: '0 8 0 8',
          listeners: {
            activate: function() {
              app.refreshConnection();
            }
          }
        }, {
          itemId: 'threadCard',
          title: '线程',
          xtype: 'container',
          iconCls: 'execute_icon',
          autoScroll: true,
          padding: '0 8 0 8',
          listeners: {
            activate: function() {
              app.refreshThread();
            }
          }
        }]
      }]
    });
  },
  /**
   * 启动IDE。
   */
  launch: function(config) {
    sys.ide = Ide;
    app = Ide;
    app.initParams = Wb.decode(config) || {};
    Ide.init();
    Ide.addEvents();
    Ide.createView();
    Ide.activeCmp = 'file';
    Ide.setButtons();
    Ide.addSocket();
  }
};